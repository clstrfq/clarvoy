# The Steward v2.0
## System 2 Governance & Outcomes Architecture for iOS
### A Recursive SDD Framework for Non-Profit Leadership

---

## What Is This?

This repository contains the complete **Spec-Driven Development (SDD) framework** for building "The Steward" — an iOS application that enforces cognitive hygiene protocols for non-profit governance, targeting a **98% Return on Donation** efficiency goal.

It is designed for **one-shot deployment via Replit Agent**. Upload this entire directory to Replit, then feed the `REPLIT_MEGA_PROMPT.md` to the Replit AI Agent to begin code generation.

---

## How To Use With Replit

1. Upload this entire directory to a new Replit project.
2. Open `REPLIT_MEGA_PROMPT.md` and copy its contents into the Replit Agent chat.
3. The Agent will read the four SDD documents (`constitution.md`, `spec.md`, `plan.md`, `tasks.md`) and execute the 41 build tasks across 12 phases.
4. Configure your `.env` file with Supabase, LLM provider, and OAuth credentials.
5. Run the database migration (`001_initial_schema.sql`) against your Supabase project.

---

## Repository Structure

```
the-steward-ios-sdd/
├── REPLIT_MEGA_PROMPT.md          ← START HERE (one-shot instruction for Replit)
├── README.md                      ← You are here
├── package.json                   ← Frontend dependencies (React Native / Expo)
├── app.json                       ← Expo configuration
├── tsconfig.json                  ← TypeScript configuration
├── .env.example                   ← Environment variables template
│
├── docs/                          ← THE SDD HIERARCHY (read in order)
│   ├── constitution.md            ← 1. SUPREME — 12 immutable Laws
│   ├── spec.md                    ← 2. Functional specification — 7 modules
│   ├── plan.md                    ← 3. Technical architecture — stack decisions
│   └── tasks.md                   ← 4. Build tasks — 41 tasks, 12 phases
│
├── src/                           ← Frontend source code (React Native)
│   ├── types/index.ts             ← All TypeScript type definitions
│   └── config/
│       ├── theme.ts               ← Design system (colors, typography)
│       └── constants.ts           ← System thresholds and configuration
│
├── server/                        ← Backend source code (Node.js / Express)
│   ├── package.json
│   └── src/
│       ├── index.ts               ← Server entry point (Shadow Layer registered here)
│       ├── middleware/
│       │   └── shadowLayer.ts     ← THE GOVERNANCE BACKDOOR (Law 4)
│       └── db/
│           └── migrations/
│               └── 001_initial_schema.sql  ← Complete database schema + seed data
│
└── python-services/               ← Statistical microservice (FastAPI)
    ├── main.py                    ← Monte Carlo engine, variance calculator
    └── requirements.txt           ← Python dependencies
```

---

## The 12 Constitutional Laws

| # | Law | Principle |
|---|-----|-----------|
| 1 | Epistemic Rigor | No prediction without confidence intervals |
| 2 | Noise Intolerance | Blind inputs before group discussion |
| 3 | The Outside View | Reference Class Forecasting is mandatory |
| 4 | Governance Backdoor | Shadow Layer audits all decisions |
| 5 | Outcome Binding | 98% efficiency — no feature bloat |
| 6 | Cognitive Sovereignty | AI augments, never decides |
| 7 | Data Sovereignty | All data exportable, no lock-in |
| 8 | Radical Transparency | Public API for decision logic |
| 9 | LLM Provider Sovereignty | User selects their LLM |
| 10 | Contextual Intelligence | Email/calendar is opt-in only |
| 11 | Voice Sovereignty | Recording requires explicit consent |
| 12 | Daily Bias Heat Map | Board-only oversight dashboard |

---

## Technology Stack

| Layer | Technology |
|---|---|
| Mobile | React Native + Expo SDK 52 |
| Navigation | React Navigation v6 |
| State | Zustand + React Query |
| Backend API | Express.js (Node.js 20) |
| Statistics | FastAPI (Python 3.11) + numpy/scipy |
| Database | Supabase (PostgreSQL 15 + pgvector) |
| Task Queue | BullMQ + Upstash Redis |
| LLM Providers | Gemini, NotebookLM, Claude, ChatGPT, Perplexity |

---

## Key Features

- **Noise Audit Engine** — Blind scoring, variance analysis, false consensus detection
- **Outside View Calculator** — Reference class forecasting with blocking mechanisms
- **Chaos Simulator** — Monte Carlo simulations with probability cones
- **Shadow Steward** — Real-time bias detection and adversarial debate generation
- **Multi-LLM Coaching** — Choose your AI coach from 5 providers
- **Email/Calendar Intelligence** — Opt-in contextual awareness for coaching
- **Voice Recording** — On-device transcription with consent management
- **Daily Bias Heat Map** — Board-only dashboard for organizational oversight
- **Friction-Full UI** — Deliberate delays, scroll gates, undismissable modals

---

*Built with Spec-Driven Development. The specification IS the source code.*
