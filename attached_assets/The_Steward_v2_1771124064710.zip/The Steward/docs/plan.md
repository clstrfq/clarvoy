# THE STEWARD — PLAN.md
## Technical Implementation Plan
### Version 2.0 | iOS Native (React Native / Expo) | Recursive SDD Framework

> **Authority Level:** SUBORDINATE to constitution.md and spec.md. This document maps the spec to a concrete technology stack and implementation architecture. The AI agent (Replit) must follow this plan when generating code.

---

## 1. TECHNOLOGY STACK DECISIONS

### 1.1 Frontend: React Native (Expo Managed Workflow)

| Decision | Choice | Rationale |
|---|---|---|
| Framework | React Native + Expo SDK 52+ | Replit's primary mobile path; single codebase; fast iteration |
| Navigation | React Navigation v6 | Industry standard for RN; supports tab + stack nesting |
| State Management | Zustand + React Query (TanStack) | Zustand for client state; React Query for server state/caching |
| Charts/Visualization | Victory Native + react-native-svg | Scatter plots, heat maps, probability cones |
| Forms | React Hook Form + Zod | Validation-first forms (enforces min character counts, etc.) |
| Auth | expo-auth-session + Supabase Auth | OAuth flows for Google/OpenAI; Supabase for session management |
| Audio | expo-av | Voice recording capture |
| Secure Storage | expo-secure-store | OAuth tokens on device |
| Animations | react-native-reanimated | Friction-full UI delays, countdown animations |

### 1.2 Backend: Node.js API Gateway + Python Microservices

| Decision | Choice | Rationale |
|---|---|---|
| API Gateway | Express.js (Node.js 20+) | Fast routing, middleware support for Shadow Layer |
| Statistical Engine | Python 3.11 (FastAPI) | numpy, scipy, pandas for Monte Carlo simulations |
| Database | Supabase (PostgreSQL 15 + pgvector) | Managed Postgres with vector search, auth, realtime |
| Vector Embeddings | pgvector extension | Cosine similarity for False Consensus detection |
| Caching | Supabase Edge Functions | Daily heat map caching, scheduled jobs |
| Task Queue | BullMQ (Redis-backed) | Async bias analysis, simulation runs, heat map generation |
| LLM Routing | Custom LLMRouter service | Provider adapter pattern for multi-LLM support |

### 1.3 Infrastructure

| Decision | Choice | Rationale |
|---|---|---|
| Hosting (API) | Railway or Render | Easy deployment from Replit; auto-scaling |
| Hosting (Python) | Railway (Docker) | Containerized statistical microservice |
| Database | Supabase Cloud | Managed PostgreSQL with built-in auth and realtime |
| File Storage | Supabase Storage | Temporary voice recordings (24hr TTL) |
| Cron Jobs | Supabase pg_cron + Edge Functions | Nightly bias analysis, daily heat map generation |
| CI/CD | Replit Deployments | Automatic deployment from Replit workspace |

### 1.4 External Service Dependencies

| Service | Purpose | Auth Method |
|---|---|---|
| Google Gemini API | LLM coaching provider | OAuth 2.0 |
| Anthropic Claude API | LLM coaching + bias analysis | API Key (backend) |
| OpenAI API | LLM coaching provider | OAuth 2.0 / API Key |
| Perplexity API | LLM research coaching | API Key (backend) |
| Microsoft Graph API | Outlook email/calendar | OAuth 2.0 (PKCE) |
| Google APIs | Gmail/Calendar | OAuth 2.0 |
| Apple Speech Framework | On-device transcription | Native (no auth) |

---

## 2. ARCHITECTURE DIAGRAMS

### 2.1 System Architecture (High-Level)

```
┌─────────────────────────────────────────────────────────────────────┐
│                        iOS APP (React Native / Expo)                │
│                                                                     │
│  ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐│
│  │Dashboard │ │Decisions │ │Coaching  │ │Sims      │ │Settings  ││
│  │Screen    │ │Stack     │ │Stack     │ │Stack     │ │Stack     ││
│  └────┬─────┘ └────┬─────┘ └────┬─────┘ └────┬─────┘ └────┬─────┘│
│       └──────────────┴──────────────┴──────────────┴──────────┘     │
│                              │                                      │
│                     React Query + Zustand                           │
│                              │                                      │
│                    expo-auth-session (OAuth)                         │
│                    expo-av (Voice Recording)                        │
│                    expo-secure-store (Tokens)                       │
└──────────────────────────────┬──────────────────────────────────────┘
                               │ HTTPS / REST
                               ▼
┌──────────────────────────────────────────────────────────────────────┐
│                     API GATEWAY (Express.js)                         │
│                                                                      │
│  ┌─────────────────┐  ┌──────────────────┐  ┌────────────────────┐ │
│  │ Auth Middleware  │  │ Shadow Layer     │  │ Rate Limiter       │ │
│  │ (Supabase JWT)  │  │ (Bias Interceptor│  │ (per-user quotas)  │ │
│  └────────┬────────┘  │  forks to Bias   │  └────────────────────┘ │
│           │           │  Engine async)   │                          │
│           │           └────────┬─────────┘                          │
│           ▼                    │                                     │
│  ┌────────────────┐           │           ┌──────────────────────┐ │
│  │ Route Handlers │           │           │ LLM Router Service   │ │
│  │ /decisions     │           │           │ ┌──────┐ ┌────────┐  │ │
│  │ /judgments     │           │           │ │Gemini│ │Claude  │  │ │
│  │ /simulations   │           │           │ │Adapt.│ │Adapter │  │ │
│  │ /coaching      │           │           │ └──────┘ └────────┘  │ │
│  │ /voice         │           │           │ ┌──────┐ ┌────────┐  │ │
│  │ /admin         │           │           │ │OpenAI│ │Perplx. │  │ │
│  └────────┬───────┘           │           │ │Adapt.│ │Adapter │  │ │
│           │                   │           │ └──────┘ └────────┘  │ │
│           │                   │           └──────────────────────┘ │
└───────────┼───────────────────┼──────────────────────────────────────┘
            │                   │
            ▼                   ▼
┌────────────────┐    ┌──────────────────┐    ┌────────────────────────┐
│   Supabase     │    │ Python Statistical│    │   Task Queue (BullMQ)  │
│   PostgreSQL   │    │ Microservice      │    │                        │
│   + pgvector   │    │ (FastAPI)         │    │ Jobs:                  │
│   + pg_cron    │    │                   │    │ - BiasAnalysis         │
│                │    │ - Monte Carlo     │    │ - SimulationRun        │
│ Tables:        │    │ - Noise Calc      │    │ - HeatMapGeneration    │
│ - users        │    │ - Variance Engine │    │ - NightlyPatternScan   │
│ - decisions    │    │ - Embedding Gen   │    │ - EmailMetadataExtract │
│ - judgments    │    │                   │    │                        │
│ - audit_log    │    └───────────────────┘    └────────────────────────┘
│ - simulations  │
│ - bias_profiles│
│ - coaching_log │
│ - email_context│
│ - voice_notes  │
│ - heatmap_cache│
└────────────────┘
```

### 2.2 Shadow Layer Data Flow

```
User submits decision
        │
        ▼
┌─────────────────┐
│ API Gateway      │
│ POST /decisions  │
│ /submit          │
└────────┬────────┘
         │
    ┌────┴────┐
    │  FORK   │
    └────┬────┘
         │
    ┌────┴─────────────────┐
    │                      │
    ▼                      ▼
┌──────────┐      ┌──────────────┐
│ Normal   │      │ Shadow Layer │
│ Response │      │ (Async)      │
│ to User  │      │              │
└──────────┘      │ 1. Bias Scan │
                  │ 2. Debate Gen│
                  │ 3. Pattern   │
                  │    Analysis  │
                  │ 4. AuditLog  │
                  │    Write     │
                  └──────────────┘
```

### 2.3 LLM Router Architecture

```
Coaching Request (user_id, message, context)
        │
        ▼
┌─────────────────────┐
│   LLM Router        │
│                     │
│ 1. Load user prefs  │
│ 2. Select adapter   │
│ 3. Inject context   │
│ 4. Route request    │
└────────┬────────────┘
         │
    ┌────┼────────────────────────────┐
    │    │         │         │        │
    ▼    ▼         ▼         ▼        ▼
┌──────┐┌──────┐┌──────┐┌──────┐┌──────┐
│Gemini││NbLM  ││Claude││GPT   ││Perp. │
│Adapt.││Adapt.││Adapt.││Adapt.││Adapt.│
└──────┘└──────┘└──────┘└──────┘└──────┘
    │        │       │       │       │
    └────────┴───────┴───────┴───────┘
                     │
                     ▼
            Standardized Response
            (text, sources, confidence)
```

---

## 3. FILE STRUCTURE (Replit Project)

```
the-steward/
├── app.json                          # Expo configuration
├── package.json                      # Dependencies
├── tsconfig.json                     # TypeScript config
├── babel.config.js                   # Babel config
├── .env.example                      # Environment variables template
│
├── docs/
│   ├── constitution.md               # Immutable Laws (THIS FILE WINS)
│   ├── spec.md                       # Functional specification
│   ├── plan.md                       # Technical plan (this file)
│   └── tasks.md                      # Granular build tasks
│
├── src/
│   ├── App.tsx                       # Root component
│   │
│   ├── navigation/
│   │   ├── RootNavigator.tsx         # Tab + Stack setup
│   │   ├── DecisionsStack.tsx
│   │   ├── CoachingStack.tsx
│   │   ├── SimulationsStack.tsx
│   │   ├── SettingsStack.tsx
│   │   └── AdminStack.tsx            # Role-gated
│   │
│   ├── screens/
│   │   ├── DashboardScreen.tsx
│   │   ├── DecisionListScreen.tsx
│   │   ├── DecisionDetailScreen.tsx
│   │   ├── BlindInputScreen.tsx
│   │   ├── GroupResultsScreen.tsx
│   │   ├── OutsideViewScreen.tsx
│   │   ├── PreMortemScreen.tsx
│   │   ├── CoachingChatScreen.tsx
│   │   ├── VoiceRecorderScreen.tsx
│   │   ├── CoachingHistoryScreen.tsx
│   │   ├── SimulationConfigScreen.tsx
│   │   ├── FutureConesScreen.tsx
│   │   ├── ProfileScreen.tsx
│   │   ├── LLMSettingsScreen.tsx
│   │   ├── DataIntegrationScreen.tsx
│   │   ├── PrivacySettingsScreen.tsx
│   │   ├── ExportDataScreen.tsx
│   │   ├── BiasHeatMapDashboard.tsx  # Board/Admin only
│   │   ├── AuditLogScreen.tsx        # Board/Admin only
│   │   ├── EpistemicHealthScreen.tsx  # Board/Admin only
│   │   ├── UserManagementScreen.tsx  # Admin only
│   │   └── SystemConfigScreen.tsx    # Admin only
│   │
│   ├── components/
│   │   ├── ui/
│   │   │   ├── Button.tsx
│   │   │   ├── Card.tsx
│   │   │   ├── Modal.tsx
│   │   │   ├── FrictionButton.tsx    # 3-second delay button
│   │   │   ├── UncertaintyBadge.tsx  # Orange warning for CI < 70%
│   │   │   └── ScrollGate.tsx        # Scroll-to-bottom gate
│   │   ├── charts/
│   │   │   ├── ScatterPlot.tsx       # Judgment variance
│   │   │   ├── HeatMap.tsx           # Bias heat map
│   │   │   ├── FutureCones.tsx       # Probability cones
│   │   │   ├── BurnRateGauge.tsx
│   │   │   └── InequalityRatio.tsx
│   │   ├── decisions/
│   │   │   ├── BlindInputForm.tsx
│   │   │   ├── VarianceDisplay.tsx
│   │   │   ├── OutsideViewCalculator.tsx
│   │   │   └── PreMortemInput.tsx
│   │   ├── coaching/
│   │   │   ├── ChatBubble.tsx
│   │   │   ├── LLMProviderPicker.tsx
│   │   │   └── CoachingContextCard.tsx
│   │   └── voice/
│   │       ├── VoiceRecorder.tsx
│   │       └── TranscriptViewer.tsx
│   │
│   ├── services/
│   │   ├── api.ts                    # Axios/fetch wrapper
│   │   ├── auth.ts                   # Supabase auth service
│   │   ├── decisions.ts              # Decision CRUD
│   │   ├── judgments.ts              # Judgment submission
│   │   ├── simulations.ts           # Simulation requests
│   │   ├── coaching.ts              # LLM coaching service
│   │   ├── llmRouter.ts             # Client-side LLM routing
│   │   ├── emailIntegration.ts      # Email OAuth + metadata
│   │   ├── calendarIntegration.ts   # Calendar OAuth + data
│   │   ├── voiceService.ts          # Recording + transcription
│   │   ├── biasHeatmap.ts           # Admin heat map data
│   │   └── exportService.ts         # Data export
│   │
│   ├── stores/
│   │   ├── authStore.ts             # Zustand: auth state
│   │   ├── decisionStore.ts         # Zustand: active decision
│   │   ├── settingsStore.ts         # Zustand: user settings
│   │   └── coachingStore.ts         # Zustand: coaching session
│   │
│   ├── hooks/
│   │   ├── useDecisions.ts          # React Query hook
│   │   ├── useJudgments.ts
│   │   ├── useSimulations.ts
│   │   ├── useCoaching.ts
│   │   ├── useBiasHeatmap.ts
│   │   ├── useVoiceRecorder.ts
│   │   └── useRoleGate.ts           # RBAC enforcement hook
│   │
│   ├── utils/
│   │   ├── crypto.ts                # SHA-256 hashing
│   │   ├── statistics.ts            # Client-side variance calc
│   │   ├── permissions.ts           # RBAC helper
│   │   ├── dateUtils.ts
│   │   └── constants.ts             # Colors, thresholds, config
│   │
│   ├── config/
│   │   ├── theme.ts                 # Design system tokens
│   │   ├── llmProviders.ts          # Provider configuration
│   │   └── oauthConfig.ts           # OAuth client IDs
│   │
│   └── types/
│       ├── index.ts                 # Shared TypeScript types
│       ├── decisions.ts
│       ├── coaching.ts
│       └── admin.ts
│
├── server/                           # Backend (deployed separately)
│   ├── package.json
│   ├── tsconfig.json
│   ├── src/
│   │   ├── index.ts                 # Express server entry
│   │   ├── middleware/
│   │   │   ├── auth.ts              # JWT validation
│   │   │   ├── shadowLayer.ts       # THE SHADOW LAYER
│   │   │   ├── roleGate.ts          # RBAC middleware
│   │   │   └── rateLimiter.ts
│   │   ├── routes/
│   │   │   ├── auth.ts
│   │   │   ├── decisions.ts
│   │   │   ├── judgments.ts
│   │   │   ├── simulations.ts
│   │   │   ├── coaching.ts
│   │   │   ├── voice.ts
│   │   │   ├── admin.ts
│   │   │   ├── settings.ts
│   │   │   ├── export.ts
│   │   │   └── public.ts            # Glass Wall API
│   │   ├── services/
│   │   │   ├── biasEngine.ts        # Bias detection logic
│   │   │   ├── llmRouter.ts         # Server-side LLM routing
│   │   │   ├── adapters/
│   │   │   │   ├── geminiAdapter.ts
│   │   │   │   ├── claudeAdapter.ts
│   │   │   │   ├── openaiAdapter.ts
│   │   │   │   ├── perplexityAdapter.ts
│   │   │   │   └── notebookLMAdapter.ts
│   │   │   ├── emailService.ts      # Email metadata extraction
│   │   │   ├── calendarService.ts
│   │   │   ├── heatmapGenerator.ts  # Daily heat map generation
│   │   │   └── auditService.ts
│   │   ├── jobs/
│   │   │   ├── nightlyBiasAnalysis.ts
│   │   │   ├── dailyHeatmapJob.ts
│   │   │   ├── emailSyncJob.ts
│   │   │   └── voiceCleanupJob.ts   # 24hr audio deletion
│   │   └── db/
│   │       ├── supabase.ts          # Supabase client
│   │       ├── migrations/          # SQL migration files
│   │       └── seed.ts              # Reference class seed data
│   └── Dockerfile
│
├── python-services/                  # Statistical microservice
│   ├── requirements.txt
│   ├── main.py                      # FastAPI entry
│   ├── services/
│   │   ├── monte_carlo.py           # Stochastic simulation
│   │   ├── variance_engine.py       # Noise calculations
│   │   ├── embedding_service.py     # Vector embedding generation
│   │   └── statistics.py            # General stat functions
│   └── Dockerfile
│
└── scripts/
    ├── setup.sh                     # Initial setup script
    ├── seed-reference-classes.sql   # Seed data for RCF
    └── generate-heatmap-test.py     # Test data generator
```

---

## 4. DEPLOYMENT STRATEGY

### 4.1 Replit Deployment Plan
1. **Frontend (React Native):** Replit Agent generates the Expo project. Preview via Expo Go QR code.
2. **Backend (Node.js):** Deployed as a Replit Deployment (Express server).
3. **Python Microservice:** Deployed as a separate Replit Deployment (Docker container).
4. **Database:** Supabase Cloud (external, free tier for pilot).
5. **Redis (Task Queue):** Upstash Redis (serverless, Replit-compatible).

### 4.2 Environment Variables (.env)
```
# Supabase
SUPABASE_URL=
SUPABASE_ANON_KEY=
SUPABASE_SERVICE_ROLE_KEY=

# LLM Providers
ANTHROPIC_API_KEY=
OPENAI_API_KEY=
GOOGLE_GEMINI_API_KEY=
PERPLEXITY_API_KEY=

# OAuth Client IDs
GOOGLE_OAUTH_CLIENT_ID=
OPENAI_OAUTH_CLIENT_ID=
MICROSOFT_OAUTH_CLIENT_ID=

# Redis (Task Queue)
REDIS_URL=

# Python Service
PYTHON_SERVICE_URL=

# App Config
NOISE_THRESHOLD=1.5
INEQUALITY_RATIO_THRESHOLD=5
BURN_RATE_BUFFER_MONTHS=6
CONFIDENCE_INTERVAL_THRESHOLD=0.7
HEAT_MAP_CRON_SCHEDULE=0 0 * * *
VOICE_RETENTION_HOURS=24
```

---

## 5. SECURITY ARCHITECTURE

### 5.1 Authentication Flow
```
User → Supabase Auth (email/password or OAuth) → JWT Token
JWT Token → Express middleware → Validate + Extract role
Role → RBAC middleware → Allow/Deny endpoint access
```

### 5.2 LLM API Key Security
- User OAuth tokens: Stored in `expo-secure-store` (iOS Keychain).
- Provider API keys: Encrypted with AES-256-GCM, stored in `user_settings.llm_credentials`.
- Decryption key: Environment variable on server, never transmitted to client.
- All LLM calls proxied through backend — client never directly contacts LLM APIs.

### 5.3 Data Privacy Pipeline
```
Email OAuth → Graph/Gmail API → Server extracts metadata →
LLM summarizes (50 words) → Summary stored → Raw data deleted (< 60s)
```

---

## 6. TESTING STRATEGY

### 6.1 Unit Tests
- Jest for component testing.
- Each constitutional Law must have at least one corresponding test.
- Example: Test that `BlindInputForm` prevents submission if `rationale_qual.length < 100`.

### 6.2 Integration Tests
- API endpoint tests for all routes.
- Shadow Layer verification: Confirm that every POST to `/decisions/submit` generates an `AuditLog` entry.

### 6.3 Constitutional Compliance Tests
- Automated tests that verify each Law is enforced:
  - Law 1: No screen renders a prediction without a confidence interval.
  - Law 2: Group results are inaccessible before all judgments submitted.
  - Law 3: Submit button is disabled without divergence justification.
  - Law 4: AuditLog entry exists for every decision submission.
  - Law 12: Heat map is inaccessible to STANDARD_USER role.

---

*Plan.md — The Steward v2.0 — Recursive SDD Framework for iOS*
*Architecture decisions locked. Ready for task decomposition.*
