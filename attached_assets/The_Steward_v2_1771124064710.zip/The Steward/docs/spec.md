# THE STEWARD — SPEC.md
## Functional Specification: Complete Module Breakdown
### Version 2.0 | iOS Native (React Native / Expo) | Recursive SDD Framework

> **Authority Level:** SUBORDINATE to constitution.md. This document translates the Laws into buildable features. Every feature must reference the specific Law(s) it implements.

> **Target Platform:** iOS via React Native (Expo managed workflow) deployed through Replit Agent.

> **Backend:** Node.js (Express) with Python microservices for statistical computation. Supabase (PostgreSQL + Auth + Realtime) as the primary data platform.

---

## 1. SYSTEM OVERVIEW

### 1.1 Application Identity
- **Name:** The Steward
- **Tagline:** "System 2 Governance for Mission-Critical Decisions"
- **Platform:** iOS 16+ (React Native / Expo)
- **Backend:** Node.js API Gateway + Python Statistical Microservices + Supabase
- **Architecture Pattern:** Event-driven microservices with a Shadow Layer middleware

### 1.2 User Personas
1. **Executive Director** — Makes strategic decisions, receives coaching nudges.
2. **Grant Committee Member** — Submits blind scores and rationales during decision rounds.
3. **Board Member** — Monitors organizational epistemic health via the Bias Heat Map and AuditLog.
4. **System Administrator** — Manages users, roles, system configuration, and monitors all dashboards.
5. **Auditor** — Read-only access to AuditLog, bias reports, and decision history.
6. **Beneficiary (Public)** — Read-only access to the Glass Wall transparency API.

---

## 2. MODULE 1: DECISION HYGIENE & NOISE AUDIT ENGINE
**Implements:** Law 1 (Epistemic Rigor), Law 2 (Noise Intolerance), Law 6 (Cognitive Sovereignty)

### 2.1 Feature: Noise Audit Protocol

#### 2.1.1 Blind Input Mode
- **Trigger:** A Decision Case (e.g., "Grant Application #1024") is opened for review.
- **UI Behavior:**
  - The system locks the "Group View" tab.
  - Each committee member sees an isolated input form.
  - Fields: `Quantitative Score` (1-10 slider), `Qualitative Rationale` (text area, min 100 characters).
  - Upon submission, the input is SHA-256 hashed and stored in the `Judgments` table.
  - The submit button shows a confirmation: "Your judgment has been sealed. It cannot be modified."
- **Blocking Logic:** The "View Group Results" button remains disabled and greyed out until `count(submitted) === count(assigned)` for that Decision Case.
- **React Native Component:** `<BlindInputForm decisionId={id} userId={uid} />`

#### 2.1.2 Information Cascade Block
- The system prevents any user from seeing scores, comments, or rationales of peers until ALL assigned committee members have submitted.
- The UI shows a progress indicator: "3 of 5 judgments submitted. Waiting for remaining members."
- No push notifications reveal individual scores.

#### 2.1.3 Variance Calculation Engine
- **Trigger:** Final judgment submitted for a Decision Case.
- **Calculations:**
  - Standard Deviation (σ) of `score_quant` values.
  - Mean (μ) of `score_quant` values.
  - Coefficient of Variation (CV = σ / μ).
- **Alert Threshold:** If σ > 1.5 (configurable), trigger "High Noise Alert."
- **UI Output:** Scatter plot (using `react-native-chart-kit` or `victory-native`) displaying the spread of judgments.
- **Alert UI:** Red banner: "High Disagreement Detected. Do not move to consensus until variance is explored."

#### 2.1.4 Semantic Divergence Analysis (False Consensus Detection)
- **Logic:**
  - Convert each `rationale_qual` text into a vector embedding via the selected LLM's embedding API (or a dedicated embedding service).
  - Calculate cosine similarity between rationales of users who gave similar quantitative scores (gap < 1).
  - If cosine similarity < 0.5, flag as "False Consensus."
- **Output UI:** Modal alert: "Consensus Illusion Detected: You agree on the score, but disagree on the reason. Reviewing conflict in reasoning is mandatory."
- **Storage:** Flag stored in `Judgments.hidden_bias_flags` as JSON.

### 2.2 Feature: Outside View Calculator (Reference Class Forecasting)
**Implements:** Law 3 (The Outside View)

#### 2.2.1 Trigger
- User enters a project budget or timeline estimate.

#### 2.2.2 Data Sources
- Internal historical projects database (`ReferenceClasses` table).
- External benchmarks (UK Treasury Green Book data, sector-specific databases configurable via admin).

#### 2.2.3 Logic Flow
1. **Reference Class Selection:** User selects category (e.g., "IT Migration," "Community Health Intervention," "Capital Construction").
2. **Base Rate Retrieval:** System retrieves `avg_cost_overrun`, `avg_time_overrun`, `base_rate_failure` for the selected class.
3. **Reality-Check Alert:** Modal interrupts workflow: "Historical data suggests a final cost of $X and time Y. Your estimate is Z% more optimistic than the Reference Class."
4. **Blocking Mechanism:** The "Submit" button is disabled.
5. **Unblock Requirement:** User must type a "Divergence Justification" (min 200 characters) citing validated distinctives.
- **React Native Component:** `<OutsideViewCalculator projectId={id} />`

### 2.3 Feature: Pre-Mortem Simulator
**Implements:** Law 1 (Epistemic Rigor), Law 5 (Outcome Binding)

- **Trigger:** Final approval stage of any strategic initiative valued over $50,000.
- **Prompt:** Mandatory text field: "The year is 2028. This mission has failed. The donor base has vanished, and beneficiaries are harmed. Write the history of this disaster."
- **Analysis:** LLM analyzes input for keywords: "Internal Failure" vs. "External Shocks." Classification stored in `RiskRegister` table.
- **Review Loop:** System resurfaces these narratives during quarterly reviews.

---

## 3. MODULE 2: THE "GOLIATH" RESILIENCE FRAMEWORK
**Implements:** Law 5 (Outcome Binding), Law 8 (Radical Transparency)

### 3.1 Feature: Inequality & Transparency Tracking

#### 3.1.1 Inequality Ratio (I_R)
- **Formula:** I_R = Highest Paid Compensation / Lowest Paid Compensation
- **Threshold:** If I_R > 5:1, trigger "Fragility Warning: Elite Capture Risk."
- **UI Action:** Executive dashboard background shifts to low-saturation red. Notification generated for Board Governance Committee.

#### 3.1.2 Radical Transparency API
- **Endpoint:** `/public/api/v1/resource-distribution`
- **Function:** Read-only, privacy-masked view of aggregated fund flows.
- **Authentication:** Public access for authenticated beneficiaries.
- **React Native Screen:** `<TransparencyDashboard />` (public-facing read-only view).

### 3.2 Feature: Institutional "Slack" Buffers

#### 3.2.1 Burn Rate Monitor
- **Inputs:** Current Cash Reserves (C), Monthly Burn Rate (B).
- **Runway Calculation:** R = C / B
- **Alert:** If R < 6 months, trigger "Critical Fragility Alert."
- **UI Component:** `<BurnRateGauge reserves={C} burnRate={B} />`

#### 3.2.2 Single Point of Failure (SPOF) Detector
- **Input:** Organizational Chart + Role Capability tags.
- **Logic:** For every "Critical Mission Function," count capable personnel.
- **Alert:** If count < 2, flag "SPOF Detected" (e.g., "Role 'Chief Architect' has no backup. Bus Factor = 1").

### 3.3 Feature: Goliath Fuel Mitigation (Data Minimization)
- **Scan:** Scheduled job audits Donor database for "Lootable Data."
- **Flag:** Excessive PII collection triggers: "Risk of Extraction: Excessive Data Collection Detected."
- **Recommendation:** Immediate deletion or hashing of unnecessary data.

---

## 4. MODULE 3: PREDICTIVE ARCHITECTURE & CHAOS LOGIC
**Implements:** Law 1 (Epistemic Rigor), Guardrail 3 (Constructive Noise Injection)

### 4.1 Feature: Stochastic Simulation Engine (Monte Carlo)
- **Engine:** Python microservice using `numpy` and `scipy`.
- **Input:** Project parameters (Budget, Timeline, Expected Impact).
- **Perturbation Scheme:**
  - Funding: ±10%
  - Regulatory Stability: ±5%
  - Staff Turnover: ±15%
- **Iterations:** Minimum 100 runs per simulation.
- **Output:** Probability Distribution with percentile markers (p5, p50, p95).
- **API Endpoint:** `POST /api/v1/simulations/run`
- **Response Schema:** `{ decision_id, run_count, p5_outcome, p50_outcome, p95_outcome, distribution_data[], perturbation_params }`

### 4.2 Feature: Future Scenario Cones (Visualization)
- **Render Logic:** Three cones rendered using `react-native-svg` or `victory-native`:
  1. **Attractor Cone (Median):** p50 — "status quo" trajectory.
  2. **Worst-Case Boundary ("Hell on Earth"):** p5 — funding collapse, mission failure.
  3. **High-Entropy Cone ("Butterfly Effect"):** p95 — non-linear mission expansion.
- **Design Rule:** Cones use opacity gradients to represent probability density.
- **React Native Component:** `<FutureScenarioCones simulationId={id} />`

---

## 5. MODULE 4: THE "SHADOW STEWARD" (Governance Backdoor & Bias Engine)
**Implements:** Law 4 (Governance Backdoor), Law 12 (Daily Bias Heat Map), Guardrail 1 (Shadow Layer)

### 5.1 Feature: Shadow Layer Architecture
- **Position:** Middleware interceptor at the API Gateway level.
- **Function:** Intercepts every POST request to `/decisions/submit`. Forks payload to BiasEngine asynchronously.
- **Isolation:** BiasEngine runs as a separate microservice. Processing latency does not affect user experience.

### 5.2 Feature: Bias Engine (LLM-Powered Analysis)

#### 5.2.1 The Debate Generator (Adversarial Processing)
- **Input:** User's proposed decision + written rationale.
- **Agentic Task:** LLM prompt: "Act as a skilled debater. Identify three logical fallacies or weak assumptions in this rationale. Generate a vigorous counter-argument."
- **Storage:** Counter-argument stored in `AuditLog.debate_counter_argument`.
- **Visibility:** Board Members and Auditors. Optionally pushed to user as "Devil's Advocate" prompt.

#### 5.2.2 Historical Decision Pattern Analyzer
- **Data:** User's past 50 decisions from `Decisions` table.
- **Analysis Patterns:**
  - **Sunk Cost Fallacy Detection:** Does the user consistently approve funding extensions for failing projects tagged 'Legacy'?
  - **Halo Effect Detection:** Does the user consistently rate proposals from specific directors higher than the group average?
  - **Recency Bias:** Does the user overweight the most recent quarterly data?
  - **Loss Aversion:** Does the user hold onto failing projects longer than statistical average?
- **Nightly Job:** Batch analysis runs on `Decisions` table, flags anomalies.

#### 5.2.3 Mind Map of Conflicts
- **Visualization:** Knowledge graph (node-link diagram) showing where current decision logic conflicts with the organization's Constitution or historical Reference Class data.
- **Library:** `react-native-graph` or custom `react-native-svg` rendering.

### 5.3 Feature: Coaching Backdoor Reporting
- **Target Audience:** Board of Directors / Oversight Committee.
- **Report:** Monthly "Epistemic Health Report" auto-generated.
- **Metrics:**
  - "Bias Load" — frequency of detected cognitive distortions.
  - "Divergence Score" — how often the leader ignores the Outside View.
  - "Noise Contribution" — variance this leader adds to committee decisions.
- **Coaching Nudges:** Real-time modals triggered by high "Anger/Certainty" sentiment + low data confidence.

### 5.4 Feature: Daily Bias Heat Map Report
**Implements:** Law 12 (Board Oversight Mandate)

- **Generation:** Background agent runs daily at midnight UTC.
- **Data Aggregation:** Queries all `AuditLog` entries from the past 24 hours.
- **Dimensions:**
  - X-axis: Bias type (Sunk Cost, Halo Effect, Anchoring, Confirmation, Recency, Loss Aversion, Optimism, Groupthink)
  - Y-axis: Decision category (Grant Allocation, Budget Approval, Strategic Planning, Personnel)
  - Color intensity: Severity count (Low=blue, Medium=green, High=orange, Critical=red)
- **Interactivity:** Tap any cell to drill down into specific decisions and users involved.
- **Access Control:** `role IN ('BOARD_MEMBER', 'SYSTEM_ADMIN', 'AUDITOR')` — enforced at both API and UI level.
- **React Native Screen:** `<BiasHeatMapDashboard />`
- **API Endpoint:** `GET /api/v1/admin/bias-heatmap?date=YYYY-MM-DD`

---

## 6. MODULE 5: GENERATIVE LEADERSHIP COACHING (LLM Integration)
**Implements:** Law 9 (LLM Provider Sovereignty), Law 6 (Cognitive Sovereignty)

### 6.1 Feature: Multi-LLM Router

#### 6.1.1 Supported Providers
| Provider | Model | Auth Method | Coaching Mode |
|---|---|---|---|
| Google Gemini | gemini-2.5-pro | OAuth 2.0 (Google Account) | Conversational coaching, structured analysis |
| Google NotebookLM | NotebookLM via Gemini | OAuth 2.0 (Google Account) | Document-grounded coaching, source synthesis |
| Anthropic Claude | claude-sonnet-4-5 | API Key (backend proxy) | Deep reasoning, adversarial debate generation |
| OpenAI ChatGPT | gpt-4.1 | OAuth 2.0 (OpenAI Account) | General coaching, brainstorming |
| Perplexity | sonar-pro | API Key (backend proxy) | Research-grounded coaching, citation-rich responses |

#### 6.1.2 LLM Selection UI
- **Screen:** `<LLMSettingsScreen />`
- **Components:**
  - Provider picker (dropdown with provider logos).
  - OAuth login buttons for Google and OpenAI.
  - API key input fields for Claude and Perplexity (stored encrypted on backend).
  - "Test Connection" button to validate credentials.
  - Default provider selector.
- **Persistence:** User preferences stored in `UserSettings` table.

#### 6.1.3 LLM Router Architecture
- **Backend Service:** `LLMRouterService` accepts a standardized `CoachingRequest` payload.
- **Routing Logic:** Based on `user.preferred_llm_provider`, routes to the appropriate provider adapter.
- **Adapter Pattern:** Each provider has an adapter implementing `ILLMAdapter` interface:
  ```
  interface ILLMAdapter {
    sendMessage(prompt: string, context: CoachingContext): Promise<CoachingResponse>
    getEmbedding(text: string): Promise<number[]>
    streamResponse(prompt: string, context: CoachingContext): AsyncGenerator<string>
  }
  ```
- **Fallback:** If the primary provider fails, the system attempts the next provider in the user's ranked preference list.

### 6.2 Feature: Generative Coaching Chat
- **Screen:** `<CoachingChatScreen />`
- **Behavior:**
  - Conversational interface with the selected LLM.
  - Context window includes: user's recent decisions, bias profile, noise contribution score, and (if opted-in) email/calendar summaries.
  - The LLM is system-prompted to act as a "Decision Hygiene Coach" — it must reference the user's specific bias patterns and provide actionable debiasing exercises.
  - All coaching conversations are logged to `CoachingLog` table for audit purposes.
- **System Prompt Template:**
  ```
  You are The Steward's Decision Hygiene Coach. Your role is to help the user
  improve their decision-making quality. You have access to the following context:

  - User's Bias Profile: {bias_profile}
  - Recent Noise Contribution Score: {noise_score}
  - Top Detected Biases: {detected_biases}
  - Recent Decision History: {decision_summary}
  - (Optional) Email/Calendar Context: {email_calendar_context}

  Your coaching must:
  1. Reference specific instances from the user's history.
  2. Suggest concrete debiasing exercises (e.g., "pre-mortem," "consider the opposite").
  3. Never make decisions for the user — only provide context and frameworks.
  4. Flag when the user's language suggests high certainty with low data confidence.
  ```

### 6.3 Feature: Direct LLM Login
- **OAuth Flows:**
  - Google: Standard OAuth 2.0 with `expo-auth-session` for Gemini/NotebookLM access.
  - OpenAI: OAuth 2.0 via OpenAI platform.
- **API Key Flows:**
  - Claude: User enters API key → encrypted → stored on backend → routed through proxy.
  - Perplexity: Same pattern as Claude.
- **Session Management:** OAuth tokens refreshed automatically. API keys encrypted with AES-256-GCM at rest.

---

## 7. MODULE 6: CONTEXTUAL DATA INTEGRATION (Email, Calendar, Voice)
**Implements:** Law 10 (Opt-In Data Integration), Law 11 (Voice Sovereignty)

### 7.1 Feature: Email Integration (Opt-In)

#### 7.1.1 Microsoft Outlook (Microsoft Graph API)
- **OAuth Scopes:** `Mail.Read`, `User.Read`, `Calendars.Read`, `offline_access`
- **Auth Flow:** PKCE-enhanced OAuth 2.0 via `expo-auth-session`.
- **Data Extraction Pipeline:**
  1. Fetch email metadata (sender, subject, date, labels) — NOT full body.
  2. For coaching-relevant emails (detected via keyword matching against user's active decisions), extract a 50-word summary using the user's selected LLM.
  3. Store summary in `EmailContext` table. Delete raw API response.
  4. Feed summaries into coaching context window.

#### 7.1.2 Gmail (Google API)
- **OAuth Scopes:** `gmail.readonly`, `gmail.labels`, `calendar.readonly`
- **Auth Flow:** Google Sign-In via `expo-auth-session`.
- **Data Extraction:** Same pipeline as Outlook.

#### 7.1.3 Proton Mail
- **Limitation:** Proton Mail Bridge does NOT support iOS natively.
- **Implementation:**
  - Display informational screen explaining the limitation.
  - Offer "Proton Mail Desktop Sync" — user runs Proton Bridge on desktop, which syncs metadata to The Steward's backend via a secure API endpoint.
  - Provide setup instructions within the app.
- **Fallback:** Manual note entry for Proton Mail users.

### 7.2 Feature: Calendar Integration (Opt-In)
- **Sources:** Microsoft Calendar (Graph API), Google Calendar (Calendar API).
- **Data Extracted:** Meeting titles, times, attendee counts, recurring meeting patterns.
- **Coaching Application:**
  - "You have 3 grant review meetings this week. Historical data shows your bias scores increase by 15% when you review more than 2 grants in a single day. Consider spacing them out."
  - Meeting preparation summaries generated by LLM.

### 7.3 Feature: Voice Notes & Conversation Recording (Opt-In)

#### 7.3.1 Recording
- **Technology:** `expo-av` for audio capture, Apple `SpeechAnalyzer` (via native module) for on-device transcription.
- **UI Component:** `<VoiceRecorder decisionId={id} />`
- **Behavior:**
  - Prominent red recording indicator.
  - Consent prompt: "Recording will begin. Ensure all parties are aware."
  - In two-party consent states (configurable): additional prompt "Have all participants been notified? [Yes / Cancel]"
  - Audio captured in `.m4a` format, encrypted at rest.

#### 7.3.2 Transcription
- **Primary:** On-device via Apple DictationTranscriber (formatted output).
- **Fallback (opt-in):** Cloud transcription via OpenAI Whisper API.
- **Output:** Transcribed text stored in `VoiceNotes` table, linked to decision context.
- **Retention:** Raw audio auto-deleted after 24 hours (configurable). Transcripts retained per data retention policy.

#### 7.3.3 Coaching Integration
- Transcripts fed into the coaching context window.
- LLM analyzes meeting transcripts for decision hygiene signals: "In your last meeting, the phrase 'we've always done it this way' appeared 4 times. This may indicate status quo bias."

---

## 8. MODULE 7: USER INTERFACE SPECIFICATION
**Implements:** Law 6 (Cognitive Sovereignty), Guardrail 2 (Epistemic Visualization)

### 8.1 Navigation Architecture (React Navigation)

```
TabNavigator
├── HomeStack
│   ├── DashboardScreen
│   ├── DecisionDetailScreen
│   └── PreMortemScreen
├── DecisionsStack
│   ├── DecisionListScreen
│   ├── BlindInputScreen
│   ├── GroupResultsScreen
│   └── OutsideViewScreen
├── CoachingStack
│   ├── CoachingChatScreen
│   ├── VoiceRecorderScreen
│   └── CoachingHistoryScreen
├── SimulationsStack
│   ├── SimulationConfigScreen
│   ├── FutureConesScreen
│   └── SimulationHistoryScreen
├── SettingsStack
│   ├── ProfileScreen
│   ├── LLMSettingsScreen
│   ├── DataIntegrationScreen (Email/Calendar/Voice opt-in)
│   ├── PrivacySettingsScreen
│   └── ExportDataScreen
└── AdminStack (BOARD_MEMBER + SYSTEM_ADMIN only)
    ├── BiasHeatMapDashboard
    ├── AuditLogScreen
    ├── EpistemicHealthReportScreen
    ├── UserManagementScreen (SYSTEM_ADMIN only)
    └── SystemConfigScreen (SYSTEM_ADMIN only)
```

### 8.2 Design System

#### 8.2.1 Color Palette
| Token | Hex | Usage |
|---|---|---|
| `primary` | #1E3A5F | Headers, primary actions |
| `secondary` | #4A90D9 | Secondary actions, links |
| `success` | #2ECC71 | Positive indicators, low bias |
| `warning` | #FF8C00 | Uncertainty Orange (Law 1) |
| `danger` | #E74C3C | High noise alerts, critical bias |
| `surface` | #F8F9FA | Card backgrounds |
| `text-primary` | #2C3E50 | Body text |
| `text-secondary` | #7F8C8D | Placeholder text |
| `heatmap-low` | #3498DB | Heat map — low severity |
| `heatmap-medium` | #2ECC71 | Heat map — medium |
| `heatmap-high` | #FF8C00 | Heat map — high |
| `heatmap-critical` | #E74C3C | Heat map — critical |

#### 8.2.2 Typography
- **System Font:** San Francisco (iOS native) via React Native defaults.
- **Heading 1:** 28pt Bold
- **Heading 2:** 22pt SemiBold
- **Body:** 16pt Regular
- **Caption:** 12pt Regular, `text-secondary`

#### 8.2.3 Friction-Full Design Principles
Per the Constitution's "System 2 Supremacy" mandate:
- No "quick approve" buttons. Every approval requires at minimum 2 taps and a rationale input.
- Mandatory 3-second delay on "Submit Decision" buttons with a countdown animation.
- Modals that present conflicting data cannot be dismissed without user action (no "X" button — must choose "Acknowledge" or "Review Data").
- Scroll-to-bottom requirement for long-form risk assessments before the "Continue" button activates.

---

## 9. DATA SCHEMA (Supabase / PostgreSQL)

### 9.1 Core Tables

```sql
-- Users & Authentication
CREATE TABLE users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email TEXT UNIQUE NOT NULL,
  full_name TEXT NOT NULL,
  role TEXT NOT NULL CHECK (role IN ('STANDARD_USER', 'COMMITTEE_MEMBER', 'BOARD_MEMBER', 'SYSTEM_ADMIN', 'AUDITOR')),
  prestige_score DECIMAL(5,2) DEFAULT 0,
  bias_profile_id UUID REFERENCES bias_profiles(id),
  noise_contribution_metric DECIMAL(5,2) DEFAULT 0,
  preferred_llm_provider TEXT DEFAULT 'claude',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Decisions (High-stakes choice events)
CREATE TABLE decisions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title TEXT NOT NULL,
  description TEXT,
  project_id UUID,
  status TEXT NOT NULL CHECK (status IN ('OPEN', 'IN_REVIEW', 'BLOCKED', 'APPROVED', 'REJECTED')),
  final_outcome TEXT,
  reference_class_id UUID REFERENCES reference_classes(id),
  value_amount DECIMAL(12,2),
  created_by UUID REFERENCES users(id),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Judgments (Individual blind inputs)
CREATE TABLE judgments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  decision_id UUID NOT NULL REFERENCES decisions(id),
  user_id UUID NOT NULL REFERENCES users(id),
  score_quant INTEGER NOT NULL CHECK (score_quant BETWEEN 1 AND 10),
  rationale_qual TEXT NOT NULL CHECK (char_length(rationale_qual) >= 100),
  hash_integrity TEXT NOT NULL, -- SHA-256 hash
  hidden_bias_flags JSONB DEFAULT '{}',
  vector_embedding VECTOR(1536), -- pgvector extension
  submitted_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(decision_id, user_id)
);

-- Reference Classes (Historical baselines)
CREATE TABLE reference_classes (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  category TEXT NOT NULL,
  description TEXT,
  avg_cost_overrun DECIMAL(5,2),
  avg_time_overrun DECIMAL(5,2),
  base_rate_failure DECIMAL(5,2),
  sample_size INTEGER,
  source TEXT,
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- AuditLog (The Shadow Layer)
CREATE TABLE audit_log (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  judgment_id UUID REFERENCES judgments(id),
  decision_id UUID REFERENCES decisions(id),
  user_id UUID REFERENCES users(id),
  detected_fallacies JSONB, -- [{type: "Sunk Cost", confidence: 0.85, evidence: "..."}]
  debate_counter_argument TEXT,
  bias_severity TEXT CHECK (bias_severity IN ('LOW', 'MEDIUM', 'HIGH', 'CRITICAL')),
  bias_category TEXT,
  decision_category TEXT CHECK (decision_category IN ('GRANT_ALLOCATION', 'BUDGET_APPROVAL', 'STRATEGIC_PLANNING', 'PERSONNEL')),
  hash_integrity_check TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Simulations (Chaos Engine outputs)
CREATE TABLE simulations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  decision_id UUID NOT NULL REFERENCES decisions(id),
  run_count INTEGER NOT NULL DEFAULT 100,
  p5_outcome JSONB,
  p50_outcome JSONB,
  p95_outcome JSONB,
  distribution_data JSONB,
  perturbation_params JSONB,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Bias Profiles
CREATE TABLE bias_profiles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id),
  sunk_cost_score DECIMAL(5,2) DEFAULT 0,
  halo_effect_score DECIMAL(5,2) DEFAULT 0,
  anchoring_score DECIMAL(5,2) DEFAULT 0,
  confirmation_bias_score DECIMAL(5,2) DEFAULT 0,
  recency_bias_score DECIMAL(5,2) DEFAULT 0,
  loss_aversion_score DECIMAL(5,2) DEFAULT 0,
  optimism_bias_score DECIMAL(5,2) DEFAULT 0,
  groupthink_score DECIMAL(5,2) DEFAULT 0,
  overall_bias_load DECIMAL(5,2) DEFAULT 0,
  last_updated TIMESTAMPTZ DEFAULT NOW()
);

-- Coaching Log
CREATE TABLE coaching_log (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id),
  llm_provider TEXT NOT NULL,
  prompt_summary TEXT,
  response_summary TEXT,
  context_sources JSONB, -- ["bias_profile", "email_context", "calendar_context"]
  session_duration_seconds INTEGER,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Email Context (extracted metadata only)
CREATE TABLE email_context (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id),
  provider TEXT NOT NULL CHECK (provider IN ('outlook', 'gmail', 'proton')),
  email_summary TEXT NOT NULL, -- LLM-generated 50-word summary
  relevance_score DECIMAL(3,2),
  decision_id UUID REFERENCES decisions(id),
  extracted_at TIMESTAMPTZ DEFAULT NOW(),
  expires_at TIMESTAMPTZ DEFAULT NOW() + INTERVAL '30 days'
);

-- Calendar Context
CREATE TABLE calendar_context (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id),
  provider TEXT NOT NULL CHECK (provider IN ('outlook', 'google')),
  meeting_title TEXT,
  meeting_date TIMESTAMPTZ,
  attendee_count INTEGER,
  is_recurring BOOLEAN DEFAULT FALSE,
  coaching_signal TEXT, -- LLM-generated insight
  extracted_at TIMESTAMPTZ DEFAULT NOW()
);

-- Voice Notes
CREATE TABLE voice_notes (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id),
  decision_id UUID REFERENCES decisions(id),
  transcript TEXT NOT NULL,
  duration_seconds INTEGER,
  consent_recorded BOOLEAN NOT NULL DEFAULT TRUE,
  two_party_consent BOOLEAN DEFAULT FALSE,
  audio_file_path TEXT, -- temporary, auto-deleted after 24h
  audio_expires_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Daily Bias Heat Map Cache
CREATE TABLE bias_heatmap_cache (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  report_date DATE NOT NULL UNIQUE,
  heatmap_data JSONB NOT NULL, -- {matrix: [[]], labels: {x: [], y: []}, drilldown: {}}
  total_detections INTEGER,
  critical_count INTEGER,
  generated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Risk Register (Pre-Mortem narratives)
CREATE TABLE risk_register (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  decision_id UUID NOT NULL REFERENCES decisions(id),
  narrative TEXT NOT NULL,
  failure_classification TEXT CHECK (failure_classification IN ('INTERNAL_FAILURE', 'EXTERNAL_SHOCK', 'MIXED')),
  created_by UUID REFERENCES users(id),
  reviewed_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- User Settings (LLM preferences, integrations)
CREATE TABLE user_settings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL UNIQUE REFERENCES users(id),
  preferred_llm TEXT DEFAULT 'claude',
  llm_credentials JSONB DEFAULT '{}', -- encrypted
  email_integration_enabled BOOLEAN DEFAULT FALSE,
  email_providers JSONB DEFAULT '[]',
  calendar_integration_enabled BOOLEAN DEFAULT FALSE,
  calendar_providers JSONB DEFAULT '[]',
  voice_recording_enabled BOOLEAN DEFAULT FALSE,
  voice_cloud_transcription BOOLEAN DEFAULT FALSE,
  two_party_consent_jurisdiction BOOLEAN DEFAULT FALSE,
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Organizational Config
CREATE TABLE org_config (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  key TEXT UNIQUE NOT NULL,
  value JSONB NOT NULL,
  description TEXT,
  updated_by UUID REFERENCES users(id),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);
```

### 9.2 Database Extensions Required
- `pgvector` — for vector embedding storage and cosine similarity search.
- `pg_cron` — for scheduling nightly bias analysis and daily heat map generation.

---

## 10. AGENTIC WORKFLOW (Background Agents)

### 10.1 Agent 1: The Auditor
- **Trigger:** New record in `Judgments` table.
- **Actions:**
  1. Generate vector embedding from `rationale_qual`.
  2. Run semantic similarity against other judgments for the same decision.
  3. Flag False Consensus if cosine similarity < 0.5 with similar scores.
  4. Update `AuditLog` with bias flags.

### 10.2 Agent 2: The Forecaster
- **Trigger:** Decision status changes to `IN_REVIEW`.
- **Actions:**
  1. Retrieve Reference Class data.
  2. Trigger Monte Carlo simulation (100 runs).
  3. Store results in `Simulations` table.
  4. Generate Future Scenario Cones data.

### 10.3 Agent 3: The Steward (UI Enforcer)
- **Trigger:** User interaction with decision workflows.
- **Actions:**
  1. Enforce blocking mechanisms (Outside View, Pre-Mortem).
  2. Check Reference Class compliance.
  3. Manage submission state machine (OPEN → IN_REVIEW → BLOCKED/APPROVED/REJECTED).

### 10.4 Agent 4: The Shadow (Bias Engine)
- **Trigger:** Any POST to `/decisions/submit`.
- **Actions:**
  1. Fork payload to BiasEngine.
  2. Run adversarial debate generation.
  3. Run historical pattern analysis (nightly batch).
  4. Generate coaching nudges.
  5. Update `bias_profiles` table.

### 10.5 Agent 5: The Reporter (Heat Map Generator)
- **Trigger:** Daily cron job at midnight UTC.
- **Actions:**
  1. Query all `AuditLog` entries from past 24 hours.
  2. Aggregate by bias_type × decision_category × severity.
  3. Generate heat map matrix data.
  4. Cache in `bias_heatmap_cache` table.
  5. Send push notification to Board Members: "Daily Bias Report is ready."

---

## 11. API ENDPOINT SUMMARY

| Method | Endpoint | Auth | Description |
|---|---|---|---|
| POST | /api/v1/auth/login | Public | Authenticate user |
| POST | /api/v1/auth/register | Admin | Create new user |
| GET | /api/v1/decisions | User | List decisions |
| POST | /api/v1/decisions | User | Create decision |
| GET | /api/v1/decisions/:id | User | Get decision detail |
| POST | /api/v1/judgments | User | Submit blind judgment |
| GET | /api/v1/judgments/:decisionId | User | Get group results (post-submission only) |
| POST | /api/v1/simulations/run | Committee+ | Run Monte Carlo simulation |
| GET | /api/v1/simulations/:decisionId | Committee+ | Get simulation results |
| GET | /api/v1/reference-classes | User | List reference classes |
| POST | /api/v1/coaching/chat | User | Send coaching message |
| GET | /api/v1/coaching/history | User | Get coaching history |
| POST | /api/v1/voice/upload | User | Upload voice transcript |
| GET | /api/v1/admin/bias-heatmap | Board+ | Get daily bias heat map |
| GET | /api/v1/admin/audit-log | Board+ | Get audit log entries |
| GET | /api/v1/admin/epistemic-report | Board+ | Get epistemic health report |
| GET | /api/v1/admin/users | Admin | List/manage users |
| PUT | /api/v1/settings | User | Update user settings |
| GET | /api/v1/export/:format | User | Export data (CSV/JSON/PDF) |
| GET | /public/api/v1/resource-distribution | Public | Glass Wall transparency endpoint |

---

*Spec.md — The Steward v2.0 — Recursive SDD Framework for iOS*
*All features traceable to Constitution Laws 1-12*
