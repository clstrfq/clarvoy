# THE STEWARD — TASKS.md
## Granular Build Task Breakdown
### Version 2.0 | iOS Native (React Native / Expo) | Recursive SDD Framework

> **Authority Level:** SUBORDINATE to constitution.md, spec.md, and plan.md. Each task is a self-contained unit of work (30-60 minutes) with sufficient context for autonomous execution by the Replit AI Agent.

> **Execution Rule:** Tasks MUST be executed in order within each phase. Phases may run in parallel where noted. After completing each task, the agent must validate against the Constitution before proceeding.

---

## PHASE 0: PROJECT SCAFFOLDING & CONFIGURATION
*Estimated: 2 hours | Dependency: None*

### Task 0.1: Initialize Expo Project
- **Command:** `npx create-expo-app the-steward --template blank-typescript`
- **Post-Setup:** Add to `app.json`: app name "The Steward", bundleIdentifier, iOS config.
- **Validation:** `npx expo start` runs without errors.

### Task 0.2: Install Frontend Dependencies
```bash
npx expo install react-native-svg victory-native @react-navigation/native @react-navigation/native-stack @react-navigation/bottom-tabs react-native-screens react-native-safe-area-context expo-auth-session expo-av expo-secure-store expo-crypto react-native-reanimated react-native-gesture-handler
npm install zustand @tanstack/react-query react-hook-form zod @hookform/resolvers axios date-fns
npm install -D @types/react-native
```
- **Validation:** All packages resolve. No peer dependency conflicts.

### Task 0.3: Configure TypeScript & Project Structure
- Create all directories per `plan.md` file structure.
- Create `tsconfig.json` with strict mode, path aliases (`@/` → `src/`).
- Create `src/types/index.ts` with all TypeScript interfaces from spec.md schema.
- **Validation:** `npx tsc --noEmit` passes.

### Task 0.4: Setup Design System
- Create `src/config/theme.ts` with all color tokens from spec.md Section 8.2.
- Create `src/config/constants.ts` with all threshold values from constitution.md Part V.
- Create base UI components: `Button`, `Card`, `Modal` in `src/components/ui/`.
- **Validation:** Components render without errors.

### Task 0.5: Initialize Backend Server
- Create `server/` directory with `package.json`.
- Install: `express`, `cors`, `helmet`, `@supabase/supabase-js`, `bullmq`, `ioredis`, `jsonwebtoken`, `express-rate-limit`, `zod`.
- Create `server/src/index.ts` with Express server, CORS, helmet, basic health endpoint.
- **Validation:** `GET /health` returns `{ status: "ok" }`.

### Task 0.6: Initialize Python Statistical Microservice
- Create `python-services/` directory.
- Create `requirements.txt`: `fastapi`, `uvicorn`, `numpy`, `scipy`, `pandas`, `pydantic`.
- Create `main.py` with FastAPI server, health endpoint.
- **Validation:** `GET /health` returns `{ status: "ok" }`.

### Task 0.7: Setup Supabase Database
- Create Supabase project (or configure connection).
- Run all SQL from spec.md Section 9.1 as migration.
- Enable `pgvector` extension.
- Create RLS (Row Level Security) policies per RBAC matrix.
- Seed `reference_classes` table with initial data.
- **Validation:** All tables exist. RLS policies active.

### Task 0.8: Configure Environment Variables
- Create `.env.example` with all variables from plan.md Section 4.2.
- Create `.env` with placeholder values.
- Configure Supabase client in `server/src/db/supabase.ts`.
- **Validation:** Supabase client connects successfully.

---

## PHASE 1: AUTHENTICATION & NAVIGATION
*Estimated: 3 hours | Dependency: Phase 0*

### Task 1.1: Implement Supabase Authentication
- Create `src/services/auth.ts` with login, logout, register, getSession.
- Create `src/stores/authStore.ts` (Zustand) with user state, role, isAuthenticated.
- Integrate `@supabase/supabase-js` client in frontend.
- **Validation:** User can sign up, sign in, sign out.

### Task 1.2: Build Auth Screens
- Create `LoginScreen.tsx` with email/password form.
- Create `RegisterScreen.tsx` (admin-initiated, per spec).
- Handle auth state persistence with `expo-secure-store`.
- **Validation:** Full auth flow works end-to-end.

### Task 1.3: Implement Navigation Architecture
- Create `RootNavigator.tsx` with Bottom Tab Navigator (5 tabs per spec Section 8.1).
- Create all Stack Navigators per plan.md file structure.
- Implement `useRoleGate.ts` hook — restricts AdminStack to BOARD_MEMBER/SYSTEM_ADMIN.
- **Validation:** All tabs render. AdminStack hidden for STANDARD_USER.

### Task 1.4: Build Auth Middleware (Backend)
- Create `server/src/middleware/auth.ts` — validates Supabase JWT from Authorization header.
- Create `server/src/middleware/roleGate.ts` — checks user role against endpoint requirements.
- **Validation:** Protected endpoints return 401 without token, 403 without role.

---

## PHASE 2: DECISION HYGIENE & NOISE AUDIT ENGINE (Module 1)
*Estimated: 6 hours | Dependency: Phase 1*

### Task 2.1: Decision CRUD
- Create `server/src/routes/decisions.ts` — GET list, POST create, GET detail.
- Create `src/services/decisions.ts` — API client.
- Create `src/hooks/useDecisions.ts` — React Query hooks.
- Create `DecisionListScreen.tsx` and `DecisionDetailScreen.tsx`.
- **Validation:** Can create and list decisions.

### Task 2.2: Blind Input Mode (Law 2)
- Create `BlindInputForm.tsx` component:
  - Score slider (1-10) with haptic feedback.
  - Rationale text area with character counter (min 100 chars, enforced by Zod).
  - SHA-256 hash generation using `expo-crypto`.
  - Submit button disabled until all validation passes.
- Create `server/src/routes/judgments.ts` — POST submit (validates hash, stores to DB).
- **CONSTITUTIONAL CHECK:** Verify no score data leaks before all submissions complete.
- **Validation:** Judgment stored with hash. Cannot view others' scores.

### Task 2.3: Information Cascade Block (Law 2)
- Implement submission counting logic in `server/src/routes/judgments.ts`.
- `GET /judgments/:decisionId` returns results ONLY when `count(submitted) === count(assigned)`.
- Frontend: `GroupResultsScreen.tsx` shows "Waiting for X more judgments" or unlocked results.
- **Validation:** Results hidden until all submissions complete.

### Task 2.4: Variance Calculation Engine
- Create `python-services/services/variance_engine.py`:
  - Input: Array of scores.
  - Output: `{ mean, std_dev, cv, is_high_noise }`.
  - Threshold: `std_dev > NOISE_THRESHOLD` (default 1.5).
- Create `ScatterPlot.tsx` using Victory Native.
- Integrate variance results into `GroupResultsScreen.tsx`.
- **Validation:** Scatter plot renders. High noise alert triggers when σ > 1.5.

### Task 2.5: Semantic Divergence Analysis (False Consensus)
- Create `python-services/services/embedding_service.py`:
  - Generates vector embeddings via LLM embedding API.
  - Stores in `judgments.vector_embedding` (pgvector).
- Create cosine similarity comparison logic.
- Flag False Consensus when scores within 1 point but cosine similarity < 0.5.
- **Validation:** False Consensus flag appears in AuditLog.

### Task 2.6: Outside View Calculator (Law 3)
- Create `OutsideViewCalculator.tsx` component:
  - Reference class dropdown (from `reference_classes` table).
  - Reality-check modal with historical data comparison.
  - Submit button DISABLED until divergence justification entered (min 200 chars).
- Create `OutsideViewScreen.tsx` integrating the calculator.
- **CONSTITUTIONAL CHECK:** Submit physically impossible without justification.
- **Validation:** Cannot submit without justification when estimate deviates from reference class.

### Task 2.7: Pre-Mortem Simulator
- Create `PreMortemScreen.tsx`:
  - Mandatory text field with prompt: "The year is 2028. This mission has failed..."
  - LLM analysis classifies failure as INTERNAL_FAILURE vs. EXTERNAL_SHOCK.
  - Stored in `risk_register` table.
- Trigger: Only for decisions with `value_amount > 50000`.
- **Validation:** Pre-mortem required for high-value decisions.

---

## PHASE 3: GOLIATH RESILIENCE FRAMEWORK (Module 2)
*Estimated: 3 hours | Dependency: Phase 1*

### Task 3.1: Inequality Ratio Tracker
- Create `InequalityRatio.tsx` component:
  - Displays I_R = Max Compensation / Min Compensation.
  - Background shifts to low-saturation red when I_R > 5.
- Create admin endpoint to input compensation data.
- **Validation:** Alert triggers at I_R > 5.

### Task 3.2: Burn Rate Monitor
- Create `BurnRateGauge.tsx` component:
  - Inputs: Cash reserves (C), Monthly burn rate (B).
  - Display: Runway (R = C/B) as gauge visualization.
  - Alert: "Critical Fragility Alert" when R < 6 months.
- **Validation:** Alert triggers when runway < 6.

### Task 3.3: SPOF Detector
- Create organizational chart input interface.
- Logic: Count capable personnel per Critical Mission Function.
- Alert when count < 2 for any function.
- **Validation:** SPOF alert fires correctly.

### Task 3.4: Data Minimization Scanner
- Create scheduled job in `server/src/jobs/` that audits donor table for lootable data.
- Flag excessive PII fields.
- **Validation:** Scanner identifies test PII data.

### Task 3.5: Radical Transparency API (Law 8)
- Create `server/src/routes/public.ts`:
  - `GET /public/api/v1/resource-distribution` — returns privacy-masked fund flows.
- No authentication required (public endpoint).
- Create `TransparencyDashboard.tsx` screen.
- **Validation:** Public endpoint returns aggregated data without PII.

---

## PHASE 4: THE SHADOW STEWARD & BIAS ENGINE (Module 4)
*Estimated: 5 hours | Dependency: Phase 2*
*THIS IS THE GOVERNANCE BACKDOOR — Constitution Law 4*

### Task 4.1: Shadow Layer Middleware
- Create `server/src/middleware/shadowLayer.ts`:
  - Intercepts ALL POST requests to `/decisions/submit` and `/judgments`.
  - Forks payload asynchronously to BiasEngine.
  - Does NOT block the main response.
- **CONSTITUTIONAL CHECK:** Verify middleware cannot be disabled by any route handler.
- **Validation:** Every judgment submission creates an AuditLog entry.

### Task 4.2: Bias Engine — Debate Generator
- Create `server/src/services/biasEngine.ts`:
  - `generateDebate(rationale: string): Promise<string>` — uses LLM to generate counter-argument.
  - System prompt: "Identify three logical fallacies. Generate a vigorous counter-argument."
- Store counter-argument in `audit_log.debate_counter_argument`.
- **Validation:** Counter-arguments generated and stored.

### Task 4.3: Bias Engine — Historical Pattern Analyzer
- Create `server/src/jobs/nightlyBiasAnalysis.ts`:
  - Queries user's past 50 decisions.
  - Detects: Sunk Cost, Halo Effect, Recency Bias, Loss Aversion patterns.
  - Updates `bias_profiles` table.
- Schedule via BullMQ recurring job (nightly at 2 AM UTC).
- **Validation:** Bias profiles update after nightly run.

### Task 4.4: Coaching Nudges (Real-time)
- Create sentiment analysis check in BiasEngine:
  - Detect "Anger" or "Certainty" markers + low data confidence.
  - Trigger soft modal: "Decision Hygiene Alert: Your rationale uses high-certainty language despite low data confidence."
- **Validation:** Nudge triggers on test input.

### Task 4.5: Daily Bias Heat Map Generator (Law 12)
- Create `server/src/jobs/dailyHeatmapJob.ts`:
  - Queries `audit_log` for past 24 hours.
  - Aggregates: bias_type × decision_category × severity.
  - Generates heat map matrix.
  - Caches in `bias_heatmap_cache` table.
- Create `server/src/services/heatmapGenerator.ts` with matrix generation logic.
- Schedule via BullMQ (midnight UTC daily).
- **Validation:** Heat map cache populated with correct matrix.

### Task 4.6: Bias Heat Map Dashboard UI
- Create `BiasHeatMapDashboard.tsx`:
  - Renders heat map using Victory Native or custom SVG.
  - Color scale: blue (low) → green (medium) → orange (high) → red (critical).
  - Tap-to-drill-down on any cell.
  - Date picker to view historical reports.
- **CONSTITUTIONAL CHECK:** Screen only renders for BOARD_MEMBER or SYSTEM_ADMIN.
- Create `src/hooks/useBiasHeatmap.ts` — React Query hook with role check.
- **Validation:** Heat map renders correctly. Inaccessible to STANDARD_USER.

### Task 4.7: AuditLog & Epistemic Health Screens
- Create `AuditLogScreen.tsx` — paginated list of all AuditLog entries.
- Create `EpistemicHealthScreen.tsx` — monthly report with Bias Load, Divergence Score, Noise Contribution per user.
- Role-gated to BOARD_MEMBER + SYSTEM_ADMIN + AUDITOR.
- **Validation:** Reports render correctly with test data.

---

## PHASE 5: PREDICTIVE ARCHITECTURE & CHAOS LOGIC (Module 3)
*Estimated: 3 hours | Dependency: Phase 2, Phase 0.6*

### Task 5.1: Monte Carlo Simulation Engine
- Implement `python-services/services/monte_carlo.py`:
  - Input: `{ budget, timeline, impact, perturbation_params }`.
  - Perturbation: Funding ±10%, Regulatory ±5%, Staff Turnover ±15%.
  - Iterations: 100 minimum.
  - Output: `{ p5, p50, p95, distribution_data[] }`.
- Create FastAPI endpoint: `POST /simulations/run`.
- **Validation:** Returns valid distribution with 100 data points.

### Task 5.2: Simulation API Integration
- Create `server/src/routes/simulations.ts`:
  - `POST /api/v1/simulations/run` — proxies to Python service.
  - `GET /api/v1/simulations/:decisionId` — retrieves cached results.
- Create `src/services/simulations.ts` — API client.
- **Validation:** End-to-end simulation request works.

### Task 5.3: Future Scenario Cones Visualization
- Create `FutureCones.tsx` component:
  - Three cones: Attractor (p50), Worst-Case (p5), High-Entropy (p95).
  - Opacity gradients representing probability density.
  - Built with `react-native-svg`.
- Create `FutureConesScreen.tsx` integrating simulation data.
- **CONSTITUTIONAL CHECK:** No cone renders without confidence interval (Law 1).
- **Validation:** Cones render correctly from simulation data.

### Task 5.4: Simulation Configuration Screen
- Create `SimulationConfigScreen.tsx`:
  - Parameter inputs for budget, timeline, impact.
  - Perturbation controls (sliders for ±%).
  - Run count selector (100, 500, 1000).
  - "Run Simulation" button triggers Python service.
- **Validation:** User can configure and run simulations.

---

## PHASE 6: GENERATIVE LEADERSHIP COACHING — LLM Integration (Module 5)
*Estimated: 5 hours | Dependency: Phase 4*

### Task 6.1: LLM Router Service (Backend)
- Create `server/src/services/llmRouter.ts`:
  - `ILLMAdapter` interface: `sendMessage`, `getEmbedding`, `streamResponse`.
  - Router selects adapter based on user's `preferred_llm_provider`.
  - Fallback logic if primary provider fails.
- **Validation:** Router correctly dispatches to adapters.

### Task 6.2: LLM Provider Adapters
- Create adapters in `server/src/services/adapters/`:
  - `geminiAdapter.ts` — Google Gemini API integration.
  - `claudeAdapter.ts` — Anthropic Claude API integration.
  - `openaiAdapter.ts` — OpenAI ChatGPT API integration.
  - `perplexityAdapter.ts` — Perplexity API integration.
  - `notebookLMAdapter.ts` — Google NotebookLM via Gemini API.
- Each adapter implements `ILLMAdapter` interface.
- **Validation:** Each adapter returns valid responses.

### Task 6.3: Coaching Chat API
- Create `server/src/routes/coaching.ts`:
  - `POST /api/v1/coaching/chat` — accepts message, returns LLM response with context.
  - Injects coaching system prompt from spec.md Section 6.2.
  - Includes user's bias profile, noise score, recent decisions in context.
  - Logs to `coaching_log` table.
- **Validation:** Full coaching conversation works end-to-end.

### Task 6.4: Coaching Chat UI
- Create `CoachingChatScreen.tsx`:
  - Chat interface with message bubbles.
  - Provider indicator showing current LLM.
  - Context card showing what data informs the coaching.
  - Streaming response support.
- Create `ChatBubble.tsx`, `CoachingContextCard.tsx` components.
- **Validation:** Conversational coaching works with selected LLM.

### Task 6.5: LLM Settings Screen
- Create `LLMSettingsScreen.tsx`:
  - Provider picker with logos.
  - OAuth login buttons for Google (Gemini) and OpenAI.
  - API key input for Claude and Perplexity.
  - "Test Connection" button.
  - Default provider selector.
- Integrate `expo-auth-session` for OAuth flows.
- Store preferences in `user_settings` table.
- **Validation:** User can select, authenticate, and switch LLM providers.

### Task 6.6: Direct LLM Login (OAuth)
- Implement Google OAuth flow via `expo-auth-session` for Gemini access.
- Implement OpenAI OAuth flow.
- API key encryption for Claude/Perplexity (AES-256-GCM on backend).
- Token refresh logic for OAuth providers.
- **Validation:** OAuth tokens stored securely. API keys encrypted at rest.

---

## PHASE 7: CONTEXTUAL DATA INTEGRATION (Module 6)
*Estimated: 4 hours | Dependency: Phase 6*

### Task 7.1: Email Integration — Outlook (Microsoft Graph)
- Create `server/src/services/emailService.ts`:
  - Microsoft Graph OAuth (PKCE) via `expo-auth-session`.
  - Scopes: `Mail.Read`, `User.Read`, `Calendars.Read`, `offline_access`.
  - Fetch email metadata (sender, subject, date).
  - LLM-summarize relevant emails (50 words).
  - Store in `email_context` table. Delete raw data.
- **Validation:** Email metadata extracted and summarized.

### Task 7.2: Email Integration — Gmail (Google API)
- Add Gmail scopes to existing Google OAuth: `gmail.readonly`, `gmail.labels`.
- Implement same metadata extraction pipeline as Outlook.
- **Validation:** Gmail metadata extracted and summarized.

### Task 7.3: Email Integration — Proton Mail (Limitation Handling)
- Create informational screen in `DataIntegrationScreen.tsx` explaining Proton Bridge limitation.
- Offer manual note entry fallback for Proton Mail users.
- Optional: Provide desktop sync setup instructions.
- **Validation:** Proton section displays informational content, not broken flow.

### Task 7.4: Calendar Integration
- Implement Microsoft Calendar via Graph API (scopes already requested in Task 7.1).
- Implement Google Calendar via `calendar.readonly` scope.
- Extract: meeting titles, times, attendee counts, recurring patterns.
- Generate coaching signals: "You have X meetings this week. History shows bias increases after Y reviews in one day."
- Store in `calendar_context` table.
- **Validation:** Calendar data extracted and coaching signals generated.

### Task 7.5: Data Integration Settings UI
- Create `DataIntegrationScreen.tsx`:
  - Toggle switches for each provider (Outlook, Gmail, Proton, Google Calendar, Microsoft Calendar).
  - Clear disclosure of what data is accessed.
  - Consent dialogs per Law 10.
  - "Disconnect" buttons for each provider.
- **Validation:** User can opt-in/out of each integration independently.

### Task 7.6: Voice Recording
- Create `VoiceRecorder.tsx` component using `expo-av`:
  - Red recording indicator.
  - Consent prompt before recording starts.
  - Two-party consent prompt (configurable).
  - .m4a format, encrypted at rest.
- Create `src/services/voiceService.ts` for recording management.
- **Validation:** Audio records and plays back correctly.

### Task 7.7: Voice Transcription
- Implement on-device transcription via native module bridge to Apple Speech framework.
- Fallback: Cloud transcription via OpenAI Whisper (opt-in only).
- Store transcripts in `voice_notes` table.
- Create `TranscriptViewer.tsx` component.
- **Validation:** Speech transcribed to text accurately.

### Task 7.8: Voice Cleanup Job
- Create `server/src/jobs/voiceCleanupJob.ts`:
  - Runs hourly.
  - Deletes audio files older than 24 hours (`audio_expires_at`).
- **Validation:** Old audio files automatically removed.

---

## PHASE 8: ADMIN & BOARD FEATURES
*Estimated: 3 hours | Dependency: Phase 4*

### Task 8.1: User Management Screen
- Create `UserManagementScreen.tsx` (SYSTEM_ADMIN only):
  - List all users with roles.
  - Change user roles.
  - Deactivate users.
  - View user bias profiles.
- **Validation:** Admin can manage users. Non-admins cannot access.

### Task 8.2: System Configuration Screen
- Create `SystemConfigScreen.tsx` (SYSTEM_ADMIN only):
  - Edit configurable thresholds (noise limit, inequality ratio, burn rate buffer).
  - Stored in `org_config` table.
- **Validation:** Config changes apply to system behavior.

### Task 8.3: Data Export (Law 7 — Anti-Caging)
- Create `ExportDataScreen.tsx`:
  - Export all personal data in CSV, JSON, or PDF.
  - Full decision history, judgments, coaching logs, voice transcripts.
- Create `server/src/routes/export.ts` with data packaging logic.
- **CONSTITUTIONAL CHECK:** All data exportable. No proprietary lock-in.
- **Validation:** Export produces valid files with complete user data.

---

## PHASE 9: FRICTION-FULL UI ENFORCEMENT
*Estimated: 2 hours | Dependency: Phase 2*

### Task 9.1: FrictionButton Component
- Create `FrictionButton.tsx`:
  - 3-second countdown animation before action executes.
  - Uses `react-native-reanimated` for smooth countdown.
  - Applied to all "Submit Decision" and "Approve" buttons.
- **Validation:** Button enforces delay on all critical actions.

### Task 9.2: ScrollGate Component
- Create `ScrollGate.tsx`:
  - "Continue" button disabled until user scrolls to bottom of content.
  - Used for risk assessments, pre-mortem reviews, Outside View data.
- **Validation:** Cannot proceed without scrolling through content.

### Task 9.3: UncertaintyBadge Component (Law 1)
- Create `UncertaintyBadge.tsx`:
  - Renders #FF8C00 badge with warning icon for any metric with CI < 70%.
  - Wraps any data display component.
- Apply to all screens that display predictive data.
- **Validation:** Orange badge appears on low-confidence outputs.

### Task 9.4: Undismissable Conflict Modals (Law 6)
- Modify `Modal.tsx` to support `undismissable` mode:
  - No "X" button.
  - Must choose "Acknowledge" or "Review Data."
  - Used for conflicting data presentations (Noise alerts, False Consensus).
- **Validation:** Modal cannot be dismissed without action.

---

## PHASE 10: TESTING & CONSTITUTIONAL COMPLIANCE
*Estimated: 3 hours | Dependency: All phases*

### Task 10.1: Unit Tests
- Write Jest tests for:
  - BlindInputForm validation (min 100 chars, score range 1-10).
  - SHA-256 hash generation.
  - Variance calculation (std dev, CV).
  - RBAC role checks.
  - FrictionButton delay timing.

### Task 10.2: Constitutional Compliance Test Suite
- Create `tests/constitutional/` directory.
- Write automated tests for each of the 12 Laws:
  - **Law 1:** No prediction renders without CI. Low CI shows orange.
  - **Law 2:** Group results blocked until all submitted.
  - **Law 3:** Submit disabled without divergence justification.
  - **Law 4:** AuditLog entry exists for every submission.
  - **Law 5:** All features map to a metric.
  - **Law 6:** No auto-decision by AI.
  - **Law 7:** Data exportable in CSV/JSON/PDF.
  - **Law 8:** Public API returns non-PII data.
  - **Law 9:** LLM provider is selectable.
  - **Law 10:** Email integration requires consent toggle.
  - **Law 11:** Voice recording requires consent.
  - **Law 12:** Heat map inaccessible to non-Board roles.

### Task 10.3: Integration Tests
- API endpoint tests for all routes.
- Shadow Layer verification: Every POST generates AuditLog entry.
- LLM Router: All adapters return valid responses.

### Task 10.4: Seed Data & Demo
- Create seed script with:
  - 5 test users (one per role).
  - 3 reference classes.
  - 2 decisions with judgments.
  - Sample AuditLog entries.
  - Sample bias heat map data.
- **Validation:** App fully functional with demo data.

---

## PHASE 11: DEPLOYMENT & POLISH
*Estimated: 2 hours | Dependency: Phase 10*

### Task 11.1: Production Environment Setup
- Configure production environment variables.
- Deploy backend to Railway/Render.
- Deploy Python service to Railway (Docker).
- Configure Supabase production project.
- Configure Upstash Redis for production.

### Task 11.2: App Store Preparation
- Configure `app.json` for iOS production build.
- Generate app icons and splash screen.
- Prepare App Store description and screenshots.
- Configure EAS Build for Expo.

### Task 11.3: Final Constitutional Audit
- Run full compliance test suite.
- Review every screen against RBAC matrix.
- Verify Shadow Layer cannot be bypassed.
- Verify heat map access controls.
- Generate final Epistemic Health Report.

---

## TASK DEPENDENCY GRAPH

```
Phase 0 (Scaffolding)
    │
    ├──▶ Phase 1 (Auth & Nav)
    │       │
    │       ├──▶ Phase 2 (Noise Audit) ──▶ Phase 4 (Shadow Steward)
    │       │                                    │
    │       │                                    ├──▶ Phase 6 (LLM Coaching)
    │       │                                    │       │
    │       │                                    │       └──▶ Phase 7 (Email/Calendar/Voice)
    │       │                                    │
    │       │                                    └──▶ Phase 8 (Admin Features)
    │       │
    │       ├──▶ Phase 3 (Goliath Framework)
    │       │
    │       └──▶ Phase 9 (Friction UI)
    │
    └──▶ Phase 5 (Chaos/Simulations) ──────────────────────┐
                                                            │
                                                            ▼
                                                    Phase 10 (Testing)
                                                            │
                                                            ▼
                                                    Phase 11 (Deploy)
```

---

## TOTAL ESTIMATED BUILD TIME

| Phase | Description | Est. Hours |
|---|---|---|
| 0 | Project Scaffolding | 2 |
| 1 | Auth & Navigation | 3 |
| 2 | Noise Audit Engine | 6 |
| 3 | Goliath Framework | 3 |
| 4 | Shadow Steward & Bias Engine | 5 |
| 5 | Chaos Simulations | 3 |
| 6 | LLM Coaching Integration | 5 |
| 7 | Email/Calendar/Voice | 4 |
| 8 | Admin Features | 3 |
| 9 | Friction UI | 2 |
| 10 | Testing & Compliance | 3 |
| 11 | Deployment | 2 |
| **TOTAL** | | **41 hours** |

---

*Tasks.md — The Steward v2.0 — Recursive SDD Framework for iOS*
*41 tasks across 12 phases. Ready for Replit Agent execution.*
