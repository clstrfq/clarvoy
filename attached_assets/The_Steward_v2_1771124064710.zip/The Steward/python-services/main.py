"""
THE STEWARD — Python Statistical Microservice
==============================================
Authority: plan.md Section 1.2 (Backend), spec.md Section 4 (Predictive Architecture)

This FastAPI service handles all statistical computation:
- Monte Carlo simulations (Chaos Engine)
- Variance calculations (Noise Audit)
- Vector embedding generation
- General statistical functions

It is called by the Node.js API Gateway and does NOT serve the iOS client directly.
"""

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from typing import List, Optional
import numpy as np
from scipy import stats
import uvicorn
from datetime import datetime

app = FastAPI(
    title="The Steward — Statistical Engine",
    description="Monte Carlo simulations, variance analysis, and statistical computation for System 2 Governance",
    version="2.0.0",
)


# =============================================================================
# MODELS
# =============================================================================

class SimulationRequest(BaseModel):
    """Input for Monte Carlo simulation — Constitution Law 1 (Epistemic Rigor)"""
    decision_id: str
    budget: float = Field(..., gt=0, description="Project budget in dollars")
    timeline: float = Field(..., gt=0, description="Project timeline in months")
    expected_impact: float = Field(..., ge=0, le=100, description="Expected impact score 0-100")
    funding_variance: float = Field(default=0.10, ge=0, le=1, description="Funding perturbation ±%")
    regulatory_variance: float = Field(default=0.05, ge=0, le=1, description="Regulatory perturbation ±%")
    staff_turnover_variance: float = Field(default=0.15, ge=0, le=1, description="Staff turnover perturbation ±%")
    run_count: int = Field(default=100, ge=100, le=10000, description="Number of Monte Carlo iterations (min 100)")


class SimulationResult(BaseModel):
    """Output of Monte Carlo simulation — Guardrail 3 (Constructive Noise Injection)"""
    decision_id: str
    run_count: int
    p5_outcome: dict
    p50_outcome: dict
    p95_outcome: dict
    distribution_data: List[dict]
    perturbation_params: dict
    generated_at: str


class VarianceRequest(BaseModel):
    """Input for variance calculation — Constitution Law 2 (Noise Intolerance)"""
    scores: List[float] = Field(..., min_length=2, description="Array of quantitative scores (1-10)")
    noise_threshold: float = Field(default=1.5, description="σ threshold for High Noise Alert")


class VarianceResult(BaseModel):
    """Output of variance calculation"""
    mean: float
    std_dev: float
    cv: float  # Coefficient of Variation
    is_high_noise: bool
    scores: List[float]
    score_count: int


# =============================================================================
# HEALTH CHECK
# =============================================================================

@app.get("/health")
async def health_check():
    return {
        "status": "ok",
        "service": "The Steward Statistical Engine",
        "version": "2.0.0",
        "capabilities": ["monte_carlo", "variance_analysis", "embedding_generation"],
        "timestamp": datetime.utcnow().isoformat(),
    }


# =============================================================================
# MONTE CARLO SIMULATION ENGINE
# =============================================================================
# Implements: Constitution Law 1 (Epistemic Rigor), Guardrail 3 (Constructive Noise Injection)
# Spec Reference: Module 3 — Predictive Architecture & Chaos Logic
#
# The system REJECTS deterministic single-point predictions.
# It outputs a Probability Distribution representing the "Invariant Set"
# of the system's attractor.
# =============================================================================

@app.post("/simulations/run", response_model=SimulationResult)
async def run_simulation(request: SimulationRequest):
    """
    Run a Monte Carlo simulation with constructive noise injection.

    This implements the "Chaos Engine" that perturbs initial conditions
    to reveal hidden fracture points in project plans. It produces
    three scenario cones:
    - Attractor Cone (p50): Most probable path
    - Worst-Case Boundary (p5): "Hell on Earth" scenario
    - High-Entropy Cone (p95): "Butterfly Effect" positive scenario
    """
    np.random.seed(None)  # Ensure true randomness

    results_budget = []
    results_timeline = []
    results_impact = []

    for _ in range(request.run_count):
        # Apply perturbation (Constructive Noise Injection)
        funding_shock = np.random.normal(1.0, request.funding_variance)
        regulatory_shock = np.random.normal(1.0, request.regulatory_variance)
        turnover_shock = np.random.normal(1.0, request.staff_turnover_variance)

        # Perturbed outcomes
        sim_budget = request.budget * funding_shock * regulatory_shock
        sim_timeline = request.timeline * regulatory_shock * turnover_shock
        sim_impact = min(100, max(0, request.expected_impact * funding_shock / turnover_shock))

        results_budget.append(sim_budget)
        results_timeline.append(sim_timeline)
        results_impact.append(sim_impact)

    # Calculate percentiles for scenario cones
    budget_arr = np.array(results_budget)
    timeline_arr = np.array(results_timeline)
    impact_arr = np.array(results_impact)

    p5 = {
        "budget": round(float(np.percentile(budget_arr, 5)), 2),
        "timeline": round(float(np.percentile(timeline_arr, 95)), 2),  # Worst case = longer timeline
        "impact": round(float(np.percentile(impact_arr, 5)), 2),
    }
    p50 = {
        "budget": round(float(np.percentile(budget_arr, 50)), 2),
        "timeline": round(float(np.percentile(timeline_arr, 50)), 2),
        "impact": round(float(np.percentile(impact_arr, 50)), 2),
    }
    p95 = {
        "budget": round(float(np.percentile(budget_arr, 95)), 2),
        "timeline": round(float(np.percentile(timeline_arr, 5)), 2),  # Best case = shorter timeline
        "impact": round(float(np.percentile(impact_arr, 95)), 2),
    }

    # Distribution data for visualization (sampled for payload size)
    sample_size = min(request.run_count, 200)
    indices = np.random.choice(request.run_count, sample_size, replace=False)
    distribution_data = [
        {
            "budget": round(results_budget[i], 2),
            "timeline": round(results_timeline[i], 2),
            "impact": round(results_impact[i], 2),
        }
        for i in indices
    ]

    return SimulationResult(
        decision_id=request.decision_id,
        run_count=request.run_count,
        p5_outcome=p5,
        p50_outcome=p50,
        p95_outcome=p95,
        distribution_data=distribution_data,
        perturbation_params={
            "funding_variance": request.funding_variance,
            "regulatory_variance": request.regulatory_variance,
            "staff_turnover_variance": request.staff_turnover_variance,
        },
        generated_at=datetime.utcnow().isoformat(),
    )


# =============================================================================
# VARIANCE CALCULATION ENGINE
# =============================================================================
# Implements: Constitution Law 2 (Noise Intolerance)
# Spec Reference: Module 1, Section 3.1.1 — Noise Audit Protocol
# =============================================================================

@app.post("/variance/calculate", response_model=VarianceResult)
async def calculate_variance(request: VarianceRequest):
    """
    Calculate the variance metrics for a set of blind judgment scores.

    This implements the Noise Audit's core statistical engine:
    - Standard Deviation (σ): Measures score spread
    - Coefficient of Variation (CV = σ/μ): Normalized noise metric
    - High Noise Flag: Triggers when σ exceeds the configurable threshold
    """
    scores = np.array(request.scores)

    if len(scores) < 2:
        raise HTTPException(status_code=400, detail="Need at least 2 scores for variance calculation")

    mean = float(np.mean(scores))
    std_dev = float(np.std(scores, ddof=1))  # Sample standard deviation
    cv = std_dev / mean if mean != 0 else float('inf')

    return VarianceResult(
        mean=round(mean, 4),
        std_dev=round(std_dev, 4),
        cv=round(cv, 4),
        is_high_noise=std_dev > request.noise_threshold,
        scores=request.scores,
        score_count=len(request.scores),
    )


# =============================================================================
# CONFIDENCE INTERVAL CALCULATION
# =============================================================================
# Implements: Constitution Law 1 — No prediction without CI
# =============================================================================

class ConfidenceIntervalRequest(BaseModel):
    values: List[float] = Field(..., min_length=2)
    confidence_level: float = Field(default=0.95, ge=0.5, le=0.99)


class ConfidenceIntervalResult(BaseModel):
    mean: float
    ci_lower: float
    ci_upper: float
    confidence_level: float
    is_low_confidence: bool  # True if CI width > 30% of mean
    sample_size: int


@app.post("/statistics/confidence-interval", response_model=ConfidenceIntervalResult)
async def calculate_confidence_interval(request: ConfidenceIntervalRequest):
    """Calculate confidence interval — Constitutional requirement (Law 1)."""
    values = np.array(request.values)
    n = len(values)
    mean = float(np.mean(values))
    se = float(stats.sem(values))

    ci = stats.t.interval(request.confidence_level, df=n - 1, loc=mean, scale=se)

    ci_width = ci[1] - ci[0]
    is_low_confidence = (ci_width / abs(mean)) > 0.3 if mean != 0 else True

    return ConfidenceIntervalResult(
        mean=round(mean, 4),
        ci_lower=round(float(ci[0]), 4),
        ci_upper=round(float(ci[1]), 4),
        confidence_level=request.confidence_level,
        is_low_confidence=is_low_confidence,
        sample_size=n,
    )


# =============================================================================
# SERVER STARTUP
# =============================================================================

if __name__ == "__main__":
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=8000,
        reload=True,
        log_level="info",
    )
