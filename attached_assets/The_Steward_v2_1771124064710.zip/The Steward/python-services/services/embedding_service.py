"""Vector Embedding Service for False Consensus Detection."""
import numpy as np
from typing import List

def cosine_similarity(a: List[float], b: List[float]) -> float:
    a_arr, b_arr = np.array(a), np.array(b)
    dot = np.dot(a_arr, b_arr)
    norm = np.linalg.norm(a_arr) * np.linalg.norm(b_arr)
    return float(dot / norm) if norm != 0 else 0.0

def detect_false_consensus(embeddings: List[List[float]], scores: List[int],
                           similarity_threshold: float = 0.5, score_gap: int = 1) -> List[dict]:
    flags = []
    for i in range(len(scores)):
        for j in range(i + 1, len(scores)):
            if abs(scores[i] - scores[j]) <= score_gap:
                sim = cosine_similarity(embeddings[i], embeddings[j])
                if sim < similarity_threshold:
                    flags.append({'users': [i, j], 'similarity': round(sim, 4), 'score_gap': abs(scores[i] - scores[j])})
    return flags
