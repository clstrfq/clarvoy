"""Monte Carlo Simulation Engine — extracted service module."""
import numpy as np
from typing import Dict, List

def run_simulation(budget: float, timeline: float, impact: float,
                   funding_var: float = 0.1, regulatory_var: float = 0.05,
                   turnover_var: float = 0.15, runs: int = 100) -> Dict:
    results = {'budget': [], 'timeline': [], 'impact': []}
    for _ in range(runs):
        f = np.random.normal(1.0, funding_var)
        r = np.random.normal(1.0, regulatory_var)
        t = np.random.normal(1.0, turnover_var)
        results['budget'].append(budget * f * r)
        results['timeline'].append(timeline * r * t)
        results['impact'].append(min(100, max(0, impact * f / t)))
    return {k: np.array(v) for k, v in results.items()}
