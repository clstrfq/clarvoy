"""General statistical functions."""
import numpy as np
from scipy import stats
from typing import List, Dict

def confidence_interval(values: List[float], confidence: float = 0.95) -> Dict:
    arr = np.array(values)
    mean = float(np.mean(arr))
    se = float(stats.sem(arr))
    ci = stats.t.interval(confidence, df=len(arr) - 1, loc=mean, scale=se)
    return {'mean': round(mean, 4), 'ci_lower': round(float(ci[0]), 4), 'ci_upper': round(float(ci[1]), 4)}
