"""Variance Calculation Engine — Law 2 (Noise Intolerance)."""
import numpy as np
from typing import Dict, List

def calculate_variance(scores: List[float], threshold: float = 1.5) -> Dict:
    arr = np.array(scores)
    mean = float(np.mean(arr))
    std = float(np.std(arr, ddof=1))
    return {
        'mean': round(mean, 4),
        'std_dev': round(std, 4),
        'cv': round(std / mean, 4) if mean != 0 else float('inf'),
        'is_high_noise': std > threshold,
        'score_count': len(scores),
    }
