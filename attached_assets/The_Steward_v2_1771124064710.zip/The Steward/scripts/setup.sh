#!/bin/bash
# THE STEWARD — Project Setup Script
echo "╔══════════════════════════════════════╗"
echo "║     THE STEWARD v2.0 — Setup        ║"
echo "╚══════════════════════════════════════╝"

echo "→ Installing frontend dependencies..."
npm install

echo "→ Installing backend dependencies..."
cd server && npm install && cd ..

echo "→ Installing Python dependencies..."
cd python-services && pip install -r requirements.txt && cd ..

echo "→ Setup complete!"
echo "→ Next steps:"
echo "  1. Copy .env.example to .env and fill in your credentials"
echo "  2. Run database migration against Supabase"
echo "  3. Start backend: cd server && npm run dev"
echo "  4. Start Python service: cd python-services && python main.py"
echo "  5. Start frontend: npx expo start"
