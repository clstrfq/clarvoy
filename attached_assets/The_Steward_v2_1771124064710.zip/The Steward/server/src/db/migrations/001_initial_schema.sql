-- =============================================================================
-- THE STEWARD — Initial Database Schema Migration
-- =============================================================================
-- Authority: spec.md Section 9 (Data Schema)
-- Database: Supabase (PostgreSQL 15 + pgvector)
--
-- Run this migration against your Supabase project to create all tables.
-- Prerequisites: Enable pgvector extension in Supabase dashboard.
-- =============================================================================

-- Enable required extensions
CREATE EXTENSION IF NOT EXISTS "pgvector";
CREATE EXTENSION IF NOT EXISTS "pg_cron";
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- =============================================================================
-- TABLES
-- =============================================================================

-- Bias Profiles (created first for FK reference)
CREATE TABLE IF NOT EXISTS bias_profiles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL,
  sunk_cost_score DECIMAL(5,2) DEFAULT 0,
  halo_effect_score DECIMAL(5,2) DEFAULT 0,
  anchoring_score DECIMAL(5,2) DEFAULT 0,
  confirmation_bias_score DECIMAL(5,2) DEFAULT 0,
  recency_bias_score DECIMAL(5,2) DEFAULT 0,
  loss_aversion_score DECIMAL(5,2) DEFAULT 0,
  optimism_bias_score DECIMAL(5,2) DEFAULT 0,
  groupthink_score DECIMAL(5,2) DEFAULT 0,
  overall_bias_load DECIMAL(5,2) DEFAULT 0,
  last_updated TIMESTAMPTZ DEFAULT NOW()
);

-- Users & Authentication
CREATE TABLE IF NOT EXISTS users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email TEXT UNIQUE NOT NULL,
  full_name TEXT NOT NULL,
  role TEXT NOT NULL CHECK (role IN ('STANDARD_USER', 'COMMITTEE_MEMBER', 'BOARD_MEMBER', 'SYSTEM_ADMIN', 'AUDITOR')),
  prestige_score DECIMAL(5,2) DEFAULT 0,
  bias_profile_id UUID REFERENCES bias_profiles(id),
  noise_contribution_metric DECIMAL(5,2) DEFAULT 0,
  preferred_llm_provider TEXT DEFAULT 'claude',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Add FK from bias_profiles to users
ALTER TABLE bias_profiles ADD CONSTRAINT fk_bias_profiles_user FOREIGN KEY (user_id) REFERENCES users(id);

-- Reference Classes (Historical baselines)
CREATE TABLE IF NOT EXISTS reference_classes (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  category TEXT NOT NULL,
  description TEXT,
  avg_cost_overrun DECIMAL(5,2),
  avg_time_overrun DECIMAL(5,2),
  base_rate_failure DECIMAL(5,2),
  sample_size INTEGER,
  source TEXT,
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Decisions (High-stakes choice events)
CREATE TABLE IF NOT EXISTS decisions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title TEXT NOT NULL,
  description TEXT,
  project_id UUID,
  status TEXT NOT NULL CHECK (status IN ('OPEN', 'IN_REVIEW', 'BLOCKED', 'APPROVED', 'REJECTED')),
  final_outcome TEXT,
  reference_class_id UUID REFERENCES reference_classes(id),
  value_amount DECIMAL(12,2),
  created_by UUID REFERENCES users(id),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Judgments (Individual blind inputs) — Constitution Law 2
CREATE TABLE IF NOT EXISTS judgments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  decision_id UUID NOT NULL REFERENCES decisions(id),
  user_id UUID NOT NULL REFERENCES users(id),
  score_quant INTEGER NOT NULL CHECK (score_quant BETWEEN 1 AND 10),
  rationale_qual TEXT NOT NULL CHECK (char_length(rationale_qual) >= 100),
  hash_integrity TEXT NOT NULL,
  hidden_bias_flags JSONB DEFAULT '{}',
  vector_embedding VECTOR(1536),
  submitted_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(decision_id, user_id)
);

-- AuditLog (The Shadow Layer) — Constitution Law 4
CREATE TABLE IF NOT EXISTS audit_log (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  judgment_id UUID REFERENCES judgments(id),
  decision_id UUID REFERENCES decisions(id),
  user_id UUID REFERENCES users(id),
  detected_fallacies JSONB,
  debate_counter_argument TEXT,
  bias_severity TEXT CHECK (bias_severity IN ('LOW', 'MEDIUM', 'HIGH', 'CRITICAL')),
  bias_category TEXT,
  decision_category TEXT CHECK (decision_category IN ('GRANT_ALLOCATION', 'BUDGET_APPROVAL', 'STRATEGIC_PLANNING', 'PERSONNEL')),
  hash_integrity_check TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Simulations (Chaos Engine outputs) — Guardrail 3
CREATE TABLE IF NOT EXISTS simulations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  decision_id UUID NOT NULL REFERENCES decisions(id),
  run_count INTEGER NOT NULL DEFAULT 100,
  p5_outcome JSONB,
  p50_outcome JSONB,
  p95_outcome JSONB,
  distribution_data JSONB,
  perturbation_params JSONB,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Coaching Log
CREATE TABLE IF NOT EXISTS coaching_log (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id),
  llm_provider TEXT NOT NULL,
  prompt_summary TEXT,
  response_summary TEXT,
  context_sources JSONB DEFAULT '[]',
  session_duration_seconds INTEGER,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Email Context (extracted metadata only) — Constitution Law 10
CREATE TABLE IF NOT EXISTS email_context (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id),
  provider TEXT NOT NULL CHECK (provider IN ('outlook', 'gmail', 'proton')),
  email_summary TEXT NOT NULL,
  relevance_score DECIMAL(3,2),
  decision_id UUID REFERENCES decisions(id),
  extracted_at TIMESTAMPTZ DEFAULT NOW(),
  expires_at TIMESTAMPTZ DEFAULT NOW() + INTERVAL '30 days'
);

-- Calendar Context — Constitution Law 10
CREATE TABLE IF NOT EXISTS calendar_context (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id),
  provider TEXT NOT NULL CHECK (provider IN ('outlook', 'google')),
  meeting_title TEXT,
  meeting_date TIMESTAMPTZ,
  attendee_count INTEGER,
  is_recurring BOOLEAN DEFAULT FALSE,
  coaching_signal TEXT,
  extracted_at TIMESTAMPTZ DEFAULT NOW()
);

-- Voice Notes — Constitution Law 11
CREATE TABLE IF NOT EXISTS voice_notes (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id),
  decision_id UUID REFERENCES decisions(id),
  transcript TEXT NOT NULL,
  duration_seconds INTEGER,
  consent_recorded BOOLEAN NOT NULL DEFAULT TRUE,
  two_party_consent BOOLEAN DEFAULT FALSE,
  audio_file_path TEXT,
  audio_expires_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Daily Bias Heat Map Cache — Constitution Law 12
CREATE TABLE IF NOT EXISTS bias_heatmap_cache (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  report_date DATE NOT NULL UNIQUE,
  heatmap_data JSONB NOT NULL,
  total_detections INTEGER,
  critical_count INTEGER,
  generated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Risk Register (Pre-Mortem narratives)
CREATE TABLE IF NOT EXISTS risk_register (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  decision_id UUID NOT NULL REFERENCES decisions(id),
  narrative TEXT NOT NULL,
  failure_classification TEXT CHECK (failure_classification IN ('INTERNAL_FAILURE', 'EXTERNAL_SHOCK', 'MIXED')),
  created_by UUID REFERENCES users(id),
  reviewed_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- User Settings (LLM preferences, integrations)
CREATE TABLE IF NOT EXISTS user_settings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL UNIQUE REFERENCES users(id),
  preferred_llm TEXT DEFAULT 'claude',
  llm_credentials JSONB DEFAULT '{}',
  email_integration_enabled BOOLEAN DEFAULT FALSE,
  email_providers JSONB DEFAULT '[]',
  calendar_integration_enabled BOOLEAN DEFAULT FALSE,
  calendar_providers JSONB DEFAULT '[]',
  voice_recording_enabled BOOLEAN DEFAULT FALSE,
  voice_cloud_transcription BOOLEAN DEFAULT FALSE,
  two_party_consent_jurisdiction BOOLEAN DEFAULT FALSE,
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Organizational Config
CREATE TABLE IF NOT EXISTS org_config (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  key TEXT UNIQUE NOT NULL,
  value JSONB NOT NULL,
  description TEXT,
  updated_by UUID REFERENCES users(id),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- =============================================================================
-- INDEXES
-- =============================================================================

CREATE INDEX idx_judgments_decision_id ON judgments(decision_id);
CREATE INDEX idx_judgments_user_id ON judgments(user_id);
CREATE INDEX idx_audit_log_decision_id ON audit_log(decision_id);
CREATE INDEX idx_audit_log_user_id ON audit_log(user_id);
CREATE INDEX idx_audit_log_created_at ON audit_log(created_at);
CREATE INDEX idx_audit_log_bias_severity ON audit_log(bias_severity);
CREATE INDEX idx_simulations_decision_id ON simulations(decision_id);
CREATE INDEX idx_coaching_log_user_id ON coaching_log(user_id);
CREATE INDEX idx_email_context_user_id ON email_context(user_id);
CREATE INDEX idx_voice_notes_user_id ON voice_notes(user_id);
CREATE INDEX idx_bias_heatmap_cache_date ON bias_heatmap_cache(report_date);
CREATE INDEX idx_decisions_status ON decisions(status);
CREATE INDEX idx_decisions_created_by ON decisions(created_by);

-- =============================================================================
-- SEED DATA: Reference Classes
-- =============================================================================

INSERT INTO reference_classes (category, description, avg_cost_overrun, avg_time_overrun, base_rate_failure, sample_size, source) VALUES
('IT_MIGRATION', 'Information Technology System Migration', 45.0, 55.0, 0.18, 1200, 'Flyvbjerg (2021) - Oxford Global Projects'),
('COMMUNITY_HEALTH', 'Community Health Intervention Programs', 25.0, 35.0, 0.22, 800, 'WHO Project Database 2020-2024'),
('CAPITAL_CONSTRUCTION', 'Capital Construction Projects', 60.0, 70.0, 0.15, 2500, 'UK Treasury Green Book'),
('EDUCATION_PROGRAM', 'Educational Program Rollouts', 20.0, 30.0, 0.25, 600, 'DFID Education Portfolio Review'),
('DISASTER_RELIEF', 'Disaster Relief & Emergency Response', 35.0, 40.0, 0.12, 900, 'OCHA Coordination Reports'),
('ADVOCACY_CAMPAIGN', 'Advocacy & Policy Campaign', 15.0, 25.0, 0.30, 400, 'Non-profit Effectiveness Database'),
('FOOD_SECURITY', 'Food Security & Agriculture Programs', 30.0, 45.0, 0.20, 700, 'FAO Project Monitoring Database'),
('MICROFINANCE', 'Microfinance & Economic Development', 20.0, 25.0, 0.15, 1100, 'CGAP Global Microfinance Data');

-- =============================================================================
-- SEED DATA: Organization Config
-- =============================================================================

INSERT INTO org_config (key, value, description) VALUES
('noise_threshold', '"1.5"', 'Standard deviation threshold for High Noise Alert'),
('inequality_ratio_threshold', '"5.0"', 'Max acceptable compensation ratio'),
('burn_rate_buffer_months', '"6"', 'Minimum acceptable cash runway in months'),
('confidence_interval_threshold', '"0.7"', 'Below this CI, display Uncertainty Orange'),
('pre_mortem_value_threshold', '"50000"', 'Decisions above this value require Pre-Mortem'),
('divergence_justification_min_chars', '"200"', 'Minimum characters for Outside View justification'),
('rationale_min_chars', '"100"', 'Minimum characters for judgment rationale'),
('simulation_default_runs', '"100"', 'Default Monte Carlo iterations'),
('voice_retention_hours', '"24"', 'Hours before raw audio auto-deletion'),
('email_extraction_window_seconds', '"60"', 'Max time to hold raw email data'),
('heatmap_cron_schedule', '"0 0 * * *"', 'Daily heat map generation schedule (midnight UTC)'),
('nightly_bias_cron_schedule', '"0 2 * * *"', 'Nightly bias analysis schedule (2 AM UTC)');

-- =============================================================================
-- ROW LEVEL SECURITY (RLS)
-- =============================================================================

-- Enable RLS on all tables
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE decisions ENABLE ROW LEVEL SECURITY;
ALTER TABLE judgments ENABLE ROW LEVEL SECURITY;
ALTER TABLE audit_log ENABLE ROW LEVEL SECURITY;
ALTER TABLE simulations ENABLE ROW LEVEL SECURITY;
ALTER TABLE coaching_log ENABLE ROW LEVEL SECURITY;
ALTER TABLE email_context ENABLE ROW LEVEL SECURITY;
ALTER TABLE calendar_context ENABLE ROW LEVEL SECURITY;
ALTER TABLE voice_notes ENABLE ROW LEVEL SECURITY;
ALTER TABLE bias_heatmap_cache ENABLE ROW LEVEL SECURITY;
ALTER TABLE risk_register ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE bias_profiles ENABLE ROW LEVEL SECURITY;

-- Audit Log: ONLY Board Members, System Admins, Auditors (Law 4, Law 12)
CREATE POLICY audit_log_board_only ON audit_log
  FOR SELECT USING (
    auth.uid() IN (
      SELECT id FROM users WHERE role IN ('BOARD_MEMBER', 'SYSTEM_ADMIN', 'AUDITOR')
    )
  );

-- Bias Heat Map Cache: ONLY Board Members, System Admins, Auditors (Law 12)
CREATE POLICY heatmap_board_only ON bias_heatmap_cache
  FOR SELECT USING (
    auth.uid() IN (
      SELECT id FROM users WHERE role IN ('BOARD_MEMBER', 'SYSTEM_ADMIN', 'AUDITOR')
    )
  );

-- Users can read their own data
CREATE POLICY users_own_data ON user_settings
  FOR ALL USING (auth.uid() = user_id);

CREATE POLICY coaching_own_data ON coaching_log
  FOR ALL USING (auth.uid() = user_id);

CREATE POLICY email_own_data ON email_context
  FOR ALL USING (auth.uid() = user_id);

CREATE POLICY voice_own_data ON voice_notes
  FOR ALL USING (auth.uid() = user_id);

-- Decisions: Readable by all authenticated users
CREATE POLICY decisions_read_all ON decisions
  FOR SELECT USING (auth.uid() IS NOT NULL);

-- Reference Classes: Readable by all
CREATE POLICY reference_classes_public ON reference_classes
  FOR SELECT USING (true);
