// =============================================================================
// THE STEWARD — API Gateway Server Entry Point (FULLY WIRED)
// =============================================================================
// Authority: plan.md Section 2.1 (System Architecture)
// CRITICAL: Shadow Layer registered BEFORE all route handlers (Law 4).
// =============================================================================

import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import dotenv from 'dotenv';

import { shadowLayerMiddleware } from './middleware/shadowLayer';
import { authMiddleware } from './middleware/auth';
import { roleGateMiddleware } from './middleware/roleGate';
import { apiLimiter, llmLimiter } from './middleware/rateLimiter';

import authRoutes from './routes/auth';
import decisionsRoutes from './routes/decisions';
import judgmentsRoutes from './routes/judgments';
import simulationsRoutes from './routes/simulations';
import coachingRoutes from './routes/coaching';
import voiceRoutes from './routes/voice';
import adminRoutes from './routes/admin';
import settingsRoutes from './routes/settings';
import exportRoutes from './routes/export';
import publicRoutes from './routes/public';

import { runDailyHeatmapJob } from './jobs/dailyHeatmapJob';
import { runVoiceCleanupJob } from './jobs/voiceCleanupJob';

dotenv.config();

const app = express();
const PORT = process.env.PORT || 3000;

// GLOBAL MIDDLEWARE
app.use(helmet());
app.use(cors({ origin: process.env.CLIENT_ORIGIN || '*', credentials: true }));
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));
app.use('/api/', apiLimiter);

// SHADOW LAYER — CONSTITUTIONAL REQUIREMENT (Law 4) — BEFORE ROUTES
app.use('/api/v1/decisions', shadowLayerMiddleware);
app.use('/api/v1/judgments', shadowLayerMiddleware);

// Health check
app.get('/health', (_req, res) => {
  res.json({
    status: 'ok', service: 'The Steward API Gateway', version: '2.0.0',
    shadow_layer: 'ACTIVE', timestamp: new Date().toISOString(),
  });
});

// Public Routes (Law 8: Radical Transparency)
app.use('/public/api/v1', publicRoutes);

// Auth
app.use('/api/v1/auth', authRoutes);

// Authenticated Routes
app.use('/api/v1/decisions', authMiddleware, decisionsRoutes);
app.use('/api/v1/judgments', authMiddleware, judgmentsRoutes);
app.use('/api/v1/simulations', authMiddleware, simulationsRoutes);
app.use('/api/v1/coaching', authMiddleware, llmLimiter, coachingRoutes);
app.use('/api/v1/voice', authMiddleware, voiceRoutes);
app.use('/api/v1/settings', authMiddleware, settingsRoutes);
app.use('/api/v1/export', authMiddleware, exportRoutes);

// Admin Routes — Role-Gated (Law 4, Law 12)
app.use('/api/v1/admin', authMiddleware, roleGateMiddleware(['BOARD_MEMBER', 'SYSTEM_ADMIN', 'AUDITOR']), adminRoutes);

// Error handling
app.use((_req, res) => { res.status(404).json({ error: 'Endpoint not found' }); });
app.use((err: Error, _req: express.Request, res: express.Response, _next: express.NextFunction) => {
  console.error('[ERROR]', err.message);
  res.status(500).json({ error: 'Internal server error', message: process.env.NODE_ENV === 'development' ? err.message : undefined });
});

// Scheduled Jobs
const scheduleJobs = () => {
  const now = new Date();
  const msUntilMidnight = new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1, 0, 0, 0).getTime() - now.getTime();
  setTimeout(() => { runDailyHeatmapJob(); setInterval(runDailyHeatmapJob, 86400000); }, msUntilMidnight);
  setInterval(runVoiceCleanupJob, 3600000);
};

app.listen(PORT, () => {
  scheduleJobs();
  console.log(`
╔══════════════════════════════════════════════════════════════╗
║                    THE STEWARD v2.0                         ║
║           System 2 Governance API Gateway                   ║
║  Shadow Layer: ACTIVE (Constitutional Law 4)                ║
║  Port: ${PORT} | Env: ${process.env.NODE_ENV || 'development'}                         ║
║  Routes: auth, decisions, judgments, simulations,           ║
║          coaching, voice, admin, settings, export, public   ║
║  LLM: Gemini, Claude, ChatGPT, Perplexity, NotebookLM     ║
╚══════════════════════════════════════════════════════════════╝
  `);
});

export default app;
