// Runs at midnight UTC daily — Law 12
import { generateDailyHeatmap } from '../services/heatmapGenerator';

export async function runDailyHeatmapJob(): Promise<void> {
  console.log('[DailyHeatmapJob] Starting...');
  await generateDailyHeatmap();
  console.log('[DailyHeatmapJob] Complete.');
}
