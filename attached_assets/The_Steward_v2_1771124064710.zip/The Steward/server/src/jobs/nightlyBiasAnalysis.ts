// Runs at 2 AM UTC nightly
import { supabase } from '../db/supabase';

export async function runNightlyBiasAnalysis(): Promise<void> {
  console.log('[NightlyBiasAnalysis] Starting...');
  const { data: users } = await supabase.from('users').select('id');
  for (const user of users || []) {
    const { data: decisions } = await supabase.from('decisions')
      .select('*').eq('created_by', user.id).order('created_at', { ascending: false }).limit(50);
    // Pattern analysis would go here
    console.log(`[NightlyBiasAnalysis] Analyzed ${decisions?.length || 0} decisions for user ${user.id}`);
  }
  console.log('[NightlyBiasAnalysis] Complete.');
}
