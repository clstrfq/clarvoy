// Law 11: Auto-delete audio after 24 hours
import { supabase } from '../db/supabase';

export async function runVoiceCleanupJob(): Promise<void> {
  const cutoff = new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString();
  const { data } = await supabase.from('voice_notes')
    .update({ audio_file_path: null })
    .lt('audio_expires_at', cutoff)
    .not('audio_file_path', 'is', null)
    .select();
  console.log(`[VoiceCleanup] Cleaned ${data?.length || 0} expired audio files`);
}
