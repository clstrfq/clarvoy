// =============================================================================
// THE STEWARD — RBAC Middleware
// =============================================================================
import { Response, NextFunction } from 'express';
import { AuthenticatedRequest } from './auth';

export function roleGateMiddleware(allowedRoles: string[]) {
  return (req: AuthenticatedRequest, res: Response, next: NextFunction): void => {
    if (!req.user || !allowedRoles.includes(req.user.role)) {
      res.status(403).json({ error: 'Insufficient permissions' });
      return;
    }
    next();
  };
}
