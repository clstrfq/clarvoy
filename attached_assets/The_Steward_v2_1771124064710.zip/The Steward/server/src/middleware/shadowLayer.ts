// =============================================================================
// THE STEWARD — Shadow Layer Middleware (The Governance Backdoor)
// =============================================================================
// Authority: Constitution Law 4 (Governance Backdoor), Guardrail 1 (Shadow Layer)
//
// THIS MIDDLEWARE IS MANDATORY AND CANNOT BE DISABLED.
// It intercepts all decision/judgment submissions, forks the payload
// asynchronously to the BiasEngine for analysis, and logs to the AuditLog.
// It operates as the "Black Box flight recorder" of organizational cognition.
//
// CONSTITUTIONAL CONSTRAINT: This middleware MUST be registered in index.ts
// BEFORE any route handlers. It CANNOT be conditionally loaded, feature-flagged,
// or disabled by any application-level logic. Any attempt to bypass it must be
// logged as a constitutional violation.
// =============================================================================

import { Request, Response, NextFunction } from 'express';
import { v4 as uuidv4 } from 'uuid';

// Type for the bias analysis queue (BullMQ job)
interface ShadowPayload {
  id: string;
  endpoint: string;
  method: string;
  userId: string | null;
  body: Record<string, unknown>;
  timestamp: string;
  headers: {
    userAgent: string | undefined;
    contentType: string | undefined;
  };
}

/**
 * Shadow Layer Middleware — Constitution Law 4
 *
 * This middleware:
 * 1. Intercepts ALL POST requests to monitored endpoints.
 * 2. Creates a deep copy of the request payload.
 * 3. Enqueues the payload for asynchronous bias analysis.
 * 4. NEVER blocks the main response — the user sees no delay.
 * 5. Logs the interception for audit trail integrity.
 *
 * The Shadow Layer is IMMUTABLE. It cannot be:
 * - Disabled via environment variable
 * - Skipped via request header
 * - Bypassed via admin override
 * - Removed without a Constitutional Amendment (75% Board supermajority)
 */
export function shadowLayerMiddleware(
  req: Request,
  res: Response,
  next: NextFunction
): void {
  // Only intercept POST requests (submissions, not reads)
  if (req.method !== 'POST') {
    next();
    return;
  }

  // Create shadow payload — deep copy to prevent mutation
  const shadowPayload: ShadowPayload = {
    id: uuidv4(),
    endpoint: req.originalUrl,
    method: req.method,
    userId: (req as any).user?.id || null,
    body: JSON.parse(JSON.stringify(req.body || {})),
    timestamp: new Date().toISOString(),
    headers: {
      userAgent: req.headers['user-agent'],
      contentType: req.headers['content-type'],
    },
  };

  // Fire-and-forget: Enqueue for async bias analysis
  // This MUST NOT block the main response pipeline
  enqueueBiasAnalysis(shadowPayload).catch((error) => {
    // Shadow Layer errors are logged but NEVER surface to the user.
    // The user experience must remain unaffected.
    console.error('[SHADOW_LAYER] Bias analysis enqueue failed:', {
      payloadId: shadowPayload.id,
      error: error.message,
      timestamp: shadowPayload.timestamp,
    });

    // Even on failure, log the interception attempt
    logShadowInterception(shadowPayload, 'ENQUEUE_FAILED', error.message);
  });

  // Log successful interception
  logShadowInterception(shadowPayload, 'INTERCEPTED');

  // Continue to the actual route handler — the user sees NO delay
  next();
}

/**
 * Enqueues the payload for asynchronous bias analysis via BullMQ.
 * In the full implementation, this sends to the BiasEngine microservice.
 */
async function enqueueBiasAnalysis(payload: ShadowPayload): Promise<void> {
  // TODO: Task 4.1 — Connect to BullMQ queue
  // const biasQueue = new Queue('bias-analysis', { connection: redis });
  // await biasQueue.add('analyze', payload, {
  //   attempts: 3,
  //   backoff: { type: 'exponential', delay: 1000 },
  //   removeOnComplete: { age: 86400 }, // Keep for 24 hours
  // });

  // Placeholder: Log the shadow capture
  console.log('[SHADOW_LAYER] Payload captured:', {
    id: payload.id,
    endpoint: payload.endpoint,
    userId: payload.userId,
    timestamp: payload.timestamp,
  });
}

/**
 * Logs the shadow interception to the audit trail.
 * This creates a minimal record that the Shadow Layer was active.
 */
function logShadowInterception(
  payload: ShadowPayload,
  status: 'INTERCEPTED' | 'ENQUEUE_FAILED',
  errorMessage?: string
): void {
  // TODO: Task 4.1 — Write to audit_log table via Supabase
  // This is a fire-and-forget operation
  const logEntry = {
    shadow_id: payload.id,
    endpoint: payload.endpoint,
    user_id: payload.userId,
    status,
    error_message: errorMessage || null,
    timestamp: payload.timestamp,
  };

  // In production, this writes directly to the audit_log table
  console.log('[SHADOW_LAYER] Interception logged:', logEntry);
}

/**
 * CONSTITUTIONAL ENFORCEMENT:
 * This export is the ONLY way to use the Shadow Layer.
 * There is no "disable" function, no "bypass" option, no "test mode."
 *
 * Per Constitution Law 4:
 * "This layer must be isolated from the main application logic
 *  to ensure that it cannot be disabled by administrative users."
 */
export default shadowLayerMiddleware;
