// =============================================================================
// THE STEWARD — Admin Routes (Board-Only)
// =============================================================================
// Implements: Law 12 (Bias Heat Map), Law 4 (Audit Log)
// Access: BOARD_MEMBER, SYSTEM_ADMIN, AUDITOR — enforced by roleGate middleware
import { Router, Response } from 'express';
import { AuthenticatedRequest } from '../middleware/auth';
import { supabase } from '../db/supabase';

const router = Router();

// Bias Heat Map — Law 12
router.get('/bias-heatmap', async (req: AuthenticatedRequest, res: Response) => {
  const date = (req.query.date as string) || new Date().toISOString().split('T')[0];
  const { data } = await supabase.from('bias_heatmap_cache')
    .select('*').eq('report_date', date).single();
  if (!data) { res.status(404).json({ error: 'No heat map data for this date' }); return; }
  res.json(data);
});

// Audit Log — Law 4
router.get('/audit-log', async (req: AuthenticatedRequest, res: Response) => {
  const limit = parseInt(req.query.limit as string) || 50;
  const { data } = await supabase.from('audit_log')
    .select('*').order('created_at', { ascending: false }).limit(limit);
  res.json(data || []);
});

// Epistemic Health Report
router.get('/epistemic-report', async (req: AuthenticatedRequest, res: Response) => {
  const { data: profiles } = await supabase.from('bias_profiles').select('*');
  const { data: auditCount } = await supabase.from('audit_log').select('*', { count: 'exact', head: true });
  res.json({
    total_profiles: profiles?.length || 0,
    total_audit_entries: auditCount || 0,
    generated_at: new Date().toISOString(),
  });
});

// User Management — SYSTEM_ADMIN only
router.get('/users', async (req: AuthenticatedRequest, res: Response) => {
  if (req.user?.role !== 'SYSTEM_ADMIN') { res.status(403).json({ error: 'Admin only' }); return; }
  const { data } = await supabase.from('users').select('*').order('created_at', { ascending: false });
  res.json(data || []);
});

export default router;
