import { Router, Request, Response } from 'express';
import jwt from 'jsonwebtoken';
import { supabase } from '../db/supabase';

const router = Router();

router.post('/login', async (req: Request, res: Response) => {
  const { email, password } = req.body;
  try {
    const { data, error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) { res.status(401).json({ error: error.message }); return; }

    const { data: userRow } = await supabase.from('users').select('*').eq('email', email).single();
    const token = jwt.sign(
      { sub: userRow?.id, email, role: userRow?.role },
      process.env.JWT_SECRET || 'steward-dev-secret',
      { expiresIn: '24h' }
    );
    res.json({ user: userRow, access_token: token });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.get('/me', async (req: any, res: Response) => {
  if (!req.user) { res.status(401).json({ error: 'Not authenticated' }); return; }
  const { data } = await supabase.from('users').select('*').eq('id', req.user.id).single();
  res.json(data);
});

export default router;
