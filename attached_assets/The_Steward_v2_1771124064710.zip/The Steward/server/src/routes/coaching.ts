import { Router, Response } from 'express';
import { AuthenticatedRequest } from '../middleware/auth';
import { supabase } from '../db/supabase';
import { routeToLLM } from '../services/llmRouter';

const router = Router();

router.post('/chat', async (req: AuthenticatedRequest, res: Response) => {
  const { message } = req.body;
  if (!message) { res.status(400).json({ error: 'Message required' }); return; }

  try {
    // Load user settings for preferred LLM
    const { data: settings } = await supabase
      .from('user_settings').select('preferred_llm').eq('user_id', req.user?.id).single();

    // Load bias profile for context injection
    const { data: profile } = await supabase
      .from('bias_profiles').select('*').eq('user_id', req.user?.id).single();

    const provider = settings?.preferred_llm || 'claude';
    const response = await routeToLLM(provider, message, {
      bias_profile: profile || undefined,
      user_id: req.user?.id,
    });

    // Log coaching interaction
    await supabase.from('coaching_log').insert({
      user_id: req.user?.id,
      llm_provider: provider,
      prompt_summary: message.substring(0, 200),
      response_summary: response.message.substring(0, 500),
    });

    res.json(response);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.get('/history', async (req: AuthenticatedRequest, res: Response) => {
  const { data } = await supabase.from('coaching_log')
    .select('*').eq('user_id', req.user?.id)
    .order('created_at', { ascending: false }).limit(50);
  res.json(data || []);
});

export default router;
