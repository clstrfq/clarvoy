import { Router, Response } from 'express';
import { supabase } from '../db/supabase';
import { AuthenticatedRequest } from '../middleware/auth';

const router = Router();

router.get('/', async (req: AuthenticatedRequest, res: Response) => {
  const { data, error } = await supabase.from('decisions').select('*').order('created_at', { ascending: false });
  if (error) { res.status(500).json({ error: error.message }); return; }
  res.json(data);
});

router.get('/:id', async (req: AuthenticatedRequest, res: Response) => {
  const { data, error } = await supabase.from('decisions').select('*').eq('id', req.params.id).single();
  if (error) { res.status(404).json({ error: 'Decision not found' }); return; }
  res.json(data);
});

router.post('/', async (req: AuthenticatedRequest, res: Response) => {
  const { title, description, value_amount, reference_class_id } = req.body;
  const { data, error } = await supabase.from('decisions').insert({
    title, description, value_amount, reference_class_id,
    status: 'OPEN', created_by: req.user?.id,
  }).select().single();
  if (error) { res.status(400).json({ error: error.message }); return; }
  res.status(201).json(data);
});

router.put('/:id', async (req: AuthenticatedRequest, res: Response) => {
  const { data, error } = await supabase.from('decisions')
    .update({ ...req.body, updated_at: new Date().toISOString() })
    .eq('id', req.params.id).select().single();
  if (error) { res.status(400).json({ error: error.message }); return; }
  res.json(data);
});

export default router;
