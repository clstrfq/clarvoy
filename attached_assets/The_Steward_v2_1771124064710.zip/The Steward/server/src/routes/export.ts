// Law 7: Data Sovereignty (Anti-Caging) — All data exportable
import { Router, Response } from 'express';
import { AuthenticatedRequest } from '../middleware/auth';
import { supabase } from '../db/supabase';

const router = Router();

router.get('/:format', async (req: AuthenticatedRequest, res: Response) => {
  const { format } = req.params;
  const userId = req.user?.id;

  const [decisions, judgments, coaching, voiceNotes] = await Promise.all([
    supabase.from('decisions').select('*').eq('created_by', userId),
    supabase.from('judgments').select('*').eq('user_id', userId),
    supabase.from('coaching_log').select('*').eq('user_id', userId),
    supabase.from('voice_notes').select('id, transcript, duration_seconds, created_at').eq('user_id', userId),
  ]);

  const exportData = {
    exported_at: new Date().toISOString(),
    user_id: userId,
    law_reference: 'Law 7: Data Sovereignty — Your data is never caged.',
    decisions: decisions.data || [],
    judgments: judgments.data || [],
    coaching_sessions: coaching.data || [],
    voice_transcripts: voiceNotes.data || [],
  };

  if (format === 'json') {
    res.setHeader('Content-Type', 'application/json');
    res.setHeader('Content-Disposition', 'attachment; filename=steward-export.json');
    res.json(exportData);
  } else if (format === 'csv') {
    // Simplified CSV for decisions
    const csv = ['id,title,status,value_amount,created_at',
      ...(exportData.decisions as any[]).map((d: any) => `${d.id},${d.title},${d.status},${d.value_amount},${d.created_at}`)
    ].join('\n');
    res.setHeader('Content-Type', 'text/csv');
    res.setHeader('Content-Disposition', 'attachment; filename=steward-export.csv');
    res.send(csv);
  } else {
    res.status(400).json({ error: 'Supported formats: json, csv' });
  }
});

export default router;
