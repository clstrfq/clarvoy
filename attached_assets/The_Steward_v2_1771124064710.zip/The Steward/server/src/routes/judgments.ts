// =============================================================================
// THE STEWARD — Judgments Route
// =============================================================================
// Implements: Law 2 (Noise Intolerance) - Blind Input & Information Cascade Block
// Rule 3: GET endpoint MUST check count(submitted) === count(assigned) before
//         returning ANY data.
import { Router, Response } from 'express';
import { supabase } from '../db/supabase';
import { AuthenticatedRequest } from '../middleware/auth';

const router = Router();

// Submit blind judgment
router.post('/', async (req: AuthenticatedRequest, res: Response) => {
  const { decision_id, score_quant, rationale_qual, hash_integrity } = req.body;

  // Validation: min 100 chars for rationale (Constitution)
  if (!rationale_qual || rationale_qual.length < 100) {
    res.status(400).json({ error: 'Rationale must be at least 100 characters (Law 2)' });
    return;
  }
  if (score_quant < 1 || score_quant > 10) {
    res.status(400).json({ error: 'Score must be between 1 and 10' });
    return;
  }

  const { data, error } = await supabase.from('judgments').insert({
    decision_id, user_id: req.user?.id,
    score_quant, rationale_qual, hash_integrity,
  }).select().single();

  if (error) { res.status(400).json({ error: error.message }); return; }
  res.status(201).json(data);
});

// Get results — BLOCKED until all submissions complete (Law 2)
router.get('/:decisionId', async (req: AuthenticatedRequest, res: Response) => {
  const { decisionId } = req.params;

  // Count submitted vs assigned
  const { count: submitted } = await supabase
    .from('judgments').select('*', { count: 'exact', head: true })
    .eq('decision_id', decisionId);

  // For now, assume 5 assigned committee members (configurable per decision)
  const totalAssigned = 5;

  // CONSTITUTIONAL CHECK: Block results until all submitted
  if ((submitted || 0) < totalAssigned) {
    res.json({
      status: 'pending',
      submitted: submitted || 0,
      total: totalAssigned,
      // NO scores, NO rationales, NO hints — Law 2 enforcement
    });
    return;
  }

  // All submitted — release results
  const { data: judgments } = await supabase
    .from('judgments').select('*').eq('decision_id', decisionId);

  const scores = (judgments || []).map((j: any) => j.score_quant);
  const mean = scores.reduce((a: number, b: number) => a + b, 0) / scores.length;
  const stdDev = Math.sqrt(scores.reduce((sum: number, s: number) => sum + Math.pow(s - mean, 2), 0) / (scores.length - 1));

  res.json({
    status: 'complete',
    judgments,
    variance: {
      mean: parseFloat(mean.toFixed(4)),
      std_dev: parseFloat(stdDev.toFixed(4)),
      cv: mean !== 0 ? parseFloat((stdDev / mean).toFixed(4)) : null,
      is_high_noise: stdDev > 1.5,
      scores,
    },
  });
});

export default router;
