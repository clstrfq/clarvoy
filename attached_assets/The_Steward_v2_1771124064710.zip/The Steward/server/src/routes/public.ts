// =============================================================================
// THE STEWARD — Public Transparency API (Law 8: Radical Transparency)
// =============================================================================
import { Router, Request, Response } from 'express';
import { supabase } from '../db/supabase';

const router = Router();

// Glass Wall API — No auth required
router.get('/resource-distribution', async (_req: Request, res: Response) => {
  const { data } = await supabase.from('decisions')
    .select('id, title, status, value_amount, created_at')
    .in('status', ['APPROVED', 'REJECTED']);

  // Privacy-masked: No PII, no user IDs, only aggregated decision data
  const masked = (data || []).map((d: any) => ({
    decision_id: d.id,
    title: d.title,
    status: d.status,
    value: d.value_amount,
    date: d.created_at,
  }));

  res.json({
    transparency_level: 'GLASS_WALL',
    law_reference: 'Law 8: Radical Transparency',
    data: masked,
    generated_at: new Date().toISOString(),
  });
});

export default router;
