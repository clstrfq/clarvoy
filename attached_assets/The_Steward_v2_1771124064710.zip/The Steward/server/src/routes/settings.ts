import { Router, Response } from 'express';
import { AuthenticatedRequest } from '../middleware/auth';
import { supabase } from '../db/supabase';

const router = Router();

router.get('/', async (req: AuthenticatedRequest, res: Response) => {
  const { data } = await supabase.from('user_settings').select('*').eq('user_id', req.user?.id).single();
  res.json(data);
});

router.put('/', async (req: AuthenticatedRequest, res: Response) => {
  const { data, error } = await supabase.from('user_settings')
    .upsert({ user_id: req.user?.id, ...req.body, updated_at: new Date().toISOString() }, { onConflict: 'user_id' })
    .select().single();
  if (error) { res.status(400).json({ error: error.message }); return; }
  res.json(data);
});

export default router;
