import { Router, Response } from 'express';
import axios from 'axios';
import { AuthenticatedRequest } from '../middleware/auth';
import { supabase } from '../db/supabase';

const router = Router();
const PYTHON_URL = process.env.PYTHON_SERVICE_URL || 'http://localhost:8000';

router.post('/run', async (req: AuthenticatedRequest, res: Response) => {
  try {
    const result = await axios.post(`${PYTHON_URL}/simulations/run`, req.body);
    // Store results
    await supabase.from('simulations').insert({
      decision_id: req.body.decision_id,
      run_count: result.data.run_count,
      p5_outcome: result.data.p5_outcome,
      p50_outcome: result.data.p50_outcome,
      p95_outcome: result.data.p95_outcome,
      distribution_data: result.data.distribution_data,
      perturbation_params: result.data.perturbation_params,
    });
    res.json(result.data);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.get('/:decisionId', async (req: AuthenticatedRequest, res: Response) => {
  const { data } = await supabase.from('simulations')
    .select('*').eq('decision_id', req.params.decisionId)
    .order('created_at', { ascending: false });
  res.json(data || []);
});

export default router;
