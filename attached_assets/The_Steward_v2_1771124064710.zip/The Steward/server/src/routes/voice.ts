// Law 11: Voice Sovereignty
import { Router, Response } from 'express';
import { AuthenticatedRequest } from '../middleware/auth';
import { supabase } from '../db/supabase';

const router = Router();

router.post('/upload', async (req: AuthenticatedRequest, res: Response) => {
  const { decision_id, transcript, duration_seconds, consent_recorded, two_party_consent } = req.body;
  if (!consent_recorded) {
    res.status(400).json({ error: 'Recording consent is required (Law 11)' });
    return;
  }
  const { data, error } = await supabase.from('voice_notes').insert({
    user_id: req.user?.id, decision_id, transcript, duration_seconds,
    consent_recorded, two_party_consent,
    audio_expires_at: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString(),
  }).select().single();
  if (error) { res.status(400).json({ error: error.message }); return; }
  res.status(201).json(data);
});

export default router;
