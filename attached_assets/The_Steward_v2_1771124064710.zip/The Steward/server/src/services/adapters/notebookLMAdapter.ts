// NotebookLM routes through Gemini API
import { sendGemini } from './geminiAdapter';

export async function sendNotebookLM(systemPrompt: string, userMessage: string): Promise<string> {
  return sendGemini(systemPrompt + '\n\nMode: Document-grounded coaching with source synthesis.', userMessage);
}
