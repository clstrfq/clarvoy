import axios from 'axios';

export async function sendPerplexity(systemPrompt: string, userMessage: string): Promise<string> {
  const response = await axios.post('https://api.perplexity.ai/chat/completions', {
    model: 'sonar-pro',
    messages: [
      { role: 'system', content: systemPrompt },
      { role: 'user', content: userMessage },
    ],
    max_tokens: 1024,
  }, {
    headers: {
      'Authorization': `Bearer ${process.env.PERPLEXITY_API_KEY}`,
      'Content-Type': 'application/json',
    },
  });
  return response.data.choices[0]?.message?.content || 'No response generated.';
}
