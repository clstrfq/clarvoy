import { supabase } from '../db/supabase';

export async function logAuditEntry(entry: {
  decision_id?: string;
  user_id?: string;
  judgment_id?: string;
  detected_fallacies?: any;
  bias_severity?: string;
  bias_category?: string;
  decision_category?: string;
}) {
  const { error } = await supabase.from('audit_log').insert(entry);
  if (error) console.error('[AuditService] Failed to log:', error);
}
