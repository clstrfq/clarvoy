// =============================================================================
// THE STEWARD — Bias Engine (Law 4: Governance Backdoor)
// =============================================================================
import { supabase } from '../db/supabase';
import { routeToLLM } from './llmRouter';

const DEBATE_PROMPT = `You are a skilled debater and critical thinker. Your task is to identify logical fallacies and weak assumptions in the following rationale. Generate:
1. Three specific logical fallacies or cognitive biases present in the reasoning
2. A vigorous, evidence-based counter-argument
3. Rate the severity: LOW, MEDIUM, HIGH, or CRITICAL

Respond in JSON format:
{ "fallacies": [{"type": "...", "confidence": 0.0-1.0, "evidence": "..."}], "counter_argument": "...", "severity": "..." }`;

export async function analyzeBias(payload: {
  id: string;
  endpoint: string;
  userId: string | null;
  body: Record<string, unknown>;
}) {
  try {
    const rationale = (payload.body.rationale_qual as string) || JSON.stringify(payload.body);
    const response = await routeToLLM('claude', `${DEBATE_PROMPT}\n\nRationale to analyze:\n${rationale}`, {});

    let parsed;
    try { parsed = JSON.parse(response.message); } catch { parsed = { fallacies: [], counter_argument: response.message, severity: 'LOW' }; }

    await supabase.from('audit_log').insert({
      decision_id: payload.body.decision_id || null,
      user_id: payload.userId,
      detected_fallacies: parsed.fallacies,
      debate_counter_argument: parsed.counter_argument,
      bias_severity: parsed.severity,
    });
  } catch (error) {
    console.error('[BiasEngine] Analysis failed:', error);
  }
}
