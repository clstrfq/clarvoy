// =============================================================================
// THE STEWARD — Heat Map Generator (Law 12)
// =============================================================================
import { supabase } from '../db/supabase';

const BIAS_TYPES = ['SUNK_COST', 'HALO_EFFECT', 'ANCHORING', 'CONFIRMATION_BIAS', 'RECENCY_BIAS', 'LOSS_AVERSION', 'OPTIMISM_BIAS', 'GROUPTHINK'];
const DECISION_CATEGORIES = ['GRANT_ALLOCATION', 'BUDGET_APPROVAL', 'STRATEGIC_PLANNING', 'PERSONNEL'];

export async function generateDailyHeatmap(): Promise<void> {
  const today = new Date().toISOString().split('T')[0];
  const yesterday = new Date(Date.now() - 86400000).toISOString();

  const { data: entries } = await supabase.from('audit_log')
    .select('*').gte('created_at', yesterday);

  // Build matrix: bias_type × decision_category
  const matrix = BIAS_TYPES.map((bias) =>
    DECISION_CATEGORIES.map((cat) =>
      (entries || []).filter((e: any) => e.bias_category === bias && e.decision_category === cat).length
    )
  );

  const totalDetections = (entries || []).length;
  const criticalCount = (entries || []).filter((e: any) => e.bias_severity === 'CRITICAL').length;

  await supabase.from('bias_heatmap_cache').upsert({
    report_date: today,
    heatmap_data: { matrix, labels: { x: BIAS_TYPES, y: DECISION_CATEGORIES } },
    total_detections: totalDetections,
    critical_count: criticalCount,
  }, { onConflict: 'report_date' });

  console.log(`[HeatmapGenerator] Generated for ${today}: ${totalDetections} detections, ${criticalCount} critical`);
}
