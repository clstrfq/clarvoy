// =============================================================================
// THE STEWARD — LLM Router Service
// =============================================================================
// Implements: Law 9 (LLM Provider Sovereignty)
// Routes coaching requests to user's preferred LLM provider.
import { sendGemini } from './adapters/geminiAdapter';
import { sendClaude } from './adapters/claudeAdapter';
import { sendOpenAI } from './adapters/openaiAdapter';
import { sendPerplexity } from './adapters/perplexityAdapter';

const COACHING_SYSTEM_PROMPT = `You are The Steward's Decision Hygiene Coach. You operate within a System 2 Governance framework designed to help non-profit leaders make higher-quality decisions.

Your role is NOT to make decisions. Your role is to:
1. Surface cognitive biases the user may not be aware of.
2. Reference specific instances from the user's decision history.
3. Suggest concrete debiasing exercises (pre-mortem, consider-the-opposite, reference class check).
4. Flag when the user's language suggests high certainty despite low data confidence.
5. Encourage probabilistic thinking over deterministic predictions.

CONSTRAINTS:
- Never make decisions for the user. Only provide frameworks and context.
- Always present uncertainty. Never say "you should" without acknowledging alternatives.
- If the user asks you to "just tell me what to do," respond: "My role is to illuminate, not decide."
- Reference the 98% Return on Donation goal when relevant.
- If you detect language patterns associated with known biases, name the bias explicitly.`;

interface LLMContext {
  bias_profile?: any;
  user_id?: string;
}

export async function routeToLLM(
  provider: string,
  message: string,
  context: LLMContext
): Promise<{ message: string; provider: string }> {
  const contextStr = context.bias_profile
    ? `\n\nUser Context: Bias Profile - ${JSON.stringify(context.bias_profile)}`
    : '';

  const fullPrompt = message + contextStr;

  try {
    switch (provider) {
      case 'gemini':
      case 'notebooklm':
        return { message: await sendGemini(COACHING_SYSTEM_PROMPT, fullPrompt), provider };
      case 'claude':
        return { message: await sendClaude(COACHING_SYSTEM_PROMPT, fullPrompt), provider };
      case 'chatgpt':
        return { message: await sendOpenAI(COACHING_SYSTEM_PROMPT, fullPrompt), provider };
      case 'perplexity':
        return { message: await sendPerplexity(COACHING_SYSTEM_PROMPT, fullPrompt), provider };
      default:
        // Fallback to Claude
        return { message: await sendClaude(COACHING_SYSTEM_PROMPT, fullPrompt), provider: 'claude' };
    }
  } catch (error: any) {
    console.error(`[LLMRouter] ${provider} failed:`, error.message);
    // Fallback chain: try Claude, then OpenAI
    if (provider !== 'claude') {
      try { return { message: await sendClaude(COACHING_SYSTEM_PROMPT, fullPrompt), provider: 'claude (fallback)' }; }
      catch { /* continue to next fallback */ }
    }
    throw new Error(`All LLM providers failed: ${error.message}`);
  }
}
