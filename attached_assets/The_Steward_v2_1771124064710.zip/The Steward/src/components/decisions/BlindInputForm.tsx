// =============================================================================
// THE STEWARD — Blind Input Form
// =============================================================================
// Implements: Law 2 (Noise Intolerance), Guardrail 4 (Immutable Logging)
// "No group decision process may begin until ALL individual, blind judgments
//  are cryptographically hashed and recorded."
// =============================================================================

import React, { useState } from 'react';
import { View, Text, TextInput, StyleSheet, Alert } from 'react-native';
import { useForm, Controller } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import Slider from '@react-native-community/slider';
import Card from '../ui/Card';
import FrictionButton from '../ui/FrictionButton';
import { colors, typography, spacing, borderRadius } from '../../config/theme';
import { RATIONALE_MIN_CHARS, SCORE_RANGE } from '../../config/constants';
import { hashJudgment } from '../../utils/crypto';
import { useSubmitJudgment } from '../../hooks/useJudgments';
import { useAuthStore } from '../../stores/authStore';

const schema = z.object({
  score_quant: z.number().min(SCORE_RANGE.min).max(SCORE_RANGE.max),
  rationale_qual: z.string().min(RATIONALE_MIN_CHARS, `Minimum ${RATIONALE_MIN_CHARS} characters required`),
});

type FormData = z.infer<typeof schema>;

interface BlindInputFormProps {
  decisionId: string;
  onSubmitted?: () => void;
}

export default function BlindInputForm({ decisionId, onSubmitted }: BlindInputFormProps) {
  const user = useAuthStore((s) => s.user);
  const submitMutation = useSubmitJudgment();
  const [score, setScore] = useState(5);

  const { control, handleSubmit, watch, formState: { errors, isValid } } = useForm<FormData>({
    resolver: zodResolver(schema),
    defaultValues: { score_quant: 5, rationale_qual: '' },
    mode: 'onChange',
  });

  const rationale = watch('rationale_qual') || '';
  const charCount = rationale.length;

  const onSubmit = async (data: FormData) => {
    if (!user) return;
    try {
      const hash = await hashJudgment(decisionId, user.id, data.score_quant, data.rationale_qual);
      await submitMutation.mutateAsync({
        decision_id: decisionId,
        score_quant: data.score_quant,
        rationale_qual: data.rationale_qual,
        hash_integrity: hash,
      });
      Alert.alert('Judgment Sealed', 'Your judgment has been sealed. It cannot be modified.');
      onSubmitted?.();
    } catch (error) {
      Alert.alert('Error', 'Failed to submit judgment. Please try again.');
    }
  };

  return (
    <Card>
      <Text style={styles.title}>Blind Assessment</Text>
      <Text style={styles.description}>
        Your assessment is independent and sealed. You cannot view others' scores until all committee members have submitted.
      </Text>

      {/* Score Slider */}
      <View style={styles.scoreSection}>
        <Text style={styles.label}>Quantitative Score</Text>
        <Controller
          name="score_quant"
          control={control}
          render={({ field: { onChange } }) => (
            <View>
              <Text style={styles.scoreValue}>{score}</Text>
              <Slider
                style={styles.slider}
                minimumValue={SCORE_RANGE.min}
                maximumValue={SCORE_RANGE.max}
                step={1}
                value={score}
                onValueChange={(v) => { setScore(v); onChange(v); }}
                minimumTrackTintColor={colors.primary}
                maximumTrackTintColor={colors.border}
                thumbTintColor={colors.primary}
              />
              <View style={styles.scoreLabels}>
                <Text style={styles.caption}>1 — Reject</Text>
                <Text style={styles.caption}>10 — Strong Approve</Text>
              </View>
            </View>
          )}
        />
      </View>

      {/* Rationale */}
      <View style={styles.rationaleSection}>
        <Text style={styles.label}>Qualitative Rationale</Text>
        <Controller
          name="rationale_qual"
          control={control}
          render={({ field: { onChange, value } }) => (
            <TextInput
              style={[styles.textInput, errors.rationale_qual && styles.inputError]}
              multiline
              numberOfLines={6}
              placeholder="Provide your independent reasoning (minimum 100 characters)..."
              placeholderTextColor={colors.textSecondary}
              value={value}
              onChangeText={onChange}
              textAlignVertical="top"
            />
          )}
        />
        <Text style={[styles.charCount, charCount < RATIONALE_MIN_CHARS && styles.charCountWarning]}>
          {charCount}/{RATIONALE_MIN_CHARS} characters
        </Text>
        {errors.rationale_qual && (
          <Text style={styles.errorText}>{errors.rationale_qual.message}</Text>
        )}
      </View>

      <FrictionButton
        title="Seal My Judgment"
        onPress={handleSubmit(onSubmit)}
        disabled={!isValid || submitMutation.isPending}
        confirmationText="Your judgment will be cryptographically sealed"
      />
    </Card>
  );
}

const styles = StyleSheet.create({
  title: { ...typography.heading2, marginBottom: spacing.xs },
  description: { ...typography.bodySmall, color: colors.textSecondary, marginBottom: spacing.lg },
  scoreSection: { marginBottom: spacing.lg },
  label: { ...typography.body, fontWeight: '600', marginBottom: spacing.sm },
  scoreValue: { fontSize: 48, fontWeight: '700', color: colors.primary, textAlign: 'center' },
  slider: { width: '100%', height: 40 },
  scoreLabels: { flexDirection: 'row', justifyContent: 'space-between' },
  caption: { ...typography.caption },
  rationaleSection: { marginBottom: spacing.lg },
  textInput: {
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: borderRadius.md,
    padding: spacing.md,
    ...typography.body,
    minHeight: 140,
  },
  inputError: { borderColor: colors.danger },
  charCount: { ...typography.caption, textAlign: 'right', marginTop: spacing.xs },
  charCountWarning: { color: colors.warning },
  errorText: { ...typography.caption, color: colors.danger, marginTop: spacing.xs },
});
