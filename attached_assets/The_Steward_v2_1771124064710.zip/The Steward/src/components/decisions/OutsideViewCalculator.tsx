// =============================================================================
// THE STEWARD — Outside View Calculator
// =============================================================================
// Implements: Law 3 (The Outside View / Reference Class Supremacy)
// "Reference Class Forecasting is MANDATORY for all budgets and timelines."
// Submit button is DISABLED until divergence justification is entered.
// =============================================================================

import React, { useState } from 'react';
import { View, Text, TextInput, StyleSheet, Alert } from 'react-native';
import Card from '../ui/Card';
import Button from '../ui/Button';
import Modal from '../ui/Modal';
import { colors, typography, spacing, borderRadius } from '../../config/theme';
import { DIVERGENCE_JUSTIFICATION_MIN_CHARS } from '../../config/constants';
import { ReferenceClass } from '../../types';

interface OutsideViewCalculatorProps {
  referenceClass: ReferenceClass | null;
  userEstimateBudget: number;
  userEstimateTimeline: number;
  onJustificationSubmitted: (justification: string) => void;
}

export default function OutsideViewCalculator({
  referenceClass,
  userEstimateBudget,
  userEstimateTimeline,
  onJustificationSubmitted,
}: OutsideViewCalculatorProps) {
  const [showAlert, setShowAlert] = useState(true);
  const [justification, setJustification] = useState('');

  if (!referenceClass) return null;

  const adjustedBudget = userEstimateBudget * (1 + referenceClass.avg_cost_overrun / 100);
  const adjustedTimeline = userEstimateTimeline * (1 + referenceClass.avg_time_overrun / 100);
  const budgetDeviation = Math.round(
    ((userEstimateBudget - adjustedBudget) / adjustedBudget) * 100
  );

  const canSubmit = justification.length >= DIVERGENCE_JUSTIFICATION_MIN_CHARS;

  return (
    <Card>
      <Text style={styles.title}>Outside View Check</Text>
      <Text style={styles.subtitle}>Reference Class: {referenceClass.category}</Text>
      <Text style={styles.source}>Source: {referenceClass.source} (n={referenceClass.sample_size})</Text>

      {/* Reality Check Modal — UNDISMISSABLE per Law 6 */}
      <Modal
        visible={showAlert}
        title="Reality Check — Outside View"
        undismissable
        actions={[{ label: 'Acknowledge & Provide Justification', onPress: () => setShowAlert(false) }]}
      >
        <Text style={styles.alertText}>
          Historical data suggests a final cost of ${adjustedBudget.toLocaleString()} and timeline of{' '}
          {adjustedTimeline.toFixed(1)} months. Your estimate is {Math.abs(budgetDeviation)}% more
          optimistic than the Reference Class.
        </Text>
        <View style={styles.statRow}>
          <Text style={styles.statLabel}>Avg Cost Overrun:</Text>
          <Text style={styles.statValue}>+{referenceClass.avg_cost_overrun}%</Text>
        </View>
        <View style={styles.statRow}>
          <Text style={styles.statLabel}>Avg Time Overrun:</Text>
          <Text style={styles.statValue}>+{referenceClass.avg_time_overrun}%</Text>
        </View>
        <View style={styles.statRow}>
          <Text style={styles.statLabel}>Base Rate Failure:</Text>
          <Text style={[styles.statValue, { color: colors.danger }]}>
            {(referenceClass.base_rate_failure * 100).toFixed(0)}%
          </Text>
        </View>
      </Modal>

      {/* Divergence Justification — BLOCKING per Law 3 */}
      <View style={styles.justificationSection}>
        <Text style={styles.label}>Divergence Justification (Required)</Text>
        <Text style={styles.hint}>
          Cite specific, validated distinctives that exempt this project from the reference class average.
        </Text>
        <TextInput
          style={styles.textInput}
          multiline
          numberOfLines={6}
          placeholder={`Minimum ${DIVERGENCE_JUSTIFICATION_MIN_CHARS} characters...`}
          placeholderTextColor={colors.textSecondary}
          value={justification}
          onChangeText={setJustification}
          textAlignVertical="top"
        />
        <Text style={[styles.charCount, !canSubmit && styles.charCountWarning]}>
          {justification.length}/{DIVERGENCE_JUSTIFICATION_MIN_CHARS}
        </Text>
      </View>

      <Button
        title="Submit Justification"
        onPress={() => onJustificationSubmitted(justification)}
        disabled={!canSubmit}
      />
    </Card>
  );
}

const styles = StyleSheet.create({
  title: { ...typography.heading2, marginBottom: spacing.xs },
  subtitle: { ...typography.body, fontWeight: '600', color: colors.primary },
  source: { ...typography.caption, marginBottom: spacing.md },
  alertText: { ...typography.body, marginBottom: spacing.md },
  statRow: { flexDirection: 'row', justifyContent: 'space-between', paddingVertical: spacing.xs },
  statLabel: { ...typography.bodySmall, color: colors.textSecondary },
  statValue: { ...typography.bodySmall, fontWeight: '600' },
  justificationSection: { marginVertical: spacing.md },
  label: { ...typography.body, fontWeight: '600', marginBottom: spacing.xs },
  hint: { ...typography.caption, color: colors.textSecondary, marginBottom: spacing.sm },
  textInput: {
    borderWidth: 1, borderColor: colors.border, borderRadius: borderRadius.md,
    padding: spacing.md, ...typography.body, minHeight: 120,
  },
  charCount: { ...typography.caption, textAlign: 'right', marginTop: spacing.xs },
  charCountWarning: { color: colors.warning },
});
