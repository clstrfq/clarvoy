// =============================================================================
// THE STEWARD — Pre-Mortem Input
// =============================================================================
// Implements: Law 1, Law 5
// "Mandatory text field: The year is 2028. This mission has failed..."
import React, { useState } from 'react';
import { View, Text, TextInput, StyleSheet } from 'react-native';
import Card from '../ui/Card';
import FrictionButton from '../ui/FrictionButton';
import { colors, typography, spacing, borderRadius } from '../../config/theme';

interface PreMortemInputProps {
  decisionId: string;
  onSubmit: (narrative: string) => void;
}

export default function PreMortemInput({ decisionId, onSubmit }: PreMortemInputProps) {
  const [narrative, setNarrative] = useState('');

  return (
    <Card>
      <Text style={styles.title}>Pre-Mortem Analysis</Text>
      <View style={styles.promptBox}>
        <Text style={styles.prompt}>
          "The year is 2028. This mission has failed. The donor base has vanished, and beneficiaries
          are harmed. Write the history of this disaster."
        </Text>
      </View>
      <TextInput
        style={styles.textInput}
        multiline
        numberOfLines={8}
        placeholder="Describe the failure scenario in detail..."
        placeholderTextColor={colors.textSecondary}
        value={narrative}
        onChangeText={setNarrative}
        textAlignVertical="top"
      />
      <FrictionButton
        title="Submit Pre-Mortem"
        onPress={() => onSubmit(narrative)}
        disabled={narrative.length < 100}
        confirmationText="This narrative will be logged for quarterly review"
      />
    </Card>
  );
}

const styles = StyleSheet.create({
  title: { ...typography.heading2, marginBottom: spacing.md },
  promptBox: {
    backgroundColor: 'rgba(255, 140, 0, 0.08)', padding: spacing.md,
    borderRadius: borderRadius.md, borderLeftWidth: 4, borderLeftColor: colors.warning,
    marginBottom: spacing.md,
  },
  prompt: { ...typography.body, fontStyle: 'italic', color: colors.textPrimary },
  textInput: {
    borderWidth: 1, borderColor: colors.border, borderRadius: borderRadius.md,
    padding: spacing.md, ...typography.body, minHeight: 180, marginBottom: spacing.md,
  },
});
