// =============================================================================
// THE STEWARD — Variance Display
// =============================================================================
import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import Card from '../ui/Card';
import UncertaintyBadge from '../ui/UncertaintyBadge';
import { colors, typography, spacing } from '../../config/theme';
import { VarianceResult } from '../../types';
import { NOISE_THRESHOLD } from '../../config/constants';

interface VarianceDisplayProps {
  variance: VarianceResult;
}

export default function VarianceDisplay({ variance }: VarianceDisplayProps) {
  return (
    <Card style={variance.is_high_noise ? styles.alertCard : undefined}>
      {variance.is_high_noise && (
        <View style={styles.alertBanner}>
          <Text style={styles.alertIcon}>⚠</Text>
          <Text style={styles.alertText}>
            High Disagreement Detected. Do not move to consensus until variance is explored.
          </Text>
        </View>
      )}
      <View style={styles.metrics}>
        <View style={styles.metricItem}>
          <Text style={styles.metricLabel}>Mean (μ)</Text>
          <Text style={styles.metricValue}>{variance.mean.toFixed(2)}</Text>
        </View>
        <View style={styles.metricItem}>
          <Text style={styles.metricLabel}>Std Dev (σ)</Text>
          <Text style={[styles.metricValue, variance.is_high_noise && styles.dangerValue]}>
            {variance.std_dev.toFixed(2)}
          </Text>
        </View>
        <View style={styles.metricItem}>
          <Text style={styles.metricLabel}>CV</Text>
          <Text style={styles.metricValue}>{variance.cv.toFixed(2)}</Text>
        </View>
      </View>
      <UncertaintyBadge
        confidence={Math.max(0, 1 - (variance.std_dev / NOISE_THRESHOLD))}
        label="Noise Score"
      />
    </Card>
  );
}

const styles = StyleSheet.create({
  alertCard: { borderWidth: 2, borderColor: colors.danger },
  alertBanner: {
    flexDirection: 'row', backgroundColor: 'rgba(231, 76, 60, 0.1)',
    padding: spacing.sm, borderRadius: 6, marginBottom: spacing.md, gap: 8,
  },
  alertIcon: { fontSize: 18 },
  alertText: { ...typography.bodySmall, color: colors.danger, flex: 1, fontWeight: '600' },
  metrics: { flexDirection: 'row', justifyContent: 'space-around', marginBottom: spacing.md },
  metricItem: { alignItems: 'center' },
  metricLabel: { ...typography.caption },
  metricValue: { fontSize: 24, fontWeight: '700', color: colors.textPrimary },
  dangerValue: { color: colors.danger },
});
