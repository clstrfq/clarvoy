// =============================================================================
// THE STEWARD — Base Button Component
// =============================================================================
import React from 'react';
import { TouchableOpacity, Text, StyleSheet, ActivityIndicator, ViewStyle, TextStyle } from 'react-native';
import { colors, typography, borderRadius, spacing } from '../../config/theme';

interface ButtonProps {
  title: string;
  onPress: () => void;
  variant?: 'primary' | 'secondary' | 'danger' | 'ghost';
  disabled?: boolean;
  loading?: boolean;
  style?: ViewStyle;
  textStyle?: TextStyle;
}

export default function Button({
  title, onPress, variant = 'primary', disabled = false, loading = false, style, textStyle,
}: ButtonProps) {
  const variantStyles = {
    primary: { bg: colors.primary, text: '#FFFFFF' },
    secondary: { bg: colors.secondary, text: '#FFFFFF' },
    danger: { bg: colors.danger, text: '#FFFFFF' },
    ghost: { bg: 'transparent', text: colors.primary },
  };
  const v = variantStyles[variant];

  return (
    <TouchableOpacity
      style={[styles.base, { backgroundColor: v.bg }, disabled && styles.disabled, style]}
      onPress={onPress}
      disabled={disabled || loading}
      activeOpacity={0.7}
    >
      {loading ? (
        <ActivityIndicator color={v.text} />
      ) : (
        <Text style={[styles.text, { color: v.text }, textStyle]}>{title}</Text>
      )}
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  base: {
    paddingVertical: spacing.md,
    paddingHorizontal: spacing.lg,
    borderRadius: borderRadius.md,
    alignItems: 'center',
    justifyContent: 'center',
    minHeight: 48,
  },
  text: { ...typography.button },
  disabled: { opacity: 0.4 },
});
