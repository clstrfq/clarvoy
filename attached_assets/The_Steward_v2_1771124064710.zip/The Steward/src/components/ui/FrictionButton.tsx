// =============================================================================
// THE STEWARD — FrictionButton (3-Second Countdown Submit)
// =============================================================================
// Implements: Law 6 (Cognitive Sovereignty), spec.md Section 8.2.3
// "No quick approve buttons. Every approval requires at minimum 2 taps
//  and a rationale input. Mandatory 3-second delay on Submit Decision buttons."
//
// CONSTITUTIONAL REQUIREMENT: This component MUST be used for all
// "Submit Decision" and "Approve" buttons. Direct submission is forbidden.
// =============================================================================

import React, { useState, useRef, useCallback, useEffect } from 'react';
import {
  TouchableOpacity, Text, View, StyleSheet, Animated,
} from 'react-native';
import { colors, typography, spacing, borderRadius, frictionConfig } from '../../config/theme';

interface FrictionButtonProps {
  title: string;
  onPress: () => void;
  disabled?: boolean;
  variant?: 'primary' | 'danger';
  confirmationText?: string;
}

export default function FrictionButton({
  title,
  onPress,
  disabled = false,
  variant = 'primary',
  confirmationText = 'Hold to confirm your decision',
}: FrictionButtonProps) {
  const [phase, setPhase] = useState<'idle' | 'counting' | 'ready'>('idle');
  const [countdown, setCountdown] = useState(3);
  const progressAnim = useRef(new Animated.Value(0)).current;
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const startCountdown = useCallback(() => {
    if (disabled) return;
    setPhase('counting');
    setCountdown(3);
    progressAnim.setValue(0);

    Animated.timing(progressAnim, {
      toValue: 1,
      duration: frictionConfig.submitDelayMs,
      useNativeDriver: false,
    }).start();

    let remaining = 3;
    intervalRef.current = setInterval(() => {
      remaining -= 1;
      setCountdown(remaining);
      if (remaining <= 0) {
        if (intervalRef.current) clearInterval(intervalRef.current);
        setPhase('ready');
      }
    }, 1000);
  }, [disabled, progressAnim]);

  const handleConfirm = useCallback(() => {
    if (phase === 'ready') {
      onPress();
      setPhase('idle');
      setCountdown(3);
      progressAnim.setValue(0);
    }
  }, [phase, onPress, progressAnim]);

  useEffect(() => {
    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, []);

  const bgColor = variant === 'danger' ? colors.danger : colors.primary;
  const progressWidth = progressAnim.interpolate({
    inputRange: [0, 1],
    outputRange: ['0%', '100%'],
  });

  if (phase === 'idle') {
    return (
      <TouchableOpacity
        style={[styles.button, { backgroundColor: bgColor }, disabled && styles.disabled]}
        onPress={startCountdown}
        disabled={disabled}
        activeOpacity={0.7}
      >
        <Text style={styles.buttonText}>{title}</Text>
        <Text style={styles.subText}>{confirmationText}</Text>
      </TouchableOpacity>
    );
  }

  if (phase === 'counting') {
    return (
      <View style={[styles.button, styles.countingButton]}>
        <Animated.View style={[styles.progress, { width: progressWidth, backgroundColor: bgColor }]} />
        <View style={styles.countdownContent}>
          <Text style={[styles.buttonText, { color: colors.textPrimary }]}>
            Confirming in {countdown}...
          </Text>
          <Text style={[styles.subText, { color: colors.textSecondary }]}>
            System 2 thinking engaged
          </Text>
        </View>
      </View>
    );
  }

  // phase === 'ready'
  return (
    <TouchableOpacity
      style={[styles.button, { backgroundColor: colors.success }]}
      onPress={handleConfirm}
      activeOpacity={0.7}
    >
      <Text style={styles.buttonText}>Confirm: {title}</Text>
      <Text style={styles.subText}>Tap to execute</Text>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  button: {
    paddingVertical: spacing.md,
    paddingHorizontal: spacing.lg,
    borderRadius: borderRadius.md,
    alignItems: 'center',
    minHeight: 64,
    justifyContent: 'center',
  },
  disabled: { opacity: 0.4 },
  buttonText: { ...typography.button, color: '#FFFFFF' },
  subText: { ...typography.caption, color: 'rgba(255,255,255,0.7)', marginTop: 2 },
  countingButton: {
    backgroundColor: colors.surface,
    borderWidth: 2,
    borderColor: colors.border,
    overflow: 'hidden',
  },
  progress: {
    position: 'absolute',
    left: 0,
    top: 0,
    bottom: 0,
    opacity: 0.15,
    borderRadius: borderRadius.md,
  },
  countdownContent: { alignItems: 'center', zIndex: 1 },
});
