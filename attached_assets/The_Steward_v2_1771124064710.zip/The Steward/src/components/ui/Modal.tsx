// =============================================================================
// THE STEWARD — Modal Component
// =============================================================================
// Supports "undismissable" mode per Law 6 (Cognitive Sovereignty)
// When undismissable=true, there is NO X button and user must choose an action.
import React, { ReactNode } from 'react';
import { Modal as RNModal, View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { colors, typography, spacing, borderRadius } from '../../config/theme';

interface ModalProps {
  visible: boolean;
  title: string;
  children: ReactNode;
  undismissable?: boolean;
  onClose?: () => void;
  actions?: { label: string; onPress: () => void; variant?: 'primary' | 'danger' }[];
}

export default function Modal({ visible, title, children, undismissable = false, onClose, actions }: ModalProps) {
  return (
    <RNModal visible={visible} transparent animationType="fade" onRequestClose={undismissable ? undefined : onClose}>
      <View style={styles.overlay}>
        <View style={styles.container}>
          <View style={styles.header}>
            <Text style={styles.title}>{title}</Text>
            {!undismissable && onClose && (
              <TouchableOpacity onPress={onClose} style={styles.closeBtn}>
                <Text style={styles.closeText}>×</Text>
              </TouchableOpacity>
            )}
          </View>
          <View style={styles.body}>{children}</View>
          {actions && actions.length > 0 && (
            <View style={styles.actions}>
              {actions.map((action, i) => (
                <TouchableOpacity
                  key={i}
                  style={[styles.actionBtn, action.variant === 'danger' && styles.dangerBtn]}
                  onPress={action.onPress}
                >
                  <Text style={styles.actionText}>{action.label}</Text>
                </TouchableOpacity>
              ))}
            </View>
          )}
        </View>
      </View>
    </RNModal>
  );
}

const styles = StyleSheet.create({
  overlay: { flex: 1, backgroundColor: colors.overlay, justifyContent: 'center', alignItems: 'center', padding: spacing.lg },
  container: { backgroundColor: '#FFFFFF', borderRadius: borderRadius.xl, width: '100%', maxWidth: 400 },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', padding: spacing.md, borderBottomWidth: 1, borderBottomColor: colors.border },
  title: { ...typography.heading3, flex: 1 },
  closeBtn: { padding: spacing.xs },
  closeText: { fontSize: 24, color: colors.textSecondary },
  body: { padding: spacing.md },
  actions: { flexDirection: 'row', justifyContent: 'flex-end', gap: spacing.sm, padding: spacing.md, borderTopWidth: 1, borderTopColor: colors.border },
  actionBtn: { backgroundColor: colors.primary, paddingVertical: spacing.sm, paddingHorizontal: spacing.md, borderRadius: borderRadius.md },
  dangerBtn: { backgroundColor: colors.danger },
  actionText: { ...typography.button, color: '#FFFFFF' },
});
