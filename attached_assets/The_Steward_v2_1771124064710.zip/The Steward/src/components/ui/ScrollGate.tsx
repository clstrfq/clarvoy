// =============================================================================
// THE STEWARD — ScrollGate
// =============================================================================
// Implements: Law 6 (Cognitive Sovereignty)
// "Scroll-to-bottom requirement for long-form risk assessments before the
//  Continue button activates."
// =============================================================================

import React, { useState, ReactNode } from 'react';
import { ScrollView, View, Text, StyleSheet, NativeSyntheticEvent, NativeScrollEvent } from 'react-native';
import { colors, typography, spacing, borderRadius, frictionConfig } from '../../config/theme';
import Button from './Button';

interface ScrollGateProps {
  children: ReactNode;
  onComplete: () => void;
  buttonTitle?: string;
}

export default function ScrollGate({
  children,
  onComplete,
  buttonTitle = 'I have reviewed this content',
}: ScrollGateProps) {
  const [hasScrolledToBottom, setHasScrolledToBottom] = useState(false);

  const handleScroll = (event: NativeSyntheticEvent<NativeScrollEvent>) => {
    const { layoutMeasurement, contentOffset, contentSize } = event.nativeEvent;
    const scrollProgress = (contentOffset.y + layoutMeasurement.height) / contentSize.height;
    if (scrollProgress >= frictionConfig.scrollGateThreshold) {
      setHasScrolledToBottom(true);
    }
  };

  return (
    <View style={styles.container}>
      <ScrollView
        style={styles.scrollView}
        onScroll={handleScroll}
        scrollEventThrottle={16}
      >
        {children}
        <View style={styles.scrollPadding} />
      </ScrollView>
      <View style={styles.footer}>
        {!hasScrolledToBottom && (
          <Text style={styles.hint}>Scroll to the bottom to continue</Text>
        )}
        <Button
          title={buttonTitle}
          onPress={onComplete}
          disabled={!hasScrolledToBottom}
        />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  scrollView: { flex: 1 },
  scrollPadding: { height: 40 },
  footer: { padding: spacing.md, borderTopWidth: 1, borderTopColor: colors.border },
  hint: { ...typography.caption, color: colors.warning, textAlign: 'center', marginBottom: spacing.sm },
});
