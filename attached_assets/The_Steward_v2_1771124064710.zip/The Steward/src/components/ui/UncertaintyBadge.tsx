// =============================================================================
// THE STEWARD — UncertaintyBadge
// =============================================================================
// Implements: Law 1 (Epistemic Rigor), Guardrail 2 (Epistemic Visualization)
// "Any output with a confidence interval below 70% must be rendered in
//  Uncertainty Orange (#FF8C00) with a visible warning icon."
//
// CONSTITUTIONAL REQUIREMENT: Every prediction MUST include this badge.
// Single-point predictions without CI are data integrity violations.
// =============================================================================

import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { colors, typography, spacing, borderRadius } from '../../config/theme';
import { CONFIDENCE_INTERVAL_THRESHOLD } from '../../config/constants';

interface UncertaintyBadgeProps {
  confidence: number; // 0-1 scale
  label?: string;
}

export default function UncertaintyBadge({ confidence, label }: UncertaintyBadgeProps) {
  const isLowConfidence = confidence < CONFIDENCE_INTERVAL_THRESHOLD;
  const percentage = Math.round(confidence * 100);

  return (
    <View style={[styles.badge, isLowConfidence ? styles.lowConfidence : styles.highConfidence]}>
      <Text style={styles.icon}>{isLowConfidence ? '⚠' : '✓'}</Text>
      <Text style={[styles.text, isLowConfidence && styles.lowText]}>
        {label || 'Confidence'}: {percentage}%
      </Text>
      {isLowConfidence && (
        <Text style={styles.warning}>Low confidence — treat with caution</Text>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  badge: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: spacing.xs,
    paddingHorizontal: spacing.sm,
    borderRadius: borderRadius.sm,
    flexWrap: 'wrap',
    gap: 4,
  },
  lowConfidence: { backgroundColor: 'rgba(255, 140, 0, 0.12)' },
  highConfidence: { backgroundColor: 'rgba(46, 204, 113, 0.12)' },
  icon: { fontSize: 14 },
  text: { ...typography.caption, color: colors.success },
  lowText: { color: colors.warning },
  warning: { ...typography.caption, color: colors.warning, width: '100%', marginTop: 2 },
});
