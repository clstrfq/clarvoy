// =============================================================================
// THE STEWARD — System Constants & Threshold Configuration
// =============================================================================
// Authority: constitution.md Part V (Key Metric Summary Table)
// These are the default values. Runtime overrides come from org_config table.

// --- Constitutional Thresholds ---

/** Law 1: Epistemic Rigor — CI below this triggers Uncertainty Orange */
export const CONFIDENCE_INTERVAL_THRESHOLD = 0.7;

/** Law 2: Noise Intolerance — σ above this triggers High Noise Alert */
export const NOISE_THRESHOLD = 1.5;

/** Law 3: The Outside View — Minimum chars for divergence justification */
export const DIVERGENCE_JUSTIFICATION_MIN_CHARS = 200;

/** Law 5: Outcome Binding — Primary outcome target */
export const RETURN_ON_DONATION_TARGET = 0.98;

/** Goliath Framework — Inequality ratio triggering Elite Capture warning */
export const INEQUALITY_RATIO_THRESHOLD = 5;

/** Anti-Efficiency Protocol — Minimum months of cash runway */
export const BURN_RATE_BUFFER_MONTHS = 6;

/** Pre-Mortem — Decisions above this value require pre-mortem */
export const PRE_MORTEM_VALUE_THRESHOLD = 50000;

/** Noise Audit — Minimum characters for judgment rationale */
export const RATIONALE_MIN_CHARS = 100;

/** Chaos Engine — Default Monte Carlo iterations */
export const SIMULATION_DEFAULT_RUNS = 100;

/** Voice — Hours before raw audio auto-deletion */
export const VOICE_RETENTION_HOURS = 24;

/** Email — Max seconds to hold raw email data */
export const EMAIL_EXTRACTION_WINDOW_SECONDS = 60;

/** Shadow Layer — Max latency for bias analysis response */
export const BIAS_DETECTION_LATENCY_SECONDS = 30;

/** LLM — Max acceptable response time */
export const LLM_RESPONSE_TIMEOUT_MS = 30000;

// --- Scoring Ranges ---

export const SCORE_RANGE = { min: 1, max: 10 } as const;

// --- False Consensus Detection ---

/** Cosine similarity below this with score gap < 1 = False Consensus */
export const FALSE_CONSENSUS_SIMILARITY_THRESHOLD = 0.5;

/** Score gap threshold for False Consensus check */
export const FALSE_CONSENSUS_SCORE_GAP = 1;

// --- Bias Types (for heat map and analysis) ---

export const BIAS_TYPES = [
  'SUNK_COST',
  'HALO_EFFECT',
  'ANCHORING',
  'CONFIRMATION_BIAS',
  'RECENCY_BIAS',
  'LOSS_AVERSION',
  'OPTIMISM_BIAS',
  'GROUPTHINK',
] as const;

export const BIAS_TYPE_LABELS: Record<string, string> = {
  SUNK_COST: 'Sunk Cost Fallacy',
  HALO_EFFECT: 'Halo Effect',
  ANCHORING: 'Anchoring Bias',
  CONFIRMATION_BIAS: 'Confirmation Bias',
  RECENCY_BIAS: 'Recency Bias',
  LOSS_AVERSION: 'Loss Aversion',
  OPTIMISM_BIAS: 'Optimism Bias',
  GROUPTHINK: 'Groupthink',
};

export const DECISION_CATEGORIES = [
  'GRANT_ALLOCATION',
  'BUDGET_APPROVAL',
  'STRATEGIC_PLANNING',
  'PERSONNEL',
] as const;

export const DECISION_CATEGORY_LABELS: Record<string, string> = {
  GRANT_ALLOCATION: 'Grant Allocation',
  BUDGET_APPROVAL: 'Budget Approval',
  STRATEGIC_PLANNING: 'Strategic Planning',
  PERSONNEL: 'Personnel',
};

// --- LLM Provider Configuration ---

export const LLM_PROVIDERS = [
  {
    id: 'gemini' as const,
    name: 'Google Gemini',
    model: 'gemini-2.5-pro',
    authMethod: 'oauth' as const,
    description: 'Conversational coaching, structured analysis',
  },
  {
    id: 'notebooklm' as const,
    name: 'Google NotebookLM',
    model: 'notebooklm-gemini',
    authMethod: 'oauth' as const,
    description: 'Document-grounded coaching, source synthesis',
  },
  {
    id: 'claude' as const,
    name: 'Anthropic Claude',
    model: 'claude-sonnet-4-5',
    authMethod: 'apikey' as const,
    description: 'Deep reasoning, adversarial debate generation',
  },
  {
    id: 'chatgpt' as const,
    name: 'OpenAI ChatGPT',
    model: 'gpt-4.1',
    authMethod: 'oauth' as const,
    description: 'General coaching, brainstorming',
  },
  {
    id: 'perplexity' as const,
    name: 'Perplexity',
    model: 'sonar-pro',
    authMethod: 'apikey' as const,
    description: 'Research-grounded coaching, citation-rich responses',
  },
] as const;

// --- Heat Map Color Stops ---

export const HEATMAP_COLOR_SCALE = [
  { threshold: 0, color: '#3498DB' },   // Blue — no/low detections
  { threshold: 3, color: '#2ECC71' },   // Green — moderate
  { threshold: 6, color: '#FF8C00' },   // Orange — high
  { threshold: 10, color: '#E74C3C' },  // Red — critical
] as const;

// --- API Endpoints ---

export const API_BASE_URL = process.env.EXPO_PUBLIC_API_URL || 'http://localhost:3000';

export const ENDPOINTS = {
  auth: {
    login: '/api/v1/auth/login',
    register: '/api/v1/auth/register',
  },
  decisions: {
    list: '/api/v1/decisions',
    create: '/api/v1/decisions',
    detail: (id: string) => `/api/v1/decisions/${id}`,
  },
  judgments: {
    submit: '/api/v1/judgments',
    results: (decisionId: string) => `/api/v1/judgments/${decisionId}`,
  },
  simulations: {
    run: '/api/v1/simulations/run',
    results: (decisionId: string) => `/api/v1/simulations/${decisionId}`,
  },
  coaching: {
    chat: '/api/v1/coaching/chat',
    history: '/api/v1/coaching/history',
  },
  voice: {
    upload: '/api/v1/voice/upload',
  },
  admin: {
    biasHeatmap: '/api/v1/admin/bias-heatmap',
    auditLog: '/api/v1/admin/audit-log',
    epistemicReport: '/api/v1/admin/epistemic-report',
    users: '/api/v1/admin/users',
  },
  settings: '/api/v1/settings',
  export: (format: string) => `/api/v1/export/${format}`,
  referenceClasses: '/api/v1/reference-classes',
  public: {
    resourceDistribution: '/public/api/v1/resource-distribution',
  },
} as const;
