// =============================================================================
// THE STEWARD — Design System Theme Configuration
// =============================================================================
// Authority: spec.md Section 8.2 (Design System)
// All color tokens and typography must match the specification exactly.

export const colors = {
  // Primary palette
  primary: '#1E3A5F',       // Headers, primary actions
  secondary: '#4A90D9',     // Secondary actions, links
  success: '#2ECC71',       // Positive indicators, low bias
  warning: '#FF8C00',       // UNCERTAINTY ORANGE — Law 1 (Epistemic Rigor)
  danger: '#E74C3C',        // High noise alerts, critical bias
  surface: '#F8F9FA',       // Card backgrounds
  background: '#FFFFFF',    // Screen backgrounds

  // Text
  textPrimary: '#2C3E50',   // Body text
  textSecondary: '#7F8C8D', // Placeholder, caption text
  textOnPrimary: '#FFFFFF', // Text on primary-colored backgrounds

  // Heat Map gradient (Law 12 — Daily Bias Heat Map)
  heatmap: {
    low: '#3498DB',          // Blue — low severity
    medium: '#2ECC71',       // Green — medium severity
    high: '#FF8C00',         // Orange — high severity
    critical: '#E74C3C',     // Red — critical severity
  },

  // Semantic
  border: '#E0E0E0',
  disabled: '#BDC3C7',
  overlay: 'rgba(0, 0, 0, 0.5)',

  // Shadow Layer indicator
  shadowLayerActive: '#8E44AD', // Purple — indicates Shadow Layer is processing
} as const;

export const typography = {
  heading1: {
    fontSize: 28,
    fontWeight: '700' as const,
    color: colors.textPrimary,
    lineHeight: 34,
  },
  heading2: {
    fontSize: 22,
    fontWeight: '600' as const,
    color: colors.textPrimary,
    lineHeight: 28,
  },
  heading3: {
    fontSize: 18,
    fontWeight: '600' as const,
    color: colors.textPrimary,
    lineHeight: 24,
  },
  body: {
    fontSize: 16,
    fontWeight: '400' as const,
    color: colors.textPrimary,
    lineHeight: 22,
  },
  bodySmall: {
    fontSize: 14,
    fontWeight: '400' as const,
    color: colors.textPrimary,
    lineHeight: 20,
  },
  caption: {
    fontSize: 12,
    fontWeight: '400' as const,
    color: colors.textSecondary,
    lineHeight: 16,
  },
  button: {
    fontSize: 16,
    fontWeight: '600' as const,
    color: colors.textOnPrimary,
    lineHeight: 22,
  },
} as const;

export const spacing = {
  xs: 4,
  sm: 8,
  md: 16,
  lg: 24,
  xl: 32,
  xxl: 48,
} as const;

export const borderRadius = {
  sm: 4,
  md: 8,
  lg: 12,
  xl: 16,
  full: 9999,
} as const;

// Friction-Full UI constants (Law 6 — Cognitive Sovereignty)
export const frictionConfig = {
  submitDelayMs: 3000,          // 3-second delay on all submit/approve buttons
  countdownIntervalMs: 100,     // Countdown animation tick rate
  minRationaleChars: 100,       // Minimum characters for judgment rationale
  minJustificationChars: 200,   // Minimum characters for divergence justification
  scrollGateThreshold: 0.95,    // Must scroll 95% to unlock continue button
} as const;

export const theme = {
  colors,
  typography,
  spacing,
  borderRadius,
  frictionConfig,
} as const;

export type Theme = typeof theme;
export default theme;
