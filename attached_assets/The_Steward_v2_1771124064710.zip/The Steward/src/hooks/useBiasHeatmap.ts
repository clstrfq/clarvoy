import { useQuery } from '@tanstack/react-query';
import * as biasHeatmapService from '../services/biasHeatmap';
import { useRoleGate } from './useRoleGate';

export function useBiasHeatmap(date?: string) {
  const { hasAccess } = useRoleGate(['BOARD_MEMBER', 'SYSTEM_ADMIN', 'AUDITOR']);
  return useQuery({
    queryKey: ['bias-heatmap', date],
    queryFn: () => biasHeatmapService.getBiasHeatmap(date),
    enabled: hasAccess,
  });
}
