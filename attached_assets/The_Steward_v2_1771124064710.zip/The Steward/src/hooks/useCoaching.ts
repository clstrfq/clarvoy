import { useCoachingStore } from '../stores/coachingStore';

export function useCoaching() {
  return useCoachingStore();
}
