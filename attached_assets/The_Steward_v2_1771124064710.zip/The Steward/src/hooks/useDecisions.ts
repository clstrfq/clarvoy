// =============================================================================
// THE STEWARD — Decision Hooks (React Query)
// =============================================================================
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import * as decisionsService from '../services/decisions';

export function useDecisions() {
  return useQuery({ queryKey: ['decisions'], queryFn: decisionsService.listDecisions });
}

export function useDecision(id: string) {
  return useQuery({
    queryKey: ['decisions', id],
    queryFn: () => decisionsService.getDecision(id),
    enabled: !!id,
  });
}

export function useCreateDecision() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: decisionsService.createDecision,
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['decisions'] }),
  });
}
