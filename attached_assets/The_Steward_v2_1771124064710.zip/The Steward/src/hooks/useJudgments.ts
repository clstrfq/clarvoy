// =============================================================================
// THE STEWARD — Judgment Hooks (React Query)
// =============================================================================
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import * as judgmentsService from '../services/judgments';

export function useJudgmentResults(decisionId: string) {
  return useQuery({
    queryKey: ['judgments', decisionId],
    queryFn: () => judgmentsService.getJudgmentResults(decisionId),
    enabled: !!decisionId,
    refetchInterval: 10000, // Poll every 10s while waiting for blind submissions
  });
}

export function useSubmitJudgment() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: judgmentsService.submitJudgment,
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ['judgments', variables.decision_id] });
    },
  });
}
