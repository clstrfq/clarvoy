// =============================================================================
// THE STEWARD — RBAC Enforcement Hook
// =============================================================================
// Authority: constitution.md Part IV (RBAC Matrix)
import { useAuthStore } from '../stores/authStore';
import { UserRole } from '../types';

/**
 * Hook to enforce role-based access. Returns true if user has required role.
 * Used by AdminStack and Board-only screens (Law 12 enforcement).
 */
export function useRoleGate(allowedRoles: UserRole[]): {
  hasAccess: boolean;
  userRole: UserRole | null;
} {
  const user = useAuthStore((state) => state.user);
  const userRole = user?.role ?? null;
  const hasAccess = userRole !== null && allowedRoles.includes(userRole);
  return { hasAccess, userRole };
}
