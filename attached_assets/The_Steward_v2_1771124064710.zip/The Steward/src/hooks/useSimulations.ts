import { useQuery, useMutation } from '@tanstack/react-query';
import * as simulationsService from '../services/simulations';
import { SimulationRequest } from '../types';

export function useSimulationResults(decisionId: string) {
  return useQuery({
    queryKey: ['simulations', decisionId],
    queryFn: () => simulationsService.getSimulationResults(decisionId),
    enabled: !!decisionId,
  });
}

export function useRunSimulation() {
  return useMutation({ mutationFn: simulationsService.runSimulation });
}
