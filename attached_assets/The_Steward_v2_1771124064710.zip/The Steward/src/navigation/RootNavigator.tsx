// =============================================================================
// THE STEWARD — Root Navigator
// =============================================================================
import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { ActivityIndicator, View, Text, StyleSheet } from 'react-native';

import { useAuthStore } from '../stores/authStore';
import { useRoleGate } from '../hooks/useRoleGate';
import { colors, typography } from '../config/theme';

// Screens
import DashboardScreen from '../screens/DashboardScreen';
import DecisionListScreen from '../screens/DecisionListScreen';
import DecisionDetailScreen from '../screens/DecisionDetailScreen';
import BlindInputScreen from '../screens/BlindInputScreen';
import GroupResultsScreen from '../screens/GroupResultsScreen';
import OutsideViewScreen from '../screens/OutsideViewScreen';
import PreMortemScreen from '../screens/PreMortemScreen';
import CoachingChatScreen from '../screens/CoachingChatScreen';
import SimulationConfigScreen from '../screens/SimulationConfigScreen';
import FutureConesScreen from '../screens/FutureConesScreen';
import ProfileScreen from '../screens/ProfileScreen';
import LLMSettingsScreen from '../screens/LLMSettingsScreen';
import BiasHeatMapDashboard from '../screens/BiasHeatMapDashboard';
import AuditLogScreen from '../screens/AuditLogScreen';
import LoginScreen from '../screens/LoginScreen';

const Tab = createBottomTabNavigator();
const Stack = createNativeStackNavigator();

function HomeStack() {
  return (
    <Stack.Navigator screenOptions={{ headerStyle: { backgroundColor: colors.primary }, headerTintColor: '#FFF' }}>
      <Stack.Screen name="Dashboard" component={DashboardScreen} options={{ title: 'The Steward' }} />
    </Stack.Navigator>
  );
}

function DecisionsStack() {
  return (
    <Stack.Navigator screenOptions={{ headerStyle: { backgroundColor: colors.primary }, headerTintColor: '#FFF' }}>
      <Stack.Screen name="DecisionList" component={DecisionListScreen} options={{ title: 'Decisions' }} />
      <Stack.Screen name="DecisionDetail" component={DecisionDetailScreen} options={{ title: 'Decision' }} />
      <Stack.Screen name="BlindInput" component={BlindInputScreen} options={{ title: 'Blind Assessment' }} />
      <Stack.Screen name="GroupResults" component={GroupResultsScreen} options={{ title: 'Group Results' }} />
      <Stack.Screen name="OutsideView" component={OutsideViewScreen} options={{ title: 'Outside View' }} />
      <Stack.Screen name="PreMortem" component={PreMortemScreen} options={{ title: 'Pre-Mortem' }} />
    </Stack.Navigator>
  );
}

function CoachingStack() {
  return (
    <Stack.Navigator screenOptions={{ headerStyle: { backgroundColor: colors.primary }, headerTintColor: '#FFF' }}>
      <Stack.Screen name="CoachingChat" component={CoachingChatScreen} options={{ title: 'Decision Coach' }} />
    </Stack.Navigator>
  );
}

function SimulationsStack() {
  return (
    <Stack.Navigator screenOptions={{ headerStyle: { backgroundColor: colors.primary }, headerTintColor: '#FFF' }}>
      <Stack.Screen name="SimConfig" component={SimulationConfigScreen} options={{ title: 'Chaos Simulator' }} />
      <Stack.Screen name="FutureCones" component={FutureConesScreen} options={{ title: 'Scenario Cones' }} />
    </Stack.Navigator>
  );
}

function SettingsStack() {
  return (
    <Stack.Navigator screenOptions={{ headerStyle: { backgroundColor: colors.primary }, headerTintColor: '#FFF' }}>
      <Stack.Screen name="Profile" component={ProfileScreen} options={{ title: 'Settings' }} />
      <Stack.Screen name="LLMSettings" component={LLMSettingsScreen} options={{ title: 'AI Provider' }} />
    </Stack.Navigator>
  );
}

function AdminStack() {
  return (
    <Stack.Navigator screenOptions={{ headerStyle: { backgroundColor: colors.primary }, headerTintColor: '#FFF' }}>
      <Stack.Screen name="BiasHeatMap" component={BiasHeatMapDashboard} options={{ title: 'Bias Heat Map' }} />
      <Stack.Screen name="AuditLog" component={AuditLogScreen} options={{ title: 'Audit Log' }} />
    </Stack.Navigator>
  );
}

function AuthStack() {
  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      <Stack.Screen name="Login" component={LoginScreen} />
    </Stack.Navigator>
  );
}

function MainTabs() {
  const { hasAccess: isBoardOrAdmin } = useRoleGate(['BOARD_MEMBER', 'SYSTEM_ADMIN', 'AUDITOR']);

  return (
    <Tab.Navigator
      screenOptions={{
        headerShown: false,
        tabBarActiveTintColor: colors.primary,
        tabBarInactiveTintColor: colors.textSecondary,
        tabBarStyle: { borderTopColor: colors.border },
      }}
    >
      <Tab.Screen name="Home" component={HomeStack} options={{ tabBarLabel: 'Home', tabBarIcon: () => <Text>🏠</Text> }} />
      <Tab.Screen name="Decisions" component={DecisionsStack} options={{ tabBarLabel: 'Decisions', tabBarIcon: () => <Text>⚖️</Text> }} />
      <Tab.Screen name="Coaching" component={CoachingStack} options={{ tabBarLabel: 'Coach', tabBarIcon: () => <Text>🧠</Text> }} />
      <Tab.Screen name="Simulations" component={SimulationsStack} options={{ tabBarLabel: 'Chaos', tabBarIcon: () => <Text>🎲</Text> }} />
      <Tab.Screen name="Settings" component={SettingsStack} options={{ tabBarLabel: 'Settings', tabBarIcon: () => <Text>⚙️</Text> }} />
      {isBoardOrAdmin && (
        <Tab.Screen name="Admin" component={AdminStack} options={{ tabBarLabel: 'Board', tabBarIcon: () => <Text>🛡️</Text> }} />
      )}
    </Tab.Navigator>
  );
}

export default function RootNavigator() {
  const { isAuthenticated, isLoading } = useAuthStore();

  if (isLoading) {
    return (
      <View style={styles.loading}>
        <ActivityIndicator size="large" color={colors.primary} />
        <Text style={styles.loadingText}>Initializing The Steward...</Text>
      </View>
    );
  }

  return (
    <NavigationContainer>
      {isAuthenticated ? <MainTabs /> : <AuthStack />}
    </NavigationContainer>
  );
}

const styles = StyleSheet.create({
  loading: { flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: colors.background },
  loadingText: { ...typography.body, color: colors.textSecondary, marginTop: 12 },
});
