import React from 'react';
import { View, Text, FlatList, StyleSheet } from 'react-native';
import Card from '../components/ui/Card';
import { useRoleGate } from '../hooks/useRoleGate';
import { colors, typography, spacing } from '../config/theme';

export default function AuditLogScreen() {
  const { hasAccess } = useRoleGate(['BOARD_MEMBER', 'SYSTEM_ADMIN', 'AUDITOR']);

  if (!hasAccess) {
    return <View style={styles.denied}><Text style={styles.deniedText}>Access Denied (Law 4)</Text></View>;
  }

  const sampleEntries = [
    { id: '1', type: 'SUNK_COST', severity: 'HIGH', timestamp: '2 hours ago', decision: 'Grant #1024' },
    { id: '2', type: 'ANCHORING', severity: 'MEDIUM', timestamp: '5 hours ago', decision: 'Budget Q3' },
    { id: '3', type: 'CONFIRMATION_BIAS', severity: 'CRITICAL', timestamp: '1 day ago', decision: 'Strategy 2025' },
  ];

  return (
    <FlatList
      style={styles.container}
      data={sampleEntries}
      keyExtractor={(item) => item.id}
      contentContainerStyle={styles.content}
      renderItem={({ item }) => (
        <Card>
          <View style={styles.row}>
            <Text style={styles.type}>{item.type.replace('_', ' ')}</Text>
            <Text style={[styles.severity, item.severity === 'CRITICAL' && styles.critical]}>{item.severity}</Text>
          </View>
          <Text style={styles.decision}>{item.decision}</Text>
          <Text style={styles.time}>{item.timestamp}</Text>
        </Card>
      )}
    />
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  content: { padding: spacing.md },
  denied: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  deniedText: { ...typography.body, color: colors.danger },
  row: { flexDirection: 'row', justifyContent: 'space-between' },
  type: { ...typography.body, fontWeight: '600' },
  severity: { ...typography.caption, fontWeight: '600', color: colors.warning },
  critical: { color: colors.danger },
  decision: { ...typography.bodySmall, color: colors.textSecondary, marginTop: 2 },
  time: { ...typography.caption, marginTop: 4 },
});
