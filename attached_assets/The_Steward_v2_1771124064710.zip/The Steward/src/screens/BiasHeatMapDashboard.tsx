// =============================================================================
// THE STEWARD — Bias Heat Map Dashboard (Board-Only)
// =============================================================================
// Implements: Law 12 (Daily Bias Heat Map / Board Oversight Mandate)
// Access: BOARD_MEMBER, SYSTEM_ADMIN, AUDITOR ONLY
import React from 'react';
import { View, Text, ScrollView, StyleSheet } from 'react-native';
import Card from '../components/ui/Card';
import { useRoleGate } from '../hooks/useRoleGate';
import { colors, typography, spacing, borderRadius } from '../config/theme';
import { BIAS_TYPE_LABELS, DECISION_CATEGORY_LABELS, HEATMAP_COLOR_SCALE } from '../config/constants';

export default function BiasHeatMapDashboard() {
  const { hasAccess } = useRoleGate(['BOARD_MEMBER', 'SYSTEM_ADMIN', 'AUDITOR']);

  if (!hasAccess) {
    return (
      <View style={styles.denied}>
        <Text style={styles.deniedIcon}>🚫</Text>
        <Text style={styles.deniedTitle}>Access Denied</Text>
        <Text style={styles.deniedText}>This dashboard is restricted to Board Members, System Administrators, and Auditors.</Text>
      </View>
    );
  }

  // Sample heat map data
  const biasTypes = Object.keys(BIAS_TYPE_LABELS);
  const categories = Object.keys(DECISION_CATEGORY_LABELS);
  const sampleMatrix = biasTypes.map(() => categories.map(() => Math.floor(Math.random() * 12)));

  const getCellColor = (value: number): string => {
    const scale = [...HEATMAP_COLOR_SCALE].reverse();
    for (const stop of scale) {
      if (value >= stop.threshold) return stop.color;
    }
    return '#F0F0F0';
  };

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content}>
      <Text style={styles.title}>Daily Bias Heat Map</Text>
      <Text style={styles.date}>{new Date().toLocaleDateString()}</Text>

      <Card>
        <ScrollView horizontal>
          <View>
            <View style={styles.headerRow}>
              <View style={styles.labelCell} />
              {categories.map((cat) => (
                <View key={cat} style={styles.headerCell}>
                  <Text style={styles.headerText}>{DECISION_CATEGORY_LABELS[cat]}</Text>
                </View>
              ))}
            </View>
            {biasTypes.map((bias, i) => (
              <View key={bias} style={styles.dataRow}>
                <View style={styles.labelCell}>
                  <Text style={styles.labelText}>{BIAS_TYPE_LABELS[bias]}</Text>
                </View>
                {sampleMatrix[i].map((val, j) => (
                  <View key={j} style={[styles.dataCell, { backgroundColor: getCellColor(val) }]}>
                    <Text style={styles.cellValue}>{val}</Text>
                  </View>
                ))}
              </View>
            ))}
          </View>
        </ScrollView>
      </Card>

      <Card>
        <Text style={styles.legendTitle}>Legend</Text>
        <View style={styles.legendRow}>
          {HEATMAP_COLOR_SCALE.map((stop) => (
            <View key={stop.threshold} style={styles.legendItem}>
              <View style={[styles.legendDot, { backgroundColor: stop.color }]} />
              <Text style={styles.legendText}>{stop.threshold}+</Text>
            </View>
          ))}
        </View>
      </Card>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  content: { padding: spacing.md },
  title: { ...typography.heading1 },
  date: { ...typography.caption, marginBottom: spacing.md },
  denied: { flex: 1, justifyContent: 'center', alignItems: 'center', padding: spacing.xl },
  deniedIcon: { fontSize: 48 },
  deniedTitle: { ...typography.heading2, color: colors.danger, marginTop: spacing.md },
  deniedText: { ...typography.body, textAlign: 'center', color: colors.textSecondary, marginTop: spacing.sm },
  headerRow: { flexDirection: 'row' },
  headerCell: { width: 90, padding: 6, alignItems: 'center' },
  headerText: { ...typography.caption, fontWeight: '600', textAlign: 'center' },
  dataRow: { flexDirection: 'row' },
  labelCell: { width: 120, justifyContent: 'center', padding: 6 },
  labelText: { ...typography.caption, fontWeight: '600' },
  dataCell: { width: 90, height: 44, justifyContent: 'center', alignItems: 'center', margin: 1, borderRadius: 4 },
  cellValue: { ...typography.bodySmall, fontWeight: '700', color: '#FFF' },
  legendTitle: { ...typography.bodySmall, fontWeight: '600', marginBottom: spacing.xs },
  legendRow: { flexDirection: 'row', gap: spacing.md },
  legendItem: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  legendDot: { width: 12, height: 12, borderRadius: 2 },
  legendText: { ...typography.caption },
});
