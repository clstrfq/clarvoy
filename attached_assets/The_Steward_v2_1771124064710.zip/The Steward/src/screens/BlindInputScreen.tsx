import React from 'react';
import { ScrollView, StyleSheet } from 'react-native';
import { useRoute, useNavigation } from '@react-navigation/native';
import BlindInputForm from '../components/decisions/BlindInputForm';
import { colors, spacing } from '../config/theme';

export default function BlindInputScreen() {
  const route = useRoute<any>();
  const nav = useNavigation();
  const decisionId = route.params?.decisionId;

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content}>
      <BlindInputForm
        decisionId={decisionId}
        onSubmitted={() => nav.goBack()}
      />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  content: { padding: spacing.md },
});
