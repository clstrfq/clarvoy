import React, { useState, useRef } from 'react';
import { View, Text, TextInput, FlatList, TouchableOpacity, StyleSheet, KeyboardAvoidingView, Platform } from 'react-native';
import Card from '../components/ui/Card';
import { useCoachingStore } from '../stores/coachingStore';
import { colors, typography, spacing, borderRadius } from '../config/theme';
import { ChatMessage } from '../types';

export default function CoachingChatScreen() {
  const { messages, isLoading, sendMessage } = useCoachingStore();
  const [input, setInput] = useState('');
  const listRef = useRef<FlatList>(null);

  const handleSend = async () => {
    if (!input.trim()) return;
    const msg = input;
    setInput('');
    await sendMessage(msg);
    listRef.current?.scrollToEnd();
  };

  const renderMessage = ({ item }: { item: ChatMessage }) => (
    <View style={[styles.bubble, item.role === 'user' ? styles.userBubble : styles.assistantBubble]}>
      {item.role === 'assistant' && <Text style={styles.coachLabel}>Decision Hygiene Coach</Text>}
      <Text style={[styles.messageText, item.role === 'user' && styles.userText]}>{item.content}</Text>
      {item.provider && <Text style={styles.provider}>via {item.provider}</Text>}
    </View>
  );

  return (
    <KeyboardAvoidingView style={styles.container} behavior={Platform.OS === 'ios' ? 'padding' : undefined} keyboardVerticalOffset={90}>
      {messages.length === 0 && (
        <View style={styles.empty}>
          <Text style={styles.emptyTitle}>Decision Hygiene Coach</Text>
          <Text style={styles.emptyText}>
            I help surface cognitive biases and provide debiasing frameworks. I will never make decisions for you — only illuminate the path.
          </Text>
        </View>
      )}
      <FlatList
        ref={listRef}
        data={messages}
        renderItem={renderMessage}
        keyExtractor={(item) => item.id}
        contentContainerStyle={styles.list}
        onContentSizeChange={() => listRef.current?.scrollToEnd()}
      />
      <View style={styles.inputBar}>
        <TextInput
          style={styles.input}
          value={input}
          onChangeText={setInput}
          placeholder="Ask your coach..."
          placeholderTextColor={colors.textSecondary}
          multiline
        />
        <TouchableOpacity style={[styles.sendBtn, (!input.trim() || isLoading) && styles.sendDisabled]} onPress={handleSend} disabled={!input.trim() || isLoading}>
          <Text style={styles.sendText}>{isLoading ? '...' : '→'}</Text>
        </TouchableOpacity>
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  list: { padding: spacing.md },
  empty: { padding: spacing.xl, alignItems: 'center' },
  emptyTitle: { ...typography.heading2, marginBottom: spacing.sm },
  emptyText: { ...typography.body, color: colors.textSecondary, textAlign: 'center' },
  bubble: { padding: spacing.md, borderRadius: borderRadius.lg, marginBottom: spacing.sm, maxWidth: '85%' },
  userBubble: { backgroundColor: colors.primary, alignSelf: 'flex-end' },
  assistantBubble: { backgroundColor: colors.surface, alignSelf: 'flex-start' },
  coachLabel: { ...typography.caption, color: colors.secondary, marginBottom: 4 },
  messageText: { ...typography.body },
  userText: { color: '#FFFFFF' },
  provider: { ...typography.caption, marginTop: 4 },
  inputBar: { flexDirection: 'row', padding: spacing.sm, borderTopWidth: 1, borderTopColor: colors.border, gap: spacing.sm },
  input: { flex: 1, ...typography.body, backgroundColor: colors.surface, borderRadius: borderRadius.lg, padding: spacing.md, maxHeight: 100 },
  sendBtn: { backgroundColor: colors.primary, width: 44, height: 44, borderRadius: 22, justifyContent: 'center', alignItems: 'center' },
  sendDisabled: { opacity: 0.4 },
  sendText: { color: '#FFF', fontSize: 20, fontWeight: '600' },
});
