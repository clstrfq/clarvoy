import React from 'react';
import { View, Text, ScrollView, StyleSheet, RefreshControl } from 'react-native';
import Card from '../components/ui/Card';
import UncertaintyBadge from '../components/ui/UncertaintyBadge';
import { useAuthStore } from '../stores/authStore';
import { useDecisions } from '../hooks/useDecisions';
import { colors, typography, spacing } from '../config/theme';

export default function DashboardScreen() {
  const user = useAuthStore((s) => s.user);
  const { data: decisions, isLoading, refetch } = useDecisions();

  const openDecisions = decisions?.filter((d) => d.status === 'OPEN') || [];
  const inReview = decisions?.filter((d) => d.status === 'IN_REVIEW') || [];

  return (
    <ScrollView style={styles.container} refreshControl={<RefreshControl refreshing={isLoading} onRefresh={refetch} />}>
      <View style={styles.welcome}>
        <Text style={styles.greeting}>Welcome, {user?.full_name || 'Steward'}</Text>
        <Text style={styles.role}>{user?.role?.replace('_', ' ')}</Text>
      </View>

      <Card>
        <Text style={styles.cardTitle}>Decision Pipeline</Text>
        <View style={styles.statsRow}>
          <View style={styles.stat}>
            <Text style={styles.statValue}>{openDecisions.length}</Text>
            <Text style={styles.statLabel}>Open</Text>
          </View>
          <View style={styles.stat}>
            <Text style={styles.statValue}>{inReview.length}</Text>
            <Text style={styles.statLabel}>In Review</Text>
          </View>
          <View style={styles.stat}>
            <Text style={styles.statValue}>{decisions?.length || 0}</Text>
            <Text style={styles.statLabel}>Total</Text>
          </View>
        </View>
      </Card>

      <Card>
        <Text style={styles.cardTitle}>Epistemic Health</Text>
        <UncertaintyBadge confidence={0.82} label="Decision Quality" />
        <Text style={styles.healthNote}>
          Shadow Layer: ACTIVE — All decisions are being audited for cognitive bias.
        </Text>
      </Card>

      <Card>
        <Text style={styles.cardTitle}>Governance Protocol</Text>
        <Text style={styles.protocolItem}>✓ Blind Input Mode enforced</Text>
        <Text style={styles.protocolItem}>✓ Reference Class Forecasting active</Text>
        <Text style={styles.protocolItem}>✓ 3-second friction delays enabled</Text>
        <Text style={styles.protocolItem}>✓ Shadow Layer logging all submissions</Text>
      </Card>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  welcome: { padding: spacing.md, backgroundColor: colors.primary },
  greeting: { ...typography.heading2, color: '#FFFFFF' },
  role: { ...typography.caption, color: 'rgba(255,255,255,0.7)', textTransform: 'uppercase', letterSpacing: 1 },
  cardTitle: { ...typography.heading3, marginBottom: spacing.sm },
  statsRow: { flexDirection: 'row', justifyContent: 'space-around' },
  stat: { alignItems: 'center' },
  statValue: { fontSize: 28, fontWeight: '700', color: colors.primary },
  statLabel: { ...typography.caption },
  healthNote: { ...typography.caption, color: colors.textSecondary, marginTop: spacing.sm },
  protocolItem: { ...typography.bodySmall, paddingVertical: 4, color: colors.success },
});
