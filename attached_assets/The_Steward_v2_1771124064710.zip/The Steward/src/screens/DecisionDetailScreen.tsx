import React from 'react';
import { View, Text, ScrollView, StyleSheet } from 'react-native';
import { useRoute, useNavigation } from '@react-navigation/native';
import Card from '../components/ui/Card';
import Button from '../components/ui/Button';
import UncertaintyBadge from '../components/ui/UncertaintyBadge';
import { useDecision } from '../hooks/useDecisions';
import { colors, typography, spacing } from '../config/theme';
import { PRE_MORTEM_VALUE_THRESHOLD } from '../config/constants';

export default function DecisionDetailScreen() {
  const route = useRoute<any>();
  const nav = useNavigation<any>();
  const { data: decision, isLoading } = useDecision(route.params?.id);

  if (isLoading || !decision) {
    return <View style={styles.container}><Text style={styles.loading}>Loading...</Text></View>;
  }

  const requiresPreMortem = (decision.value_amount || 0) > PRE_MORTEM_VALUE_THRESHOLD;

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content}>
      <Text style={styles.title}>{decision.title}</Text>
      <View style={styles.statusRow}>
        <Text style={styles.status}>{decision.status}</Text>
        {decision.value_amount && (
          <Text style={styles.amount}>${decision.value_amount.toLocaleString()}</Text>
        )}
      </View>
      {decision.description && <Text style={styles.desc}>{decision.description}</Text>}

      <Card>
        <Text style={styles.sectionTitle}>Actions</Text>
        <Button title="Submit Blind Assessment" onPress={() => nav.navigate('BlindInput', { decisionId: decision.id })} style={styles.actionBtn} />
        <Button title="View Group Results" onPress={() => nav.navigate('GroupResults', { decisionId: decision.id })} variant="secondary" style={styles.actionBtn} />
        <Button title="Outside View Check" onPress={() => nav.navigate('OutsideView', { decisionId: decision.id })} variant="secondary" style={styles.actionBtn} />
        {requiresPreMortem && (
          <Button title="Pre-Mortem Required (>${PRE_MORTEM_VALUE_THRESHOLD.toLocaleString()})" onPress={() => nav.navigate('PreMortem', { decisionId: decision.id })} variant="danger" style={styles.actionBtn} />
        )}
      </Card>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  content: { padding: spacing.md },
  loading: { ...typography.body, textAlign: 'center', marginTop: spacing.xxl },
  title: { ...typography.heading1, marginBottom: spacing.xs },
  statusRow: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: spacing.md },
  status: { ...typography.bodySmall, color: colors.secondary, fontWeight: '600' },
  amount: { ...typography.body, fontWeight: '700', color: colors.primary },
  desc: { ...typography.body, color: colors.textSecondary, marginBottom: spacing.md },
  sectionTitle: { ...typography.heading3, marginBottom: spacing.sm },
  actionBtn: { marginBottom: spacing.sm },
});
