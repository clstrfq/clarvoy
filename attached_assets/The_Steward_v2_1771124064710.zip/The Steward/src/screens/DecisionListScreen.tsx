import React from 'react';
import { View, Text, FlatList, TouchableOpacity, StyleSheet } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import Card from '../components/ui/Card';
import Button from '../components/ui/Button';
import { useDecisions } from '../hooks/useDecisions';
import { colors, typography, spacing, borderRadius } from '../config/theme';
import { Decision } from '../types';
import { timeAgo } from '../utils/dateUtils';

const STATUS_COLORS: Record<string, string> = {
  OPEN: colors.secondary,
  IN_REVIEW: colors.warning,
  BLOCKED: colors.danger,
  APPROVED: colors.success,
  REJECTED: '#7F8C8D',
};

export default function DecisionListScreen() {
  const navigation = useNavigation<any>();
  const { data: decisions, isLoading } = useDecisions();

  const renderDecision = ({ item }: { item: Decision }) => (
    <TouchableOpacity onPress={() => navigation.navigate('DecisionDetail', { id: item.id })}>
      <Card>
        <View style={styles.header}>
          <Text style={styles.title} numberOfLines={1}>{item.title}</Text>
          <View style={[styles.badge, { backgroundColor: STATUS_COLORS[item.status] || colors.textSecondary }]}>
            <Text style={styles.badgeText}>{item.status}</Text>
          </View>
        </View>
        {item.description && <Text style={styles.desc} numberOfLines={2}>{item.description}</Text>}
        <View style={styles.meta}>
          {item.value_amount && <Text style={styles.amount}>${item.value_amount.toLocaleString()}</Text>}
          <Text style={styles.time}>{timeAgo(item.created_at)}</Text>
        </View>
      </Card>
    </TouchableOpacity>
  );

  return (
    <View style={styles.container}>
      <FlatList
        data={decisions}
        renderItem={renderDecision}
        keyExtractor={(item) => item.id}
        contentContainerStyle={styles.list}
        ListEmptyComponent={
          <View style={styles.empty}>
            <Text style={styles.emptyText}>{isLoading ? 'Loading...' : 'No decisions yet'}</Text>
          </View>
        }
      />
      <View style={styles.fab}>
        <Button title="+ New Decision" onPress={() => navigation.navigate('DecisionDetail', { isNew: true })} />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  list: { padding: spacing.md },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: spacing.xs },
  title: { ...typography.body, fontWeight: '600', flex: 1, marginRight: spacing.sm },
  badge: { paddingHorizontal: spacing.sm, paddingVertical: 2, borderRadius: borderRadius.sm },
  badgeText: { ...typography.caption, color: '#FFF', fontWeight: '600', fontSize: 10 },
  desc: { ...typography.bodySmall, color: colors.textSecondary, marginBottom: spacing.xs },
  meta: { flexDirection: 'row', justifyContent: 'space-between' },
  amount: { ...typography.bodySmall, fontWeight: '600', color: colors.primary },
  time: { ...typography.caption },
  empty: { alignItems: 'center', padding: spacing.xxl },
  emptyText: { ...typography.body, color: colors.textSecondary },
  fab: { padding: spacing.md },
});
