import React from 'react';
import { View, Text, ScrollView, StyleSheet } from 'react-native';
import Card from '../components/ui/Card';
import UncertaintyBadge from '../components/ui/UncertaintyBadge';
import { colors, typography, spacing, borderRadius } from '../config/theme';

export default function FutureConesScreen() {
  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content}>
      <Text style={styles.title}>Future Scenario Cones</Text>

      {[
        { label: 'Worst Case (p5)', color: colors.danger, desc: 'Funding collapse, mission failure', budget: '$145,000', timeline: '21 months' },
        { label: 'Attractor (p50)', color: colors.secondary, desc: 'Most probable trajectory', budget: '$101,200', timeline: '12.5 months' },
        { label: 'Butterfly Effect (p95)', color: colors.success, desc: 'Non-linear expansion', budget: '$88,000', timeline: '9 months' },
      ].map(({ label, color, desc, budget, timeline }) => (
        <Card key={label}>
          <View style={[styles.coneHeader, { borderLeftColor: color }]}>
            <Text style={[styles.coneTitle, { color }]}>{label}</Text>
            <Text style={styles.coneDesc}>{desc}</Text>
          </View>
          <View style={styles.coneStats}>
            <View style={styles.coneStat}>
              <Text style={styles.coneStatLabel}>Budget</Text>
              <Text style={styles.coneStatValue}>{budget}</Text>
            </View>
            <View style={styles.coneStat}>
              <Text style={styles.coneStatLabel}>Timeline</Text>
              <Text style={styles.coneStatValue}>{timeline}</Text>
            </View>
          </View>
          <UncertaintyBadge confidence={label.includes('p50') ? 0.82 : 0.55} />
        </Card>
      ))}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  content: { padding: spacing.md },
  title: { ...typography.heading1, marginBottom: spacing.md },
  coneHeader: { borderLeftWidth: 4, paddingLeft: spacing.sm, marginBottom: spacing.sm },
  coneTitle: { ...typography.heading3 },
  coneDesc: { ...typography.caption },
  coneStats: { flexDirection: 'row', gap: spacing.lg, marginBottom: spacing.sm },
  coneStat: {},
  coneStatLabel: { ...typography.caption },
  coneStatValue: { ...typography.body, fontWeight: '700' },
});
