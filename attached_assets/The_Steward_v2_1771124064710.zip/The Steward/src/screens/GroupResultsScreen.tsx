import React from 'react';
import { View, Text, ScrollView, StyleSheet } from 'react-native';
import { useRoute } from '@react-navigation/native';
import Card from '../components/ui/Card';
import VarianceDisplay from '../components/decisions/VarianceDisplay';
import { useJudgmentResults } from '../hooks/useJudgments';
import { colors, typography, spacing } from '../config/theme';

export default function GroupResultsScreen() {
  const route = useRoute<any>();
  const { data, isLoading } = useJudgmentResults(route.params?.decisionId);

  if (isLoading) return <View style={styles.center}><Text>Loading...</Text></View>;

  if (data?.status === 'pending') {
    return (
      <View style={styles.center}>
        <Text style={styles.pendingIcon}>🔒</Text>
        <Text style={styles.pendingTitle}>Awaiting Submissions</Text>
        <Text style={styles.pendingText}>
          {data.submitted} of {data.total} judgments submitted.{'\n'}
          Results are sealed until all committee members have submitted.
        </Text>
        <Text style={styles.lawRef}>Law 2: Noise Intolerance — Information Cascade Block</Text>
      </View>
    );
  }

  if (data?.status === 'complete') {
    return (
      <ScrollView style={styles.container} contentContainerStyle={styles.content}>
        <VarianceDisplay variance={data.variance} />
        <Card>
          <Text style={styles.sectionTitle}>Individual Scores</Text>
          {data.judgments.map((j, i) => (
            <View key={j.id} style={styles.judgmentRow}>
              <Text style={styles.judgmentScore}>{j.score_quant}</Text>
              <Text style={styles.judgmentRationale} numberOfLines={3}>{j.rationale_qual}</Text>
            </View>
          ))}
        </Card>
      </ScrollView>
    );
  }

  return null;
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  content: { padding: spacing.md },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center', padding: spacing.xl },
  pendingIcon: { fontSize: 48, marginBottom: spacing.md },
  pendingTitle: { ...typography.heading2, marginBottom: spacing.sm },
  pendingText: { ...typography.body, textAlign: 'center', color: colors.textSecondary },
  lawRef: { ...typography.caption, color: colors.warning, marginTop: spacing.md, fontStyle: 'italic' },
  sectionTitle: { ...typography.heading3, marginBottom: spacing.sm },
  judgmentRow: { flexDirection: 'row', gap: spacing.sm, paddingVertical: spacing.sm, borderBottomWidth: 1, borderBottomColor: colors.border },
  judgmentScore: { fontSize: 24, fontWeight: '700', color: colors.primary, width: 40 },
  judgmentRationale: { ...typography.bodySmall, flex: 1, color: colors.textSecondary },
});
