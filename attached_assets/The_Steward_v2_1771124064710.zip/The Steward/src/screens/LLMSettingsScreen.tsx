// Implements: Law 9 (LLM Provider Sovereignty) — User MUST be able to select their LLM.
import React, { useState } from 'react';
import { View, Text, ScrollView, TouchableOpacity, StyleSheet } from 'react-native';
import Card from '../components/ui/Card';
import Button from '../components/ui/Button';
import { LLM_PROVIDERS } from '../config/constants';
import { colors, typography, spacing, borderRadius } from '../config/theme';
import { LLMProvider } from '../types';

export default function LLMSettingsScreen() {
  const [selected, setSelected] = useState<LLMProvider>('claude');

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content}>
      <Text style={styles.title}>Choose Your AI Coach</Text>
      <Text style={styles.subtitle}>Law 9: No single provider may be hardcoded as the exclusive option.</Text>

      {LLM_PROVIDERS.map((provider) => (
        <TouchableOpacity key={provider.id} onPress={() => setSelected(provider.id)}>
          <Card style={selected === provider.id ? styles.selectedCard : undefined}>
            <View style={styles.providerRow}>
              <View style={styles.providerInfo}>
                <Text style={styles.providerName}>{provider.name}</Text>
                <Text style={styles.providerModel}>{provider.model}</Text>
                <Text style={styles.providerDesc}>{provider.description}</Text>
              </View>
              <View style={[styles.radio, selected === provider.id && styles.radioSelected]} />
            </View>
            <Text style={styles.authMethod}>Auth: {provider.authMethod === 'oauth' ? 'OAuth 2.0' : 'API Key'}</Text>
          </Card>
        </TouchableOpacity>
      ))}

      <Button title="Save Provider Preference" onPress={() => console.log('Save:', selected)} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  content: { padding: spacing.md },
  title: { ...typography.heading2, marginBottom: spacing.xs },
  subtitle: { ...typography.caption, color: colors.warning, marginBottom: spacing.md, fontStyle: 'italic' },
  selectedCard: { borderWidth: 2, borderColor: colors.primary },
  providerRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  providerInfo: { flex: 1 },
  providerName: { ...typography.body, fontWeight: '600' },
  providerModel: { ...typography.caption, color: colors.secondary },
  providerDesc: { ...typography.caption, color: colors.textSecondary },
  radio: { width: 20, height: 20, borderRadius: 10, borderWidth: 2, borderColor: colors.border },
  radioSelected: { borderColor: colors.primary, backgroundColor: colors.primary },
  authMethod: { ...typography.caption, marginTop: spacing.xs },
});
