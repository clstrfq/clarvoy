import React, { useState } from 'react';
import { View, Text, TextInput, StyleSheet, Alert, KeyboardAvoidingView, Platform } from 'react-native';
import Button from '../components/ui/Button';
import { useAuthStore } from '../stores/authStore';
import { colors, typography, spacing, borderRadius } from '../config/theme';

export default function LoginScreen() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const login = useAuthStore((s) => s.login);
  const isLoading = useAuthStore((s) => s.isLoading);

  const handleLogin = async () => {
    try { await login(email, password); }
    catch { Alert.alert('Login Failed', 'Invalid credentials.'); }
  };

  return (
    <KeyboardAvoidingView style={styles.container} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <View style={styles.inner}>
        <View style={styles.header}>
          <Text style={styles.title}>The Steward</Text>
          <Text style={styles.subtitle}>System 2 Governance</Text>
          <Text style={styles.tagline}>Decision hygiene for mission-critical outcomes</Text>
        </View>
        <TextInput style={styles.input} placeholder="Email" value={email} onChangeText={setEmail}
          autoCapitalize="none" keyboardType="email-address" placeholderTextColor={colors.textSecondary} />
        <TextInput style={styles.input} placeholder="Password" value={password} onChangeText={setPassword}
          secureTextEntry placeholderTextColor={colors.textSecondary} />
        <Button title="Sign In" onPress={handleLogin} loading={isLoading} disabled={!email || !password} />
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.primary },
  inner: { flex: 1, justifyContent: 'center', padding: spacing.xl },
  header: { alignItems: 'center', marginBottom: spacing.xxl },
  title: { fontSize: 36, fontWeight: '800', color: '#FFFFFF', letterSpacing: 1 },
  subtitle: { ...typography.heading3, color: 'rgba(255,255,255,0.8)', marginTop: spacing.xs },
  tagline: { ...typography.caption, color: 'rgba(255,255,255,0.5)', marginTop: spacing.sm },
  input: {
    backgroundColor: 'rgba(255,255,255,0.12)', borderRadius: borderRadius.md, padding: spacing.md,
    ...typography.body, color: '#FFFFFF', marginBottom: spacing.md, borderWidth: 1, borderColor: 'rgba(255,255,255,0.2)',
  },
});
