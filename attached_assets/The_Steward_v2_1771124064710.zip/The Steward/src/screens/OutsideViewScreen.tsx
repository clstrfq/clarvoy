import React from 'react';
import { ScrollView, StyleSheet } from 'react-native';
import OutsideViewCalculator from '../components/decisions/OutsideViewCalculator';
import { colors, spacing } from '../config/theme';

export default function OutsideViewScreen() {
  const sampleRefClass = {
    id: '1', category: 'IT_MIGRATION', description: 'IT Migration',
    avg_cost_overrun: 45, avg_time_overrun: 55, base_rate_failure: 0.18,
    sample_size: 1200, source: 'Flyvbjerg (2021)', updated_at: '',
  };

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content}>
      <OutsideViewCalculator
        referenceClass={sampleRefClass}
        userEstimateBudget={100000}
        userEstimateTimeline={6}
        onJustificationSubmitted={(j) => console.log('Justification:', j)}
      />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  content: { padding: spacing.md },
});
