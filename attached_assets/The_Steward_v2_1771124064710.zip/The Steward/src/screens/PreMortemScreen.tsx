import React from 'react';
import { ScrollView, StyleSheet } from 'react-native';
import { useRoute, useNavigation } from '@react-navigation/native';
import PreMortemInput from '../components/decisions/PreMortemInput';
import { colors, spacing } from '../config/theme';

export default function PreMortemScreen() {
  const route = useRoute<any>();
  const nav = useNavigation();
  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content}>
      <PreMortemInput
        decisionId={route.params?.decisionId}
        onSubmit={(narrative) => { console.log('Pre-mortem:', narrative); nav.goBack(); }}
      />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  content: { padding: spacing.md },
});
