import React from 'react';
import { View, Text, ScrollView, StyleSheet, TouchableOpacity } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import Card from '../components/ui/Card';
import Button from '../components/ui/Button';
import { useAuthStore } from '../stores/authStore';
import { colors, typography, spacing } from '../config/theme';

export default function ProfileScreen() {
  const nav = useNavigation<any>();
  const { user, logout } = useAuthStore();

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content}>
      <Card>
        <Text style={styles.name}>{user?.full_name}</Text>
        <Text style={styles.role}>{user?.role?.replace('_', ' ')}</Text>
        <Text style={styles.email}>{user?.email}</Text>
      </Card>

      <TouchableOpacity onPress={() => nav.navigate('LLMSettings')}>
        <Card><Text style={styles.menuItem}>AI Provider Settings</Text></Card>
      </TouchableOpacity>

      <Card>
        <Text style={styles.menuItem}>Data Export (CSV / JSON / PDF)</Text>
        <Text style={styles.menuHint}>Law 7: Your data is never caged</Text>
      </Card>

      <View style={styles.footer}>
        <Button title="Sign Out" onPress={logout} variant="danger" />
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  content: { padding: spacing.md },
  name: { ...typography.heading2 },
  role: { ...typography.bodySmall, color: colors.secondary, textTransform: 'uppercase', letterSpacing: 1 },
  email: { ...typography.caption, marginTop: spacing.xs },
  menuItem: { ...typography.body, fontWeight: '600' },
  menuHint: { ...typography.caption, color: colors.textSecondary, marginTop: 2 },
  footer: { marginTop: spacing.xl },
});
