import React, { useState } from 'react';
import { View, Text, TextInput, ScrollView, StyleSheet, Alert } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import Card from '../components/ui/Card';
import FrictionButton from '../components/ui/FrictionButton';
import UncertaintyBadge from '../components/ui/UncertaintyBadge';
import { colors, typography, spacing, borderRadius } from '../config/theme';

export default function SimulationConfigScreen() {
  const nav = useNavigation<any>();
  const [budget, setBudget] = useState('100000');
  const [timeline, setTimeline] = useState('12');
  const [impact, setImpact] = useState('75');
  const [runs, setRuns] = useState('100');

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content}>
      <Card>
        <Text style={styles.title}>Monte Carlo Chaos Simulator</Text>
        <Text style={styles.desc}>
          Inject constructive noise to reveal hidden fracture points. Minimum 100 iterations per simulation.
        </Text>
        <UncertaintyBadge confidence={0.5} label="Simulation Required" />
      </Card>

      <Card>
        <Text style={styles.sectionTitle}>Parameters</Text>
        {[
          { label: 'Budget ($)', value: budget, set: setBudget },
          { label: 'Timeline (months)', value: timeline, set: setTimeline },
          { label: 'Expected Impact (0-100)', value: impact, set: setImpact },
          { label: 'Iterations (min 100)', value: runs, set: setRuns },
        ].map(({ label, value, set }) => (
          <View key={label} style={styles.field}>
            <Text style={styles.label}>{label}</Text>
            <TextInput style={styles.input} value={value} onChangeText={set} keyboardType="numeric" />
          </View>
        ))}
      </Card>

      <FrictionButton
        title="Run Chaos Simulation"
        onPress={() => nav.navigate('FutureCones', { budget, timeline, impact, runs })}
        confirmationText="This will run Monte Carlo perturbation analysis"
      />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  content: { padding: spacing.md },
  title: { ...typography.heading2, marginBottom: spacing.xs },
  desc: { ...typography.bodySmall, color: colors.textSecondary, marginBottom: spacing.sm },
  sectionTitle: { ...typography.heading3, marginBottom: spacing.sm },
  field: { marginBottom: spacing.md },
  label: { ...typography.bodySmall, fontWeight: '600', marginBottom: spacing.xs },
  input: { borderWidth: 1, borderColor: colors.border, borderRadius: borderRadius.md, padding: spacing.sm, ...typography.body },
});
