// =============================================================================
// THE STEWARD — Auth Service
// =============================================================================
import * as SecureStore from 'expo-secure-store';
import * as api from './api';
import { User } from '../types';
import { ENDPOINTS } from '../config/constants';

export async function login(email: string, password: string): Promise<User> {
  const response = await api.post<{ user: User; access_token: string }>(
    ENDPOINTS.auth.login,
    { email, password }
  );
  await SecureStore.setItemAsync('access_token', response.access_token);
  return response.user;
}

export async function logout(): Promise<void> {
  await SecureStore.deleteItemAsync('access_token');
}

export async function getSession(): Promise<User | null> {
  const token = await SecureStore.getItemAsync('access_token');
  if (!token) return null;
  try {
    const user = await api.get<User>('/api/v1/auth/me');
    return user;
  } catch {
    await SecureStore.deleteItemAsync('access_token');
    return null;
  }
}

export async function register(email: string, password: string, fullName: string, role: string): Promise<User> {
  return api.post<User>(ENDPOINTS.auth.register, { email, password, full_name: fullName, role });
}
