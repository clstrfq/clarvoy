// =============================================================================
// THE STEWARD — Bias Heatmap Service (Board-Only)
// =============================================================================
import * as api from './api';
import { BiasHeatmapCache } from '../types';
import { ENDPOINTS } from '../config/constants';

export async function getBiasHeatmap(date?: string): Promise<BiasHeatmapCache> {
  const params = date ? `?date=${date}` : '';
  return api.get<BiasHeatmapCache>(`${ENDPOINTS.admin.biasHeatmap}${params}`);
}
