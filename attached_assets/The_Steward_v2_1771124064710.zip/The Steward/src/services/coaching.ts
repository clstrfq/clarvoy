// =============================================================================
// THE STEWARD — Coaching Service
// =============================================================================
import * as api from './api';
import { CoachingResponse } from '../types';
import { ENDPOINTS } from '../config/constants';

export async function sendCoachingMessage(message: string): Promise<CoachingResponse> {
  return api.post<CoachingResponse>(ENDPOINTS.coaching.chat, { message });
}

export async function getCoachingHistory(): Promise<CoachingResponse[]> {
  return api.get<CoachingResponse[]>(ENDPOINTS.coaching.history);
}
