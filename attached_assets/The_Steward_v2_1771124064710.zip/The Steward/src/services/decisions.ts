// =============================================================================
// THE STEWARD — Decisions Service
// =============================================================================
import * as api from './api';
import { Decision } from '../types';
import { ENDPOINTS } from '../config/constants';

export async function listDecisions(): Promise<Decision[]> {
  return api.get<Decision[]>(ENDPOINTS.decisions.list);
}

export async function createDecision(data: {
  title: string;
  description?: string;
  value_amount?: number;
  reference_class_id?: string;
}): Promise<Decision> {
  return api.post<Decision>(ENDPOINTS.decisions.create, data);
}

export async function getDecision(id: string): Promise<Decision> {
  return api.get<Decision>(ENDPOINTS.decisions.detail(id));
}

export async function updateDecisionStatus(id: string, status: string): Promise<Decision> {
  return api.put<Decision>(ENDPOINTS.decisions.detail(id), { status });
}
