// =============================================================================
// THE STEWARD — Data Export Service (Law 7: Anti-Caging)
// =============================================================================
import * as api from './api';
import { ENDPOINTS } from '../config/constants';

export async function exportData(format: 'csv' | 'json' | 'pdf'): Promise<Blob> {
  return api.get(ENDPOINTS.export(format), { responseType: 'blob' });
}
