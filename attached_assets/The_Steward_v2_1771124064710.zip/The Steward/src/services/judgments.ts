// =============================================================================
// THE STEWARD — Judgments Service
// =============================================================================
// Implements: Law 2 (Noise Intolerance), Guardrail 4 (Immutable Epistemic Logging)
import * as api from './api';
import { Judgment, JudgmentSubmissionStatus, VarianceResult } from '../types';
import { ENDPOINTS } from '../config/constants';

export async function submitJudgment(data: {
  decision_id: string;
  score_quant: number;
  rationale_qual: string;
  hash_integrity: string;
}): Promise<Judgment> {
  return api.post<Judgment>(ENDPOINTS.judgments.submit, data);
}

export async function getJudgmentResults(
  decisionId: string
): Promise<{ status: 'pending'; submitted: number; total: number } | { status: 'complete'; judgments: Judgment[]; variance: VarianceResult }> {
  return api.get(ENDPOINTS.judgments.results(decisionId));
}
