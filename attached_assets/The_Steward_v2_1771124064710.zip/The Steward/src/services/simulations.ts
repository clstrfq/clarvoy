// =============================================================================
// THE STEWARD — Simulations Service
// =============================================================================
import * as api from './api';
import { Simulation, SimulationRequest } from '../types';
import { ENDPOINTS } from '../config/constants';

export async function runSimulation(request: SimulationRequest): Promise<Simulation> {
  return api.post<Simulation>(ENDPOINTS.simulations.run, request);
}

export async function getSimulationResults(decisionId: string): Promise<Simulation[]> {
  return api.get<Simulation[]>(ENDPOINTS.simulations.results(decisionId));
}
