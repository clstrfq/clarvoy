// =============================================================================
// THE STEWARD — Auth Store (Zustand)
// =============================================================================
// Authority: spec.md Section 1.2 (User Personas), constitution.md Part IV (RBAC)
// =============================================================================

import { create } from 'zustand';
import { User, UserRole, AuthState } from '../types';
import * as authService from '../services/auth';

export const useAuthStore = create<AuthState>((set, get) => ({
  user: null,
  isAuthenticated: false,
  isLoading: true,

  login: async (email: string, password: string) => {
    set({ isLoading: true });
    try {
      const user = await authService.login(email, password);
      set({ user, isAuthenticated: true, isLoading: false });
    } catch (error) {
      set({ isLoading: false });
      throw error;
    }
  },

  logout: async () => {
    await authService.logout();
    set({ user: null, isAuthenticated: false });
  },

  checkSession: async () => {
    set({ isLoading: true });
    try {
      const user = await authService.getSession();
      set({ user, isAuthenticated: !!user, isLoading: false });
    } catch {
      set({ user: null, isAuthenticated: false, isLoading: false });
    }
  },
}));

// Role-based helper selectors
export const useUserRole = (): UserRole | null =>
  useAuthStore((state) => state.user?.role ?? null);

export const useIsBoardOrAdmin = (): boolean =>
  useAuthStore((state) => {
    const role = state.user?.role;
    return role === 'BOARD_MEMBER' || role === 'SYSTEM_ADMIN' || role === 'AUDITOR';
  });

export const useIsAdmin = (): boolean =>
  useAuthStore((state) => state.user?.role === 'SYSTEM_ADMIN');
