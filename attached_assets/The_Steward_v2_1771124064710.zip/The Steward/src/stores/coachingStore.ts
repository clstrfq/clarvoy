// =============================================================================
// THE STEWARD — Coaching Store (Zustand)
// =============================================================================
import { create } from 'zustand';
import { ChatMessage, CoachingState } from '../types';
import * as coachingService from '../services/coaching';

export const useCoachingStore = create<CoachingState>((set, get) => ({
  messages: [],
  isLoading: false,

  sendMessage: async (message: string) => {
    const userMsg: ChatMessage = {
      id: Date.now().toString(),
      role: 'user',
      content: message,
      timestamp: new Date().toISOString(),
    };
    set((state) => ({ messages: [...state.messages, userMsg], isLoading: true }));

    try {
      const response = await coachingService.sendCoachingMessage(message);
      const assistantMsg: ChatMessage = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: response.message,
        provider: response.provider,
        timestamp: new Date().toISOString(),
      };
      set((state) => ({ messages: [...state.messages, assistantMsg], isLoading: false }));
    } catch (error) {
      set({ isLoading: false });
      throw error;
    }
  },

  clearChat: () => set({ messages: [] }),
}));
