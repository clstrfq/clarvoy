// =============================================================================
// THE STEWARD — Decision Store (Zustand)
// =============================================================================
import { create } from 'zustand';
import { Decision, DecisionState } from '../types';

export const useDecisionStore = create<DecisionState>((set) => ({
  activeDecision: null,
  setActiveDecision: (decision: Decision | null) => set({ activeDecision: decision }),
}));
