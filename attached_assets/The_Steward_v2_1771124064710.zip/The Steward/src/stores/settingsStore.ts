// =============================================================================
// THE STEWARD — Settings Store (Zustand)
// =============================================================================
import { create } from 'zustand';
import { UserSettings, SettingsState } from '../types';
import * as api from '../services/api';
import { ENDPOINTS } from '../config/constants';

export const useSettingsStore = create<SettingsState>((set) => ({
  settings: null,

  loadSettings: async () => {
    try {
      const response = await api.get<UserSettings>(ENDPOINTS.settings);
      set({ settings: response });
    } catch (error) {
      console.error('[SettingsStore] Failed to load settings:', error);
    }
  },

  updateSettings: async (updates: Partial<UserSettings>) => {
    try {
      const response = await api.put<UserSettings>(ENDPOINTS.settings, updates);
      set({ settings: response });
    } catch (error) {
      console.error('[SettingsStore] Failed to update settings:', error);
      throw error;
    }
  },
}));
