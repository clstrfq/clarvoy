// =============================================================================
// THE STEWARD — Core TypeScript Type Definitions
// =============================================================================
// Authority: Derived from spec.md Section 9 (Data Schema)
// All types must align with the PostgreSQL schema defined in spec.md.

// --- Enums ---

export type UserRole =
  | 'STANDARD_USER'
  | 'COMMITTEE_MEMBER'
  | 'BOARD_MEMBER'
  | 'SYSTEM_ADMIN'
  | 'AUDITOR';

export type DecisionStatus =
  | 'OPEN'
  | 'IN_REVIEW'
  | 'BLOCKED'
  | 'APPROVED'
  | 'REJECTED';

export type BiasSeverity = 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';

export type BiasType =
  | 'SUNK_COST'
  | 'HALO_EFFECT'
  | 'ANCHORING'
  | 'CONFIRMATION_BIAS'
  | 'RECENCY_BIAS'
  | 'LOSS_AVERSION'
  | 'OPTIMISM_BIAS'
  | 'GROUPTHINK';

export type DecisionCategory =
  | 'GRANT_ALLOCATION'
  | 'BUDGET_APPROVAL'
  | 'STRATEGIC_PLANNING'
  | 'PERSONNEL';

export type LLMProvider =
  | 'gemini'
  | 'notebooklm'
  | 'claude'
  | 'chatgpt'
  | 'perplexity';

export type EmailProvider = 'outlook' | 'gmail' | 'proton';
export type CalendarProvider = 'outlook' | 'google';

export type FailureClassification =
  | 'INTERNAL_FAILURE'
  | 'EXTERNAL_SHOCK'
  | 'MIXED';

// --- Core Models ---

export interface User {
  id: string;
  email: string;
  full_name: string;
  role: UserRole;
  prestige_score: number;
  bias_profile_id: string | null;
  noise_contribution_metric: number;
  preferred_llm_provider: LLMProvider;
  created_at: string;
  updated_at: string;
}

export interface Decision {
  id: string;
  title: string;
  description: string | null;
  project_id: string | null;
  status: DecisionStatus;
  final_outcome: string | null;
  reference_class_id: string | null;
  value_amount: number | null;
  created_by: string;
  created_at: string;
  updated_at: string;
}

export interface Judgment {
  id: string;
  decision_id: string;
  user_id: string;
  score_quant: number; // 1-10
  rationale_qual: string; // min 100 chars
  hash_integrity: string; // SHA-256
  hidden_bias_flags: Record<string, unknown>;
  vector_embedding: number[] | null;
  submitted_at: string;
}

export interface ReferenceClass {
  id: string;
  category: string;
  description: string | null;
  avg_cost_overrun: number;
  avg_time_overrun: number;
  base_rate_failure: number;
  sample_size: number;
  source: string | null;
  updated_at: string;
}

export interface AuditLogEntry {
  id: string;
  judgment_id: string | null;
  decision_id: string | null;
  user_id: string | null;
  detected_fallacies: DetectedFallacy[];
  debate_counter_argument: string | null;
  bias_severity: BiasSeverity;
  bias_category: BiasType | null;
  decision_category: DecisionCategory | null;
  hash_integrity_check: string | null;
  created_at: string;
}

export interface DetectedFallacy {
  type: BiasType;
  confidence: number;
  evidence: string;
}

export interface Simulation {
  id: string;
  decision_id: string;
  run_count: number;
  p5_outcome: SimulationOutcome;
  p50_outcome: SimulationOutcome;
  p95_outcome: SimulationOutcome;
  distribution_data: number[];
  perturbation_params: PerturbationParams;
  created_at: string;
}

export interface SimulationOutcome {
  budget: number;
  timeline: number;
  impact: number;
}

export interface PerturbationParams {
  funding_variance: number;
  regulatory_variance: number;
  staff_turnover_variance: number;
}

export interface BiasProfile {
  id: string;
  user_id: string;
  sunk_cost_score: number;
  halo_effect_score: number;
  anchoring_score: number;
  confirmation_bias_score: number;
  recency_bias_score: number;
  loss_aversion_score: number;
  optimism_bias_score: number;
  groupthink_score: number;
  overall_bias_load: number;
  last_updated: string;
}

export interface CoachingLogEntry {
  id: string;
  user_id: string;
  llm_provider: LLMProvider;
  prompt_summary: string | null;
  response_summary: string | null;
  context_sources: string[];
  session_duration_seconds: number | null;
  created_at: string;
}

export interface EmailContext {
  id: string;
  user_id: string;
  provider: EmailProvider;
  email_summary: string;
  relevance_score: number;
  decision_id: string | null;
  extracted_at: string;
  expires_at: string;
}

export interface CalendarContext {
  id: string;
  user_id: string;
  provider: CalendarProvider;
  meeting_title: string | null;
  meeting_date: string;
  attendee_count: number;
  is_recurring: boolean;
  coaching_signal: string | null;
  extracted_at: string;
}

export interface VoiceNote {
  id: string;
  user_id: string;
  decision_id: string | null;
  transcript: string;
  duration_seconds: number;
  consent_recorded: boolean;
  two_party_consent: boolean;
  audio_file_path: string | null;
  audio_expires_at: string | null;
  created_at: string;
}

export interface BiasHeatmapCache {
  id: string;
  report_date: string;
  heatmap_data: HeatmapData;
  total_detections: number;
  critical_count: number;
  generated_at: string;
}

export interface HeatmapData {
  matrix: number[][]; // [bias_type_index][decision_category_index] = severity_count
  labels: {
    x: BiasType[];
    y: DecisionCategory[];
  };
  drilldown: Record<string, AuditLogEntry[]>;
}

export interface RiskRegisterEntry {
  id: string;
  decision_id: string;
  narrative: string;
  failure_classification: FailureClassification;
  created_by: string;
  reviewed_at: string | null;
  created_at: string;
}

export interface UserSettings {
  id: string;
  user_id: string;
  preferred_llm: LLMProvider;
  llm_credentials: Record<string, unknown>; // encrypted
  email_integration_enabled: boolean;
  email_providers: EmailProvider[];
  calendar_integration_enabled: boolean;
  calendar_providers: CalendarProvider[];
  voice_recording_enabled: boolean;
  voice_cloud_transcription: boolean;
  two_party_consent_jurisdiction: boolean;
  updated_at: string;
}

export interface OrgConfig {
  id: string;
  key: string;
  value: unknown;
  description: string | null;
  updated_by: string | null;
  updated_at: string;
}

// --- API Request/Response Types ---

export interface CoachingRequest {
  message: string;
  context?: {
    bias_profile?: BiasProfile;
    noise_score?: number;
    detected_biases?: DetectedFallacy[];
    decision_summary?: Decision[];
    email_calendar_context?: string;
    voice_transcripts?: string;
  };
}

export interface CoachingResponse {
  message: string;
  provider: LLMProvider;
  sources?: string[];
  confidence?: number;
}

export interface VarianceResult {
  mean: number;
  std_dev: number;
  cv: number;
  is_high_noise: boolean;
  scores: number[];
}

export interface JudgmentSubmissionStatus {
  status: 'pending' | 'complete';
  submitted: number;
  total: number;
}

export interface SimulationRequest {
  decision_id: string;
  budget: number;
  timeline: number;
  expected_impact: number;
  perturbation_params?: Partial<PerturbationParams>;
  run_count?: number;
}

// --- UI State Types ---

export interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  login: (email: string, password: string) => Promise<void>;
  logout: () => Promise<void>;
  checkSession: () => Promise<void>;
}

export interface DecisionState {
  activeDecision: Decision | null;
  setActiveDecision: (decision: Decision | null) => void;
}

export interface SettingsState {
  settings: UserSettings | null;
  loadSettings: () => Promise<void>;
  updateSettings: (updates: Partial<UserSettings>) => Promise<void>;
}

export interface CoachingState {
  messages: ChatMessage[];
  isLoading: boolean;
  sendMessage: (message: string) => Promise<void>;
  clearChat: () => void;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  provider?: LLMProvider;
  timestamp: string;
}
