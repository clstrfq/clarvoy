// =============================================================================
// THE STEWARD — Cryptographic Utilities
// =============================================================================
// Implements: Guardrail 4 (Immutable Epistemic Logging)
import * as Crypto from 'expo-crypto';

/**
 * Generate SHA-256 hash of judgment data for tamper-proof audit trail.
 * This hash is stored BEFORE any group visualization is generated.
 */
export async function hashJudgment(
  decisionId: string,
  userId: string,
  scoreQuant: number,
  rationaleQual: string
): Promise<string> {
  const payload = JSON.stringify({
    decision_id: decisionId,
    user_id: userId,
    score_quant: scoreQuant,
    rationale_qual: rationaleQual,
    timestamp: new Date().toISOString(),
  });
  return Crypto.digestStringAsync(Crypto.CryptoDigestAlgorithm.SHA256, payload);
}
