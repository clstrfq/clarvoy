// =============================================================================
// THE STEWARD — RBAC Permission Helpers
// =============================================================================
// Authority: constitution.md Part IV (RBAC Matrix)
import { UserRole } from '../types';

const ROLE_HIERARCHY: Record<string, number> = {
  STANDARD_USER: 1,
  COMMITTEE_MEMBER: 2,
  BOARD_MEMBER: 3,
  SYSTEM_ADMIN: 4,
  AUDITOR: 3,
};

export function canAccessBiasHeatmap(role: UserRole): boolean {
  return ['BOARD_MEMBER', 'SYSTEM_ADMIN', 'AUDITOR'].includes(role);
}

export function canAccessAuditLog(role: UserRole): boolean {
  return ['BOARD_MEMBER', 'SYSTEM_ADMIN', 'AUDITOR'].includes(role);
}

export function canRunSimulations(role: UserRole): boolean {
  return role !== 'STANDARD_USER' && role !== 'AUDITOR';
}

export function canManageUsers(role: UserRole): boolean {
  return role === 'SYSTEM_ADMIN';
}

export function canSubmitJudgments(role: UserRole): boolean {
  return role !== 'AUDITOR';
}
