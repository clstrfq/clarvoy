// =============================================================================
// THE STEWARD — Client-Side Statistics Utilities
// =============================================================================
export function mean(values: number[]): number {
  return values.reduce((sum, v) => sum + v, 0) / values.length;
}

export function standardDeviation(values: number[]): number {
  const avg = mean(values);
  const squaredDiffs = values.map((v) => Math.pow(v - avg, 2));
  return Math.sqrt(squaredDiffs.reduce((sum, v) => sum + v, 0) / (values.length - 1));
}

export function coefficientOfVariation(values: number[]): number {
  const avg = mean(values);
  return avg !== 0 ? standardDeviation(values) / avg : Infinity;
}

export function isHighNoise(values: number[], threshold = 1.5): boolean {
  return standardDeviation(values) > threshold;
}
